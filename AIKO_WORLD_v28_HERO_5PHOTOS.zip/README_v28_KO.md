# 愛子 WORLD v28 — 첫 화면 5장 콜라주 + RENT/모린 배경

## 변경 내용
- 기존 대문 사진 4장은 그대로 유지.
- 새 록스타 피규어 사진을 중앙 강조 이미지 1장으로 추가 → 총 5장.
- 사용자가 제공한 흑백 《RENT》/모린 이미지의 흐릿한 분위기를 대문 배경에 적용.
- PC·태블릿·모바일 화면 크기별로 배치 조정.
- 이미지·CSS만 추가하며 공연·캘린더·관리자·Supabase·기존 DB는 변경하지 않음.
- 메인 갤러리의 사진 4개는 그대로 유지(대문 영역만 5장).

## 설치 순서
1. GitHub `kimhyunsoo1028-create/aiko-world` 저장소 최상위에 `AIKO_WORLD_v28_HERO_5PHOTOS.zip` 그대로 업로드하고 Commit.
2. Netlify → Project configuration → Build settings → Build command에서 *기존의 모든 명령을 유지한 채* 맨 끝에 아래 한 줄 추가:

    && unzip -o AIKO_WORLD_v28_HERO_5PHOTOS.zip && node install-aiworld-v28.cjs

3. 기존 v27 패치 명령 뒤에 v28 명령이 오도록 설정 후 Save.
4. GitHub에 Commit해 배포가 이미 실행되었다면 중복 Trigger deploy는 필요 없음. 그렇지 않으면 Netlify Deploys에서 새 배포 실행.
5. Published 확인 후 https://aiko-world.com 을 강력 새로고침(Ctrl+Shift+R) 또는 시크릿 창으로 확인.

## 확인
- 대문 오른쪽에 메인 큰 록스타 피규어 + 기존 4장 = 총 5장.
- 배경에 《RENT》/Maureen/아이코의 흑백 이미지가 희미하게 표현됨.
- 모바일 레이아웃 확인.
- 관리자 콘텐츠 편집·공연 자료에 영향 없음.

## 주의
- 실행 전 GitHub 리포지토리와 현재 Netlify Build command를 백업 권장.
- Build command에서 이전 명령을 덮어쓰지 마세요.
- 위 패치는 정적 화면만 바꾸며 CMS 갤러리 사진 업로드 방식은 그대로 유지합니다.
- 업로드 이미지는 사용자 제공 파일에 기반하며 상업적 이용·배포 시 권리 확인 필요.
- 두 이미지가 이미 배경 흐림 처리되도록 CSS가 설정되어 있으므로 전체 스크린샷을 배경 이미지로 붙여 넣지 마세요.
- 테이블이나 영구 데이터는 절대로 지우지 않습니다.
