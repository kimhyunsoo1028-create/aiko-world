/** AIKO WORLD v28: idempotent, non-destructive homepage hero upgrade. */
const fs=require('fs');
const path=require('path');
const home=path.join(process.cwd(),'public','index.html');
if(!fs.existsSync(home)) throw new Error('v28: public/index.html missing. Run previous project build before v28.');
let html=fs.readFileSync(home,'utf8');
if(!html.includes('class="hero-visual"')||!html.includes('class="photo-block photo-four"')){
  throw new Error('v28: the expected original homepage collage was not found; refusing unsafe change.');
}
const link='<link rel="stylesheet" href="hero-v28.css?v=28">';
if(!html.includes('hero-v28.css')) html=html.replace('</head>',link+'\n</head>');
const block='<div class="photo-block photo-five"><img src="images/hero-rockstar-feature.webp" alt="붉은 록스타 의상과 사다리의 스미다 아이코 팬 아트 캐릭터" width="1024" height="1536" decoding="async"></div>';
if(!html.includes('class="photo-block photo-five"')){
  const hit=/<div class="photo-block photo-four">[\s\S]*?<\/div>/;
  if(!hit.test(html)) throw new Error('v28: original fourth image block not found');
  html=html.replace(hit, m=>m+block);
}
html=html.replace('스미다 아이코 팬 캐릭터 네 장','스미다 아이코 팬 캐릭터 다섯 장');
fs.writeFileSync(home,html,'utf8');
for(const f of ['hero-v28.css','images/hero-rockstar-feature.webp','images/hero-rent-maureen-bg.webp']){
 if(!fs.existsSync(path.join(process.cwd(),'public',f)))throw new Error('v28: missing asset '+f);
}
console.log('AIKO WORLD v28: five-photo feature and RENT Maureen blurred background active. Existing homepage content and databases unchanged.');
