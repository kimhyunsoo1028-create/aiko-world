AIKO WORLD v45 — 관리자 전용 방문자 카운터 설치 안내
====================================================
기준: GitHub kimhyunsoo1028-create/aiko-world / Netlify / Supabase
기존 메인 사진 5장·홈 디자인·RENT 캘린더·공연·방송·관리자 자료는 그대로 보존합니다.

[먼저 확인]
- ZIP을 Netlify에 사이트 전체로 직접 업로드하지 마세요. 이것은 기존 사이트에 추가하는 패치입니다.
- 이 패치는 `public/index.html`, `public/admin/index.html`이 생성되는 기존 Netlify 빌드를 기준으로 제작했습니다.
- GitHub의 기본 브랜치에 있는 모든 기존 빌드 명령을 유지해야 합니다.
- Supabase의 비밀 키(service_role, sb_secret_)를 절대 업로드하거나 공개 환경변수로 사용하지 마세요.

1. Supabase SQL 실행 (처음 1회)
  ① Supabase 프로젝트 > SQL Editor > New query
  ② `AIKO_WORLD_v45_private_analytics.sql` 내용을 붙여넣기
  ③ Run 클릭 후 `...ready` 메시지를 확인
  (site_admins와 is_site_admin()이 이미 있어야 합니다.)

2. Netlify 환경변수 두 가지 추가
  Site configuration > Environment variables > Add a variable:
  - AIKO_ANALYTICS_SUPABASE_URL = https://[프로젝트ID].supabase.co
  - AIKO_ANALYTICS_PUBLISHABLE_KEY = Supabase API Keys의 publishable key (sb_publishable_...)
    (기존 anon JWT 사용 가능. service_role/secret 금지.)
  두 변수 모두 Builds에 사용할 수 있도록 설정합니다.

3. GitHub 저장소 최상위에 ZIP 파일 그대로 업로드
  - 파일명: AIKO_WORLD_v45_private_analytics_patch.zip
  - 저장소: https://github.com/kimhyunsoo1028-create/aiko-world
  - Add file > Upload files > Commit changes
  (ZIP 내부 파일을 GitHub에서 각각 풀어서 올릴 필요는 없습니다.)

4. Netlify Build command의 맨 뒤에만 아래를 추가
  기존 명령이 이미 있으면 지우거나 바꾸지 마세요.
  && unzip -o AIKO_WORLD_v45_private_analytics_patch.zip && node install-aiko-analytics-v45.cjs
  예: 기존에 node install-aiworld-v29.cjs가 맨 마지막이라면
  ... && node install-aiworld-v29.cjs && unzip -o AIKO_WORLD_v45_private_analytics_patch.zip && node install-aiko-analytics-v45.cjs
  Publish directory는 기존 값(public) 유지.

5. Netlify 배포 확인
  Deploys에서 새 배포가 Published인지 확인합니다.
  빌드 로그에 `[AIKO WORLD v45] Private analytics installed` 메시지가 있어야 합니다.
  SQL이 아직 적용되지 않은 경우에도 사이트가 바로 망가지지는 않지만 기록은 실패합니다.

6. 로그인과 방문자 통계 확인
  - 관리자 로그인: https://aiko-world.com/admin/
  - 관리자 통계: https://aiko-world.com/admin/analytics/
  - 관리자 화면에 로그인하면 `방문 통계 (관리자 전용)` 링크가 추가됩니다.
  - 다른 브라우저에서 사이트 홈을 열고, 관리자 통계 새로고침을 눌러 수치 변화 확인
  - 비로그인 이용자에게는 관리자 통계 조회가 거부됩니다.

[통계 해석 / 개인정보]
- 오늘/어제 방문자: 해당 날짜의 서로 다른 브라우저 ID 개수
- 누적 방문자: 저장된 기간의 서로 다른 브라우저 ID 개수 (실제 사람 수와 다를 수 있음)
- 페이지 조회수: 홈페이지 및 일반 페이지가 로드된 횟수
- 추세: 최근 14일의 일별 방문 브라우저 수
- IP 주소, 이름, 국가, 페이지 URL은 기록하지 않습니다.
- 브라우저 저장소를 삭제하거나 다른 기기로 방문하면 별도 방문자로 잡힙니다.
- JavaScript 차단, 광고 차단, 봇, 과도한 요청에 따른 집계 오차가 있습니다.
- 날짜는 UTC+9 기준입니다. 첫 설치 이전의 과거 방문 통계는 복구되지 않습니다.
- 데이터 삭제 정책은 별도 적용하지 않았으며 데이터는 누적 저장됩니다.

[중요]
- 현재 GitHub 저장소에는 완성된 메인 사이트 전체 소스가 없고 ZIP 패치들이 있습니다.
  이 설치 파일은 기존 public 빌드가 유지된다는 조건 아래에서만 정상 작동합니다.
- 이 패치는 실제 운영 사이트에 아직 설치 또는 검증된 것이 아닙니다.
- 설치가 실패하면 이전 Published 버전은 유지되며, Netlify 빌드 로그를 확인하세요.
- 기존 관리자 기능이 변경된 경우에는 관리자 링크가 나타나지 않을 수 있습니다.
  직접 /admin/analytics/ 경로로 접속해 관리자 로그인 권한을 확인할 수 있습니다.
