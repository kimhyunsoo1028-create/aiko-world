-- AIKO WORLD v45 관리자 전용 방문 통계 | 2026-11-04
-- 먼저 public.is_site_admin()이 기존 사이트에 정상 설정되어 있어야 합니다.
-- 다른 사이트 테이블과 기존 공연·사진·게시글 데이터는 변경하지 않습니다.
-- 하루 기준: 한국/일본 표준시(Asia/Seoul, UTC+9)
-- 기록: 익명 브라우저 ID의 서버측 해시만 저장. IP, 이름, 위치, 페이지 URL 저장 안 함.

DO $check$ BEGIN
  IF to_regprocedure('public.is_site_admin()') IS NULL THEN
    RAISE EXCEPTION '기존 관리자 함수 public.is_site_admin() 가 없습니다. 기존 관리자 SQL을 먼저 적용하세요.';
  END IF;
END $check$;

CREATE TABLE IF NOT EXISTS public.aiko_visitor_daily (
  visit_day date NOT NULL,
  anonymous_hash text NOT NULL,
  page_views bigint NOT NULL DEFAULT 1 CHECK(page_views >= 1),
  first_seen timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (visit_day, anonymous_hash)
);
CREATE INDEX IF NOT EXISTS idx_aiko_visitor_daily_day ON public.aiko_visitor_daily (visit_day DESC);
ALTER TABLE public.aiko_visitor_daily ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.aiko_visitor_daily FROM PUBLIC, anon, authenticated;
-- 테이블에는 공개 SELECT/INSERT 정책을 만들지 않습니다.
-- 익명 기록은 제한된 RPC만 허용하며 관리자 열람은 별도 RPC에서 검증합니다.

CREATE OR REPLACE FUNCTION public.aiko_record_visit(p_visitor_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE
  v_day date := (now() AT TIME ZONE 'Asia/Seoul')::date;
  v_hash text;
BEGIN
  IF p_visitor_id IS NULL THEN RETURN; END IF;
  v_hash := md5(p_visitor_id::text); -- 무작위 UUID의 가명화, 비밀번호 해시 용도 아님
  INSERT INTO public.aiko_visitor_daily (visit_day, anonymous_hash, page_views)
  VALUES (v_day, v_hash, 1)
  ON CONFLICT (visit_day, anonymous_hash) DO UPDATE
    SET page_views = LEAST(public.aiko_visitor_daily.page_views + 1, 100000),
        last_seen = now();
END;
$fn$;
REVOKE ALL ON FUNCTION public.aiko_record_visit(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.aiko_record_visit(uuid) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.aiko_get_private_visit_stats()
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE
  v_today date := (now() AT TIME ZONE 'Asia/Seoul')::date;
  v_today_unique bigint := 0;
  v_yesterday_unique bigint := 0;
  v_total_unique bigint := 0;
  v_pageviews bigint := 0;
  v_recent jsonb;
BEGIN
  IF auth.uid() IS NULL OR COALESCE(public.is_site_admin(),false) IS NOT TRUE THEN
    RAISE EXCEPTION '관리자 전용 통계입니다.' USING ERRCODE = '42501';
  END IF;
  SELECT COUNT(*) FILTER(WHERE visit_day = v_today),
         COUNT(*) FILTER(WHERE visit_day = v_today - 1),
         COUNT(DISTINCT anonymous_hash),
         COALESCE(SUM(page_views),0)
  INTO v_today_unique, v_yesterday_unique, v_total_unique, v_pageviews
  FROM public.aiko_visitor_daily;
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'date',d.visit_day,'visitors',d.unique_visitors,'pageviews',d.views
  ) ORDER BY d.visit_day), '[]'::jsonb)
  INTO v_recent
  FROM (
    SELECT gs.day::date AS visit_day,
           COUNT(t.anonymous_hash) AS unique_visitors,
           COALESCE(SUM(t.page_views),0) AS views
    FROM generate_series(v_today - 13,v_today,'1 day'::interval) AS gs(day)
    LEFT JOIN public.aiko_visitor_daily t ON t.visit_day = gs.day::date
    GROUP BY gs.day
  ) d;
  RETURN jsonb_build_object(
    'today',v_today_unique,
    'yesterday',v_yesterday_unique,
    'totalVisitors',v_total_unique,
    'totalPageviews',v_pageviews,
    'last14',v_recent,
    'timezone','Asia/Seoul'
  );
END;
$fn$;
REVOKE ALL ON FUNCTION public.aiko_get_private_visit_stats() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.aiko_get_private_visit_stats() TO authenticated;

SELECT 'AIKO WORLD private visitor analytics v45 ready' AS result;
