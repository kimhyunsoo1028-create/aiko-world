'use strict';
/** AIKO WORLD v45 — add private analytics without replacing homepage/admin content.
 * Run AFTER the existing website build and other patch installers. */
const fs=require('node:fs');
const path=require('node:path');
const root=process.cwd();
const pub=path.join(root,'public');
const asset=path.join(root,'aiko-analytics-assets');
const main=path.join(pub,'index.html');
const admin=path.join(pub,'admin','index.html');
for(const file of [main,admin,path.join(asset,'visitor.js'),path.join(asset,'dashboard.js')]){
  if(!fs.existsSync(file))throw Error('[AIKO v45] 필수 파일이 없습니다: '+file);
}
const url=String(process.env.AIKO_ANALYTICS_SUPABASE_URL||'').trim().replace(/\/$/,'');
const key=String(process.env.AIKO_ANALYTICS_PUBLISHABLE_KEY||'').trim();
if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)){
  throw Error('[AIKO v45] Netlify 환경변수 AIKO_ANALYTICS_SUPABASE_URL (https://...supabase.co) 설정이 필요합니다.');
}
if(!key||key.startsWith('sb_secret_')||key.startsWith('service_role')){
  throw Error('[AIKO v45] 공개 가능한 publishable/anon key만 AIKO_ANALYTICS_PUBLISHABLE_KEY에 넣으세요. service_role/secret key 금지.');
}
if(key.startsWith('eyJ')){
  try{
    const raw=Buffer.from(key.split('.')[1]||'','base64url').toString('utf8');
    if(JSON.parse(raw).role!=='anon')throw Error('JWT role is not anon');
  }catch{throw Error('[AIKO v45] anon JWT 형식이 아닙니다. secret/service_role 키를 넣지 마세요.');}
}else if(!key.startsWith('sb_publishable_')){
  throw Error('[AIKO v45] publishable key(sb_publishable_) 또는 기존 anon JWT(eyJ...)를 사용하세요.');
}
fs.mkdirSync(pub,{recursive:true});
fs.writeFileSync(path.join(pub,'aiko-analytics-config.js'),
  'window.AIKO_ANALYTICS_CONFIG='+JSON.stringify({url,publishableKey:key})+';\n');
for(const [src,dest] of [
 ['visitor.js','aiko-analytics-visitor.js'],
 ['dashboard.js','aiko-analytics-dashboard.js'],
 ['analytics.css','aiko-analytics.css'],
 ['admin-link.js','aiko-analytics-admin-link.js'],
 ['admin/analytics/index.html','admin/analytics/index.html']]){
 const to=path.join(pub,dest);fs.mkdirSync(path.dirname(to),{recursive:true});
 fs.copyFileSync(path.join(asset,src),to);
}
function inject(file,code,marker){
 let txt=fs.readFileSync(file,'utf8');
 if(txt.includes(marker)){console.log('[AIKO v45] already injected: '+file);return;}
 if(!/<\/body>/i.test(txt))throw Error('[AIKO v45] </body>가 없습니다: '+file);
 txt=txt.replace(/<\/body>/i,code+'\n</body>');
 fs.writeFileSync(file,txt,'utf8');
}
// Add tracking to every non-admin HTML page; retain the original page contents.
function addTrackerToPublicPages(dir){
  for(const ent of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,ent.name);
    if(ent.isDirectory()){
      if(ent.name==='admin'||ent.name.startsWith('.'))continue;
      addTrackerToPublicPages(full);
    }else if(ent.isFile()&&ent.name.toLowerCase().endsWith('.html')){
      const html=fs.readFileSync(full,'utf8');
      if(!/<\/body>/i.test(html))continue;
      inject(full,'<script defer src="/aiko-analytics-config.js"></script>\n<script defer src="/aiko-analytics-visitor.js"></script>','/aiko-analytics-visitor.js');
    }
  }
}
addTrackerToPublicPages(pub);
inject(admin,'<script defer src="/aiko-analytics-config.js"></script>\n<script type="module" src="/aiko-analytics-admin-link.js"></script>','/aiko-analytics-admin-link.js');
console.log('[AIKO WORLD v45] Private analytics installed. Existing homepage and admin retained.');
