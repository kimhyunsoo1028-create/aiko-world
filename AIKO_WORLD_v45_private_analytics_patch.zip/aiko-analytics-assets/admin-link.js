/* Only render the analytics navigation link when Supabase confirms site_admins access. */
(async () => {
  try {
    const cfg=window.AIKO_ANALYTICS_CONFIG;
    if (!cfg?.url||!cfg?.publishableKey) return;
    const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
    const sb=createClient(cfg.url,cfg.publishableKey,{auth:{persistSession:true,autoRefreshToken:true}});
    const {data:{user},error}=await sb.auth.getUser();
    if(error||!user)return;
    const {data,error:adminErr}=await sb.from('site_admins').select('user_id').eq('user_id',user.id).maybeSingle();
    if(adminErr||!data)return;
    if(document.querySelector('[data-aiko-analytics-link]'))return;
    const link=document.createElement('a');
    link.href='/admin/analytics/';link.dataset.aikoAnalyticsLink='true';
    link.textContent='📊 방문 통계 (관리자 전용)';
    Object.assign(link.style,{display:'inline-block',margin:'12px',padding:'10px 14px',
      borderRadius:'10px',background:'#e4f2eb',color:'#194f3b',fontWeight:'700',textDecoration:'none'});
    (document.getElementById('dashboard')||document.querySelector('main')||document.body).prepend(link);
  } catch { /* Feature must not affect existing admin. */ }
})();
