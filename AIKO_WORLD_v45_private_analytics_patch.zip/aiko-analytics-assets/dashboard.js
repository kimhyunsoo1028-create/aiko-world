const $=id=>document.getElementById(id);
const status=$('status');
const fmt=new Intl.NumberFormat('ko-KR');
const cfg=window.AIKO_ANALYTICS_CONFIG||{};
const note=(msg,isError=false)=>{status.textContent=msg;status.style.color=isError?'#ad3030':'#4d6758';};
if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')||!cfg.publishableKey){
  note('Supabase 연결 설정이 없습니다. Netlify 환경변수를 확인해 주세요.',true);
}else{
  try{
    const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
    const sb=createClient(cfg.url,cfg.publishableKey,{auth:{persistSession:true,autoRefreshToken:true}});
    const {data:{user},error}=await sb.auth.getUser();
    if(error||!user){note('로그인이 필요합니다. /admin/에서 관리자 로그인 후 다시 방문해 주세요.',true);}
    else{
      const {data:admin,error:admErr}=await sb.from('site_admins').select('user_id').eq('user_id',user.id).maybeSingle();
      if(admErr||!admin){note('관리자 권한이 없습니다. 방문 통계는 관리자만 볼 수 있습니다.',true);}
      else{
        $('content').hidden=false;
        const load=async()=>{
          note('통계를 불러오는 중입니다.');
          try{
            const {data,error:err}=await sb.rpc('aiko_get_private_visit_stats');
            if(err)throw err;
            for(const k of ['today','yesterday','totalVisitors','totalPageviews'])$(k).textContent=fmt.format(Number(data[k]||0));
            const daily=Array.isArray(data.last14)?data.last14:[];
            const max=Math.max(1,...daily.map(d=>Number(d.visitors)||0));
            const chart=$('chart');chart.replaceChildren();
            for(const d of daily){
              const outer=document.createElement('div');outer.className='barwrap';
              const val=document.createElement('span');val.className='barval';val.textContent=String(d.visitors??0);
              const bar=document.createElement('div');bar.className='bar';bar.style.height=`${Math.max(2,Math.round((Number(d.visitors)||0)/max*165))}px`;
              const label=document.createElement('span');label.className='barlabel';label.textContent=String(d.date||'').slice(5);
              outer.append(val,bar,label);chart.append(outer);
            }
            note('관리자 확인 완료 · 통계 갱신됨');
          }catch(e){note('통계 조회 실패: '+(e?.message||'알 수 없는 오류'),true);}
        };
        $('refresh').addEventListener('click',load);
        await load();
      }
    }
  }catch(e){note('로그인 확인 오류: '+(e?.message||'알 수 없는 오류'),true);}
}
