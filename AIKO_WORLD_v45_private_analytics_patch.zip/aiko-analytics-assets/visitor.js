/* AIKO WORLD v45: anonymous browser-level visitor counting, no page URLs or IP stored */
(() => {
  'use strict';
  try {
    if (location.pathname.startsWith('/admin') || location.pathname.startsWith('/.netlify')) return;
    const cfg = window.AIKO_ANALYTICS_CONFIG;
    if (!cfg?.url || !cfg?.publishableKey || !globalThis.crypto?.randomUUID) return;
    const key = 'aiko_world_visitor_v45';
    let id;
    try {
      id = localStorage.getItem(key);
      if (!id || !/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(id)) {
        id = crypto.randomUUID(); localStorage.setItem(key,id);
      }
    } catch { id = crypto.randomUUID(); }
    const api = `${cfg.url.replace(/\/$/,'')}/rest/v1/rpc/aiko_record_visit`;
    const headers={'Content-Type':'application/json','apikey':cfg.publishableKey};
    // New sb_publishable_* keys are not JWTs. Only legacy anon JWTs use Authorization.
    if (cfg.publishableKey.startsWith('eyJ')) headers.Authorization=`Bearer ${cfg.publishableKey}`;
    fetch(api, {
      method:'POST', mode:'cors', keepalive:true, headers,
      body:JSON.stringify({p_visitor_id:id})
    }).catch(() => {});
  } catch { /* Tracking failures must never interfere with the website. */ }
})();
