-- AIKO WORLD v46 | 국가·언어·기기별 관리자 전용 방문 통계
-- v45 기존 테이블/함수/메인 홈페이지/공연 데이터는 수정하지 않습니다.
-- 시작일: 이 SQL 적용 및 v46 배포 이후의 새 방문만 기록합니다. 과거 기록 소급 불가.
-- 국가: Netlify Edge Function의 국가 코드 (IP 원문 미저장)
-- 언어: navigator.language의 언어 코드, 기기: 브라우저의 대략적 분류
-- 방문자/일: v45의 무작위 UUID를 MD5 처리한 가명 식별자로 중복 제거
-- 모든 날짜는 Asia/Seoul (한국·일본 동일 UTC+9)

DO $check$ BEGIN
  IF to_regprocedure('public.is_site_admin()') IS NULL THEN
    RAISE EXCEPTION 'public.is_site_admin() 관리자 함수가 필요합니다. v45 설정을 먼저 확인하세요.';
  END IF;
  IF to_regclass('public.aiko_visitor_daily') IS NULL THEN
    RAISE EXCEPTION 'v45 aiko_visitor_daily 테이블이 없습니다. v45 SQL을 먼저 실행하세요.';
  END IF;
END $check$;

CREATE TABLE IF NOT EXISTS public.aiko_visitor_segments (
  visit_day date NOT NULL,
  anonymous_hash text NOT NULL,
  country_code text NOT NULL DEFAULT 'ZZ' CHECK (country_code ~ '^[A-Z]{2}$'),
  language_code text NOT NULL DEFAULT 'xx' CHECK (language_code ~ '^[a-z]{2}$'),
  device_type text NOT NULL DEFAULT 'unknown' CHECK (device_type IN ('desktop','mobile','tablet','unknown')),
  first_seen timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(visit_day, anonymous_hash)
);
CREATE INDEX IF NOT EXISTS idx_aiko_visitor_segments_day ON public.aiko_visitor_segments(visit_day DESC);
ALTER TABLE public.aiko_visitor_segments ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.aiko_visitor_segments FROM PUBLIC, anon, authenticated;
-- 직접 테이블 접근은 누구에게도 열지 않습니다. 제한된 RPC로만 기록/조회합니다.

CREATE OR REPLACE FUNCTION public.aiko_record_visit_segment(
  p_visitor_id uuid,
  p_country_code text,
  p_language_code text,
  p_device_type text
)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE
  v_day date := (now() AT TIME ZONE 'Asia/Seoul')::date;
  v_country text;
  v_language text;
  v_device text;
BEGIN
  IF p_visitor_id IS NULL THEN RETURN; END IF;
  v_country := CASE
    WHEN upper(coalesce(p_country_code,'')) ~ '^[A-Z]{2}$' THEN upper(p_country_code)
    ELSE 'ZZ' END;
  v_language := CASE
    WHEN lower(coalesce(p_language_code,'')) ~ '^[a-z]{2}$' THEN lower(p_language_code)
    ELSE 'xx' END;
  v_device := CASE
    WHEN p_device_type IN ('desktop','mobile','tablet') THEN p_device_type
    ELSE 'unknown' END;

  INSERT INTO public.aiko_visitor_segments (
    visit_day, anonymous_hash, country_code, language_code, device_type
  ) VALUES (
    v_day, md5(p_visitor_id::text), v_country, v_language, v_device
  )
  ON CONFLICT (visit_day, anonymous_hash) DO NOTHING;
  -- 하루에 한 브라우저 ID당 첫 국가/언어/기기만 기록합니다.
END;
$fn$;
REVOKE ALL ON FUNCTION public.aiko_record_visit_segment(uuid,text,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.aiko_record_visit_segment(uuid,text,text,text) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.aiko_get_private_visit_segments(p_days integer DEFAULT 14)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE
  v_days integer := CASE WHEN p_days IN (7,14,30) THEN p_days ELSE 14 END;
  v_today date := (now() AT TIME ZONE 'Asia/Seoul')::date;
  v_start date;
  v_total bigint := 0;
  v_countries jsonb;
  v_languages jsonb;
  v_devices jsonb;
BEGIN
  IF auth.uid() IS NULL OR COALESCE(public.is_site_admin(),false) IS NOT TRUE THEN
    RAISE EXCEPTION '관리자 전용 통계입니다.' USING ERRCODE = '42501';
  END IF;

  v_start := v_today - (v_days - 1);
  SELECT count(*) INTO v_total
  FROM public.aiko_visitor_segments
  WHERE visit_day BETWEEN v_start AND v_today;

  SELECT coalesce(jsonb_agg(jsonb_build_object('code',x.code,'visits',x.n)
                    ORDER BY x.n DESC, x.code), '[]'::jsonb) INTO v_countries
  FROM (SELECT country_code AS code, count(*) AS n
        FROM public.aiko_visitor_segments
        WHERE visit_day BETWEEN v_start AND v_today
        GROUP BY country_code) x;

  SELECT coalesce(jsonb_agg(jsonb_build_object('code',x.code,'visits',x.n)
                    ORDER BY x.n DESC, x.code), '[]'::jsonb) INTO v_languages
  FROM (SELECT language_code AS code, count(*) AS n
        FROM public.aiko_visitor_segments
        WHERE visit_day BETWEEN v_start AND v_today
        GROUP BY language_code) x;

  SELECT coalesce(jsonb_agg(jsonb_build_object('code',x.code,'visits',x.n)
                    ORDER BY x.n DESC, x.code), '[]'::jsonb) INTO v_devices
  FROM (SELECT device_type AS code, count(*) AS n
        FROM public.aiko_visitor_segments
        WHERE visit_day BETWEEN v_start AND v_today
        GROUP BY device_type) x;

  RETURN jsonb_build_object(
    'periodDays',v_days,'fromDate',v_start,'toDate',v_today,
    'dailyUniqueSum',v_total,'countries',v_countries,
    'languages',v_languages,'devices',v_devices,
    'timezone','Asia/Seoul'
  );
END;
$fn$;
REVOKE ALL ON FUNCTION public.aiko_get_private_visit_segments(integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.aiko_get_private_visit_segments(integer) TO authenticated;

SELECT 'AIKO WORLD v46 audience insights SQL ready' AS result;
