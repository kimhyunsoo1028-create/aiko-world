'use strict';
/** AIKO WORLD v46 – additive audience insight upgrade for v45.
 * Run after `node install-aiko-analytics-v45.cjs` in the existing Netlify build. */
const fs=require('node:fs'),path=require('node:path');
const root=process.cwd(),pub=path.join(root,'public');
const src=path.join(root,'aiko-analytics-v46-assets');
const admin=path.join(pub,'admin','analytics','index.html');
for(const p of [path.join(pub,'aiko-analytics-visitor.js'),admin,
  ...['visitor-segments.js','dashboard-segments.js','segments.css','aiko-geo-insights-v46.js'].map(n=>path.join(src,n))]){
  if(!fs.existsSync(p))throw new Error('[AIKO v46] 필수 v45 또는 v46 파일 누락: '+p);
}
for(const [origin,dest] of [
  ['visitor-segments.js','aiko-analytics-segments-visitor.js'],
  ['dashboard-segments.js','aiko-analytics-segments-dashboard.js'],
  ['segments.css','aiko-analytics-segments.css']]){
  fs.copyFileSync(path.join(src,origin),path.join(pub,dest));
}
const edgeDest=path.join(root,'netlify','edge-functions','aiko-geo-insights-v46.js');
fs.mkdirSync(path.dirname(edgeDest),{recursive:true});
fs.copyFileSync(path.join(src,'aiko-geo-insights-v46.js'),edgeDest);

const pubTag='<script defer src="/aiko-analytics-segments-visitor.js"></script>';
function addPublicTracking(dir){
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()){
      if(entry.name==='admin'||entry.name.startsWith('.'))continue;
      addPublicTracking(full);
    }else if(entry.isFile()&&entry.name.toLowerCase().endsWith('.html')){
      let html=fs.readFileSync(full,'utf8');
      if(!/<\/body>/i.test(html)||html.includes('/aiko-analytics-segments-visitor.js'))continue;
      // v45 script must be present: v46 reuses its browser-only anonymous UUID.
      if(!html.includes('/aiko-analytics-visitor.js'))continue;
      html=html.replace(/<\/body>/i,`${pubTag}\n</body>`);
      fs.writeFileSync(full,html,'utf8');
    }
  }
}
addPublicTracking(pub);
let html=fs.readFileSync(admin,'utf8');
if(!html.includes('/aiko-analytics-segments.css')){
  if(!/<\/head>/i.test(html))throw Error('[AIKO v46] analytics html </head> 누락');
  html=html.replace(/<\/head>/i,'<link rel="stylesheet" href="/aiko-analytics-segments.css">\n</head>');
}
if(!html.includes('/aiko-analytics-segments-dashboard.js')){
  if(!/<\/body>/i.test(html))throw Error('[AIKO v46] analytics html </body> 누락');
  html=html.replace(/<\/body>/i,'<script type="module" src="/aiko-analytics-segments-dashboard.js"></script>\n</body>');
}
fs.writeFileSync(admin,html,'utf8');
console.log('[AIKO WORLD v46] Country/language/device insights installed. v45 and original site preserved.');
