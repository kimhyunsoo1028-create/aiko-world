AIKO WORLD v46 — 관리자 전용 국가·언어·기기 통계 확장
========================================================
기존 v45 카운터는 그대로 유지됩니다.
사이트 디자인, 5장 사진, 공연 데이터, RENT 일정, 관리자 화면을 덮어쓰지 않습니다.

추가 기능
- 국가별 방문 통계: Netlify Edge Function이 판단한 ISO 국가 코드 사용
- 언어별 방문 통계: 브라우저 기본 언어 코드(ko/ja/en 등)
- 기기별 방문 통계: 스마트폰/태블릿/데스크톱 대략적 구분
- 관리자 화면: 최근 7/14/30일 기준 비교, 날짜별 중복 제거 방문 브라우저 건수
- 기존 /admin/analytics/ 화면 아래에 추가 (별도 관리자 페이지 필요 없음)

중요한 한계
- 연령/성별은 파악하지 않습니다. GA4 등의 별도 통계 및 필요한 동의 설정이 필요합니다.
- 이번 v46 통계는 설치 후 방문부터 시작하며, v45 과거 기록을 국가별로 복원할 수 없습니다.
- 국가 정보는 사용자의 IP 기반 근사 위치로, VPN, 프록시 등에 따라 달라질 수 있습니다.
- IP, 도시, 좌표, User-Agent 원문은 별도로 저장하지 않습니다.
- 기기/언어는 사용자 설정 및 브라우저 감지 정보라 실제와 다를 수 있습니다.
- 동일 브라우저가 7일 동안 매일 방문하면 기간 합계는 7건입니다(서로 다른 7명이 아님).
- 브라우저에서 국가 정보를 보내지 않고, Netlify 엣지에서 직접 국가를 분류합니다.
- 연결 실패나 Edge Functions 미동작 시 국가 통계는 기록되지 않아도 기존 v45 방문자 카운터는 계속 작동합니다.
- Edge Functions 요청은 Netlify 사용량에 포함될 수 있습니다.
- 쿠키/분석 안내 및 개인정보처리방침에 수집 목적·항목·보관 기간을 반영하세요.

설치 순서
1) Supabase SQL Editor에서 `AIKO_WORLD_v46_audience_insights.sql` 내용 실행
   실행 뒤 `AIKO WORLD v46 audience insights SQL ready` 결과 확인
   이 SQL은 기존 v45 테이블 및 함수를 삭제/수정하지 않습니다.
2) GitHub 저장소 `kimhyunsoo1028-create/aiko-world`의 최상위에
   `AIKO_WORLD_v46_audience_insights_patch.zip` 압축 파일을 그대로 업로드하고 커밋
3) Netlify 프로젝트 > Project configuration > Build settings > Build command:
   기존 명령을 모두 유지하고 맨 끝에 다음을 추가하세요.
   && unzip -o AIKO_WORLD_v46_audience_insights_patch.zip && node install-aiko-analytics-v46.cjs
   예시: ... && node install-aiko-analytics-v45.cjs && unzip -o AIKO_WORLD_v46_audience_insights_patch.zip && node install-aiko-analytics-v46.cjs
4) 저장한 뒤 새 배포(Deploys > Trigger deploy)를 시작하고 Published 확인
5) 배포 로그: `[AIKO WORLD v46] Country/language/device insights installed. ...` 문구 확인
6) 로그인 후 https://aiko-world.com/admin/analytics/ 접속
   아래의 `방문자 국가 · 언어 · 기기` 섹션을 확인하세요.
7) 추가 확인: https://aiko-world.com/aiko-analytics/collect 에 브라우저로 바로 접근(GET) 시
   404 또는 405가 나올 수 있습니다. 실제 기록은 사이트 방문 시 POST 요청으로 처리합니다.
   개발자도구 Network에서 POST /aiko-analytics/collect 의 204 확인이 더 확실합니다.

기존 Netlify 환경변수 그대로 사용 (추가 변수 불필요)
 - AIKO_ANALYTICS_SUPABASE_URL
 - AIKO_ANALYTICS_PUBLISHABLE_KEY
(둘 다 현재처럼 All scopes 사용; service_role/secret 키 사용하지 않음)

보안 및 개인정보
- 새 데이터 테이블 aiko_visitor_segments는 RLS 활성화, 직접 접근 불가.
- 공개 RPC는 국가/언어/기기 기록만 허용하고, 조회는 기존 site_admins 인증을 통과해야 합니다.
- 공개 RPC는 봇 등에 의해 악용될 수 있으므로 정확한 방문자 수를 완벽히 보장하지 않습니다.
- 관리자 화면은 로그인 여부와 DB 관리자 권한을 매번 확인합니다.
- 연령/성별을 방문 기록에서 추측하지 않습니다.
- 사이트에는 방문자가 이해할 수 있는 개인정보·분석 안내를 게시하는 것을 권장합니다.
- 수집 중단하려면 v46 Build command 마지막 설치 명령을 제거하여 재배포하세요.
  기존 수집 자료 삭제는 SQL Editor에서 별도 보존기간 정책에 따라 처리해야 합니다.
