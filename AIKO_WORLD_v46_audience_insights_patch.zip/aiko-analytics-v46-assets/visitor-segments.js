/* AIKO WORLD v46: one demographic-free audience summary per browser per day. */
(async()=>{
  'use strict';
  try {
    if(location.pathname.startsWith('/admin') || location.pathname.startsWith('/.netlify'))return;
    const id=localStorage.getItem('aiko_world_visitor_v45');
    if(!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(id||''))return;
    const key='aiko_world_segments_last_day_v46';
    const today=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
    if(localStorage.getItem(key)===today)return;
    const ua=navigator.userAgent||'';
    let device='desktop';
    if(/iPad|Tablet|PlayBook|Silk|Kindle|SM-T|Tab\b/i.test(ua) || (/Macintosh/i.test(ua)&&navigator.maxTouchPoints>1))device='tablet';
    else if(navigator.userAgentData?.mobile || /iPhone|iPod|Android.*Mobile|Mobile|Windows Phone/i.test(ua))device='mobile';
    else if(/Android/i.test(ua))device='tablet';
    const language=(navigator.language||'').split(/[-_]/)[0].toLowerCase();
    const response=await fetch('/aiko-analytics/collect',{
      method:'POST',headers:{'Content-Type':'application/json'},
      cache:'no-store',credentials:'same-origin',
      body:JSON.stringify({visitorId:id,language:/^[a-z]{2}$/.test(language)?language:'xx',device})
    });
    if(response.ok)localStorage.setItem(key,today);
  }catch{/* never affect the public website */}
})();
