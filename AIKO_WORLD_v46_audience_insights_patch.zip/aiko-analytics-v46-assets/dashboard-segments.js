/* AIKO WORLD v46: admin-only country/language/device breakdown; the v45 dashboard stays intact. */
(async()=>{
  'use strict';
  const host=document.getElementById('content');
  const cfg=window.AIKO_ANALYTICS_CONFIG||{};
  if(!host || !cfg.url || !cfg.publishableKey)return;
  try{
    const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
    const sb=createClient(cfg.url,cfg.publishableKey,{auth:{persistSession:true,autoRefreshToken:true}});
    const {data:{user},error}=await sb.auth.getUser();
    if(error||!user)return;
    const {data:admin,error:admErr}=await sb.from('site_admins').select('user_id').eq('user_id',user.id).maybeSingle();
    if(admErr||!admin)return;
    if(document.getElementById('aiko-segments-v46'))return;
    const area=document.createElement('section');area.id='aiko-segments-v46';area.className='v46-panel';
    area.innerHTML=`<div class="v46-head"><div><h2>방문자 국가 · 언어 · 기기</h2><p>새 통계 설치 이후의 방문 기록만 표시됩니다.</p></div><label>조회 기간 <select id="v46-days"><option value="7">최근 7일</option><option value="14" selected>최근 14일</option><option value="30">최근 30일</option></select></label></div><p class="v46-status" id="v46-status" role="status">조회 준비 중…</p><p class="v46-total" id="v46-total"></p><div class="v46-columns"><section><h3>🌏 국가별</h3><div id="v46-countries"></div></section><section><h3>💬 언어별</h3><div id="v46-languages"></div></section><section><h3>📱 접속 기기</h3><div id="v46-devices"></div></section></div><p class="v46-note">이 통계의 건수는 조회 기간의 <strong>날짜별 중복 제거 방문 브라우저 수를 합산</strong>한 값입니다. 같은 사람이 여러 날 방문하면 여러 건으로 계산됩니다. 국가는 접속 시점의 네트워크 위치 기반 추정치이므로 VPN 사용 등으로 실제 거주 국가와 다를 수 있습니다. 연령과 성별은 수집하지 않습니다.</p>`;
    host.append(area);
    const $=id=>document.getElementById(id);
    const fmt=new Intl.NumberFormat('ko-KR');
    const regions=typeof Intl.DisplayNames==='function'?new Intl.DisplayNames(['ko'],{type:'region'}):null;
    const languages=typeof Intl.DisplayNames==='function'?new Intl.DisplayNames(['ko'],{type:'language'}):null;
    const deviceNames={desktop:'데스크톱',mobile:'스마트폰',tablet:'태블릿',unknown:'알 수 없음'};
    const nameFor=(kind,code)=>{
      try{
        if(kind==='countries')return code==='ZZ'?'알 수 없음':`${regions?.of(code)||code} (${code})`;
        if(kind==='languages')return code==='xx'?'알 수 없음':`${languages?.of(code)||code} (${code})`;
        return deviceNames[code]||'알 수 없음';
      }catch{return code||'알 수 없음';}
    };
    function render(kind,arr,total){
      const container=$(`v46-${kind}`);container.replaceChildren();
      if(!arr.length){container.textContent='아직 기록이 없습니다.';return;}
      const top=arr.slice(0,8);
      if(arr.length>8)top.push({code:'other',visits:arr.slice(8).reduce((a,b)=>a+Number(b.visits||0),0)});
      for(const item of top){
        const n=Math.max(0,Number(item.visits)||0);
        const percent=total>0?n/total*100:0;
        const el=document.createElement('div');el.className='v46-item';
        const label=document.createElement('div');label.className='v46-label';
        const title=document.createElement('span');title.textContent=item.code==='other'?'기타':nameFor(kind,String(item.code||''));
        const value=document.createElement('span');value.textContent=`${fmt.format(n)}건 · ${percent.toFixed(1)}%`;
        const bar=document.createElement('div');bar.className='v46-track';
        const fill=document.createElement('div');fill.className='v46-fill';fill.style.width=`${Math.max(0,Math.min(100,percent))}%`;
        label.append(title,value);bar.append(fill);el.append(label,bar);container.append(el);
      }
    }
    const load=async()=>{
      $('v46-status').textContent='분석 정보를 불러오는 중입니다.';
      try{
        const days=Number($('v46-days').value);
        const {data,error}=await sb.rpc('aiko_get_private_visit_segments',{p_days:days});
        if(error)throw error;
        const total=Number(data.dailyUniqueSum||0);
        $('v46-total').textContent=`${data.fromDate||''} ~ ${data.toDate||''} · 일별 방문 브라우저 합계 ${fmt.format(total)}건`;
        for(const kind of ['countries','languages','devices'])render(kind,Array.isArray(data[kind])?data[kind]:[],total);
        $('v46-status').textContent='관리자 전용 분석 · 갱신 완료';
      }catch(err){$('v46-status').textContent=`분석 조회 실패: ${err?.message||'알 수 없는 오류'}`;}
    };
    $('v46-days').addEventListener('change',load);
    const v45refresh=document.getElementById('refresh');if(v45refresh)v45refresh.addEventListener('click',load);
    await load();
  }catch{/* analytics extension must not break v45 */}
})();
