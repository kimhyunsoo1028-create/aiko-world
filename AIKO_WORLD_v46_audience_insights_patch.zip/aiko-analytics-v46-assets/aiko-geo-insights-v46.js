/* Netlify Edge Function v46: only an ISO country code; never store or forward visitor IP. */
export const config = {
  path: '/aiko-analytics/collect',
  method: 'POST'
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const noCache = {'Cache-Control':'no-store'};
const reply = status => new Response(null, {status, headers:noCache});

export default async function handler(request, context) {
  try {
    const callerOrigin = request.headers.get('origin');
    if (callerOrigin && new URL(callerOrigin).origin !== new URL(request.url).origin) return reply(403);
    if (Number(request.headers.get('content-length') || 0) > 512) return reply(413);
    const raw = await request.text();
    if (raw.length > 512) return reply(413);
    const body = JSON.parse(raw);
    if (typeof body?.visitorId !== 'string' || !UUID.test(body.visitorId)) return reply(400);
    const language = /^[a-z]{2}$/i.test(body.language) ? body.language.toLowerCase() : 'xx';
    const device = ['desktop','mobile','tablet'].includes(body.device) ? body.device : 'unknown';
    const edgeCountry = String(context.geo?.country?.code || '').toUpperCase();
    const country = /^[A-Z]{2}$/.test(edgeCountry) ? edgeCountry : 'ZZ';
    const url = String(Netlify.env.get('AIKO_ANALYTICS_SUPABASE_URL') || '').replace(/\/$/, '');
    const key = String(Netlify.env.get('AIKO_ANALYTICS_PUBLISHABLE_KEY') || '');
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url) ||
        !(key.startsWith('sb_publishable_') || key.startsWith('eyJ'))) return reply(503);
    const headers = {'Content-Type':'application/json','apikey':key};
    if (key.startsWith('eyJ')) headers.Authorization = `Bearer ${key}`;
    const res = await fetch(`${url}/rest/v1/rpc/aiko_record_visit_segment`, {
      method:'POST', headers, body:JSON.stringify({
        p_visitor_id:body.visitorId, p_country_code:country,
        p_language_code:language, p_device_type:device
      })
    });
    return reply(res.ok ? 204 : 502);
  } catch {
    return reply(400);
  }
}
