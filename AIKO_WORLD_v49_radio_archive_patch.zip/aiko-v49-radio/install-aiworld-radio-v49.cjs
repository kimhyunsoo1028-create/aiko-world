/** AIKO WORLD v49 · Additive radio archive + admin manager. Safe to run more than once. */
'use strict';const fs=require('node:fs'),path=require('node:path');
const root=process.cwd(),pub=path.join(root,'public'),admin=path.join(pub,'admin');
const assets=path.join(root,'aiko-v49-radio');
const pairs=[['radio-public-v49.js',path.join(pub,'radio-public-v49.js')],['radio-v49.css',path.join(pub,'radio-v49.css')],['radio-admin-v49.js',path.join(admin,'radio-admin-v49.js')],['radio-admin-v49.css',path.join(admin,'radio-admin-v49.css')]];
for(const [src,dst] of pairs){const from=path.join(assets,src);if(!fs.existsSync(from))throw Error('[v49 RADIO] Missing '+from);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(from,dst)}
function inject(file,items){if(!fs.existsSync(file))throw Error('[v49 RADIO] Missing '+file);let txt=fs.readFileSync(file,'utf8');for(const [match,insert,signature] of items){if(txt.includes(signature))continue;if(!txt.includes(match))throw Error('[v49 RADIO] Insertion point missing: '+match+' in '+file);txt=txt.replace(match,insert+'\n'+match)}fs.writeFileSync(file,txt,'utf8')}
inject(path.join(pub,'index.html'),[
 ['</head>','<link rel="stylesheet" href="/radio-v49.css?v=49.0">','/radio-v49.css'],
 ['</body>','<script defer src="/radio-public-v49.js?v=49.0"></script>','/radio-public-v49.js']
]);
inject(path.join(admin,'index.html'),[
 ['</head>','<link rel="stylesheet" href="/admin/radio-admin-v49.css?v=49.0">','radio-admin-v49.css'],
 ['</body>','<script defer src="/admin/radio-admin-v49.js?v=49.0"></script>','radio-admin-v49.js']
]);
console.log('[AIKO WORLD v49] Radio archive and admin manager installed; existing content and CMS preserved.');
