# AIKO WORLD v49 — RADIO 방송 기록 아카이브

## 포함 기능
- 메인 페이지 `RADIO` 독립 메뉴와 `#radio` 방송 아카이브
- 방송 날짜별(년-월) 분류, 프로그램·연도 필터, 내용 검색, 다시 듣기/영상/출처 링크
- 관리자 페이지 `🎙️ 라디오 방송 관리` 탭: 등록, 수정, 삭제, 공개·비공개, 한·일·영 설명, 방송국·출연자·날짜·시간
- 데이터 저장: 전용 Supabase `public.radio_broadcasts` 테이블. 공개/비공개는 데이터베이스 RLS로 보호하며 기존 공연·음악·갤러리·방송 영상 데이터는 변경하지 않습니다.
- 본 기능은 공연 영상 업로드 기능과 분리된 날짜별 라디오 방송 기록입니다.

## 적용 방법
1. Supabase의 `sql/AIKO_WORLD_radio_v49.sql`을 최초 한 번 적용합니다 (이미 테이블이 있으면 재실행하지 마세요).
2. `aiko-v49-radio` 폴더와 `install-aiworld-radio-v49.cjs` 파일을 AIKO WORLD GitHub 저장소 최상위에 올립니다.
3. Netlify의 기존 **Build command를 그대로 유지**하고 **가장 마지막에** 다음을 덧붙입니다.

   `&& node install-aiworld-radio-v49.cjs`

4. Netlify → Deploys에서 새 빌드를 배포하고 **Published** 상태를 확인합니다.
5. https://aiko-world.com/#radio 및 https://aiko-world.com/admin/ 에서 확인합니다.

## 처음 사용
- 관리자 로그인 → `🎙️ 라디오 방송 관리` → `+ 새 방송`
- 날짜와 프로그램 입력 → 공개할 경우 `방문자에게 공개하기` 체크 → `방송 기록 저장`
- 데이터베이스 `radio_broadcasts`는 빈 테이블로 시작합니다. 확인되지 않은 날짜나 방송 순서/출처는 자동으로 생성하지 않습니다.
- 관리자 권한은 기존 `site_admins` 확인과 전용 `radio_broadcasts` RLS 정책으로 보호합니다. 새로운 공개 수정 권한을 만들지 않습니다.

## 안전한 복구
Netlify Build command 마지막의 `&& node install-aiworld-radio-v49.cjs`만 빼고 재배포하면 UI가 제거됩니다. `radio_broadcasts` 데이터는 그대로 보존됩니다.

## 검증 수준
코드 문법 검사 및 설치 스크립트 중복 실행 검사를 수행합니다. GitHub에 소스를 올려도 **Netlify Build command 추가 및 Published 배포 전에는 실제 웹사이트에 새 메뉴가 보이지 않습니다.**
