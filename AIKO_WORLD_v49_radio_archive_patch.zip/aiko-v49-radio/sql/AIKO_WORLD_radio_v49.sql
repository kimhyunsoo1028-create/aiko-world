-- AIKO WORLD v49: radio broadcast archive. Existing tables are not changed.
CREATE TABLE IF NOT EXISTS public.radio_broadcasts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  broadcast_date date NOT NULL,
  broadcast_time time WITHOUT TIME ZONE,
  program text NOT NULL CHECK (length(btrim(program)) BETWEEN 1 AND 160),
  station text NOT NULL DEFAULT '',
  hosts text NOT NULL DEFAULT '',
  title_ko text NOT NULL DEFAULT '',
  title_ja text NOT NULL DEFAULT '',
  title_en text NOT NULL DEFAULT '',
  summary_ko text NOT NULL DEFAULT '',
  summary_ja text NOT NULL DEFAULT '',
  summary_en text NOT NULL DEFAULT '',
  replay_url text NOT NULL DEFAULT '',
  youtube_url text NOT NULL DEFAULT '',
  source_url text NOT NULL DEFAULT '',
  verification text NOT NULL DEFAULT 'pending' CHECK (verification IN ('pending','confirmed')),
  is_published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS radio_broadcasts_date_idx ON public.radio_broadcasts(broadcast_date DESC, broadcast_time DESC);
CREATE INDEX IF NOT EXISTS radio_broadcasts_public_idx ON public.radio_broadcasts(is_published, broadcast_date DESC);
ALTER TABLE public.radio_broadcasts ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.radio_broadcasts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.radio_broadcasts TO authenticated;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='radio_broadcasts' AND policyname='radio_read_published_or_admin') THEN
    CREATE POLICY radio_read_published_or_admin ON public.radio_broadcasts FOR SELECT TO anon, authenticated USING (is_published OR (SELECT public.is_site_admin()));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='radio_broadcasts' AND policyname='radio_insert_admin') THEN
    CREATE POLICY radio_insert_admin ON public.radio_broadcasts FOR INSERT TO authenticated WITH CHECK ((SELECT public.is_site_admin()));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='radio_broadcasts' AND policyname='radio_update_admin') THEN
    CREATE POLICY radio_update_admin ON public.radio_broadcasts FOR UPDATE TO authenticated USING ((SELECT public.is_site_admin())) WITH CHECK ((SELECT public.is_site_admin()));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='radio_broadcasts' AND policyname='radio_delete_admin') THEN
    CREATE POLICY radio_delete_admin ON public.radio_broadcasts FOR DELETE TO authenticated USING ((SELECT public.is_site_admin()));
  END IF;
END $$;
