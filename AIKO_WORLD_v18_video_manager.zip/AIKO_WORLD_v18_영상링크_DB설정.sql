-- 愛子 WORLD v1.8 · 방송 영상 링크 관리 전용 테이블
-- Supabase SQL Editor에서 단 한 번 실행하세요 (반복 실행 가능).
-- 기존 공연·사진·뉴스·관리자 테이블을 수정/삭제하지 않습니다.
-- 방문자는 링크만 읽고, 등록된 관리자만 추가/수정/삭제할 수 있습니다.

CREATE TABLE IF NOT EXISTS public.broadcast_video_links (
  id text PRIMARY KEY,
  links jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(links) = 'array'),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.broadcast_video_links ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.broadcast_video_links FROM anon, authenticated;
GRANT SELECT ON public.broadcast_video_links TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.broadcast_video_links TO authenticated;

DROP POLICY IF EXISTS "public view broadcast video links" ON public.broadcast_video_links;
CREATE POLICY "public view broadcast video links"
ON public.broadcast_video_links FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin add broadcast video links" ON public.broadcast_video_links;
CREATE POLICY "admin add broadcast video links"
ON public.broadcast_video_links FOR INSERT TO authenticated
WITH CHECK ((SELECT public.is_site_admin()));

DROP POLICY IF EXISTS "admin edit broadcast video links" ON public.broadcast_video_links;
CREATE POLICY "admin edit broadcast video links"
ON public.broadcast_video_links FOR UPDATE TO authenticated
USING ((SELECT public.is_site_admin())) WITH CHECK ((SELECT public.is_site_admin()));

DROP POLICY IF EXISTS "admin reset broadcast video links" ON public.broadcast_video_links;
CREATE POLICY "admin reset broadcast video links"
ON public.broadcast_video_links FOR DELETE TO authenticated
USING ((SELECT public.is_site_admin()));

-- 저장 여부 점검 (0행이면 아직 수정한 영상 없음):
SELECT id, jsonb_array_length(links) AS video_count, updated_at
FROM public.broadcast_video_links ORDER BY updated_at DESC LIMIT 10;
