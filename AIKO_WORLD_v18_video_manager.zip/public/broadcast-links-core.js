/* AIKO WORLD v1.8 - stable IDs and read-only presentation helpers. */
(()=>{'use strict';
  const enc = v => encodeURIComponent(String(v??'').trim());
  const episodeId = (episode, song) => `episode|${enc(episode.show)}|${enc(episode.episode)}|${enc(song.title)}|${enc(song.kind)}|${enc(song.partner)}`;
  const specialId = item => `special|${enc(item.date)}|${enc(item.station)}|${enc(item.name)}`;
  const validUrl = value => {
    try {
      const u=new URL(String(value).trim());
      return u.protocol==='https:' && !u.username && !u.password && u.hostname && !/\s/.test(value) ? u.href : null;
    } catch{return null}
  };
  const sanitize = items => Array.isArray(items) ? items.slice(0,12).map(x=>({
    label: typeof x?.label==='object'&&x.label ? {ko:String(x.label.ko||'').slice(0,80),ja:String(x.label.ja||'').slice(0,80),en:String(x.label.en||'').slice(0,80)} : String(x?.label||'영상 보기').slice(0,80).trim()||'영상 보기',
    url: validUrl(x?.url)
  })).filter(x=>x.url) : [];
  const legacyEpisode = song => song.official && validUrl(song.official) ? [{label:{ko:'공식 영상',ja:'公式動画',en:'Official video'},url:validUrl(song.official)}]:[];
  const legacySpecial = item => item.link && validUrl(item.link) ? [{label:{ko:'영상·출처',ja:'動画・出典',en:'Video / source'},url:validUrl(item.link)}]:[];
  const title=(link,lang,defaultText)=>{const v=link?.label;if(typeof v==='object')return v[lang]||v.ko||v.ja||v.en||defaultText;return v||defaultText};
  const map=new Map();
  function apply(rows){map.clear();for(const r of rows||[]){if(typeof r?.id==='string'&&Array.isArray(r.links))map.set(r.id,sanitize(r.links))}window.dispatchEvent(new Event('aiko:broadcast-links-updated'))}
  function get(id,legacy){return map.has(id)?map.get(id):legacy}
  window.AIKO_BROADCAST_LINKS={episodeId,specialId,validUrl,sanitize,legacyEpisode,legacySpecial,title,apply,get,
    episode:(e,s)=>get(episodeId(e,s),legacyEpisode(s)),special:x=>get(specialId(x),legacySpecial(x))};
})();
