import {createBroadcastEditor} from './broadcast-links-admin.mjs';
await (window.AIKO_CMS_READY || Promise.resolve());
const cfg=window.AIKO_CMS_CONFIG||{};
const $=id=>document.getElementById(id);
const show=(el,yes)=>{el.hidden=!yes};
const configured=/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')&&cfg.publishableKey&&!cfg.publishableKey.includes('PASTE_');
let broadcastEditor=null;
let sb=null, events=[],gallery=[],articles=[],sourceRows=[],inbox=[],eventId=null,articleId=null;
const message=(msg,error=false)=>{$('status').textContent=msg;$('status').className=error?'status error':'status'};
const safeUrl=s=>{try{const u=new URL(s,location.href);return ['http:','https:'].includes(u.protocol)?u.href:null}catch{return null}};
const plain=s=>String(s??'');
const field=(form,name)=>form.elements.namedItem(name);
const formValue=(form,name)=>plain(field(form,name)?.value||'').trim();
function pickText(o){return o?.ko||o?.ja||o?.en||'(제목 없음)'}
function assertUrl(s){if(s&&!/^https:\/\//i.test(s))throw new Error('공식 출처와 티켓 주소는 https://로 시작해야 합니다.')}
function makeButton(text,run,cls=''){const b=document.createElement('button');b.type='button';b.textContent=text;b.className=cls;b.onclick=run;return b}
function liButton(ul,title,sub,run,active=false){const li=document.createElement('li');const b=makeButton(title,run,active?'active':'');const small=document.createElement('small');small.textContent=sub;b.append(small);li.append(b);ul.append(li)}
async function verifyAdmin(){const {data:{user},error}=await sb.auth.getUser();if(error||!user)return false;const {data,error:err}=await sb.from('site_admins').select('user_id').eq('user_id',user.id).maybeSingle();if(err){message('관리자 권한 확인 오류: '+err.message,true);return false}return Boolean(data)}
async function loginState(){const {data:{session}}=await sb.auth.getSession();const signed=Boolean(session&&await verifyAdmin());show($('dashboard'),signed);show($('login'),!signed);$('auth-status').textContent=signed?'관리자 인증됨 · '+session.user.email:('로그인 필요');if(signed)await refreshAll()}
async function refreshAll(){
  try{
    const [ec,ga,ar,sr,fi]=await Promise.all([
      sb.from('site_content').select('payload').eq('key','events').maybeSingle(),
      sb.from('site_content').select('payload').eq('key','gallery').maybeSingle(),
      sb.from('site_articles').select('*').order('created_at',{ascending:false}),
      sb.from('feed_sources').select('*').order('name'),
      sb.from('feed_inbox').select('*').order('imported_at',{ascending:false}).limit(200)
    ]);
    for(const x of [ec,ga,ar,sr,fi])if(x.error)throw x.error;
    events=Array.isArray(ec.data?.payload)?ec.data.payload:structuredClone(window.AIKO_DATA.events);
    gallery=Array.isArray(ga.data?.payload)?ga.data.payload: [
      {src:'../photo-01.webp',alt:{ko:'초록 꽃왕관 아이코',ja:'緑の花冠の愛子',en:'Green flower crown'}},
      {src:'../photo-02.webp',alt:{ko:'밀짚모자 아이코',ja:'麦わら帽子の愛子',en:'Summer'}},
      {src:'../photo-03.webp',alt:{ko:'흰 드레스 아이코',ja:'白いドレスの愛子',en:'White dress'}},
      {src:'../photo-04.webp',alt:{ko:'빨간 의상 아이코',ja:'赤い衣装の愛子',en:'Red stage outfit'}}
    ];
    articles=ar.data||[];sourceRows=sr.data||[];inbox=fi.data||[];
    renderEvents();renderGallery();renderArticles();renderInbox();renderSources();
    if(broadcastEditor)await broadcastEditor.load();
    message('연결 완료. 저장하면 방문자 홈페이지에 바로 반영됩니다.');
  }catch(e){message('불러오기 실패: '+e.message,true)}
}
function renderEvents(){const ul=$('events-list');ul.replaceChildren();[...events].sort((a,b)=>(a.date||'').localeCompare(b.date||'')).forEach(e=>liButton(ul,pickText(e.title),(e.date||'미정')+' · '+(e.status==='confirmed'?'출연 확인':'작품 기간'),()=>{eventId=e.id;fillEvent()},e.id===eventId));if(!eventId&&events.length)eventId=events[0].id;fillEvent()}
function fillEvent(){const e=events.find(x=>x.id===eventId)||{id:'',date:'',until:'',time:'',status:'production',category:'live',title:{},city:{},desc:{}};const f=$('event-form');for(const key of ['id','date','until','time','status','category','venue','source','ticket'])field(f,key).value=e[key]||'';for(const k of ['title','city','desc'])for(const lg of ['ko','ja','en'])field(f,`${k}_${lg}`).value=e[k]?.[lg]||'';[...$('events-list').querySelectorAll('button')].forEach(b=>b.classList.toggle('active',b.textContent.startsWith(pickText(e.title))))}
function readEvent(){const f=$('event-form');const e={};for(const k of ['id','date','until','time','status','category','venue','source','ticket'])e[k]=formValue(f,k);for(const k of ['title','city','desc']){e[k]={};for(const lg of ['ko','ja','en'])e[k][lg]=formValue(f,`${k}_${lg}`)}e.id=e.id||`admin-${crypto.randomUUID()}`;e.flag='🇯🇵';if(e.until&&e.until<e.date)throw new Error('종료 날짜는 시작 날짜보다 앞설 수 없습니다.');assertUrl(e.source);assertUrl(e.ticket);if(e.status==='confirmed'&&!e.source)throw new Error('아이코 출연 확인 일정에는 공식 근거 URL이 필요합니다.');return e}
$('event-form').addEventListener('submit',async ev=>{ev.preventDefault();try{const item=readEvent();const next=events.filter(e=>e.id!==item.id).concat(item).sort((a,b)=>a.date.localeCompare(b.date));const {error}=await sb.from('site_content').upsert({key:'events',payload:next,updated_at:new Date().toISOString()});if(error)throw error;events=next;eventId=item.id;renderEvents();message('✅ 공연 일정 저장 및 공개 완료!') }catch(e){message(e.message,true)}});
$('new-event').onclick=()=>{eventId='';fillEvent();message('새 일정 내용을 입력하세요.')};
$('remove-event').onclick=async()=>{if(!eventId||!confirm('해당 일정이 실제 공개 캘린더에서 삭제됩니다. 계속할까요?'))return;try{const next=events.filter(e=>e.id!==eventId);const {error}=await sb.from('site_content').upsert({key:'events',payload:next});if(error)throw error;events=next;eventId=null;renderEvents();message('일정 삭제 및 공개 반영 완료')}catch(e){message(e.message,true)}};
function renderGallery(){const root=$('gallery-forms');root.replaceChildren();for(let i=0;i<4;i++){const item=gallery[i]||{src:'',alt:{ko:''}};const div=document.createElement('div');div.className='gallery-tile';const h=document.createElement('h3');h.textContent=`사진 ${i+1}`;const img=document.createElement('img');img.src=safeUrl(item.src||'')||'../favicon.png';img.alt='캐릭터 사진';const u=document.createElement('label');u.textContent='이미지 주소';const input=document.createElement('input');input.type='text';input.value=item.src||'';input.dataset.src=String(i);input.addEventListener('input',()=>{const url=safeUrl(input.value);if(url)img.src=url});u.append(input);const alt=document.createElement('label');alt.textContent='사진 설명';const ai=document.createElement('input');ai.value=item.alt?.ko||'';ai.dataset.alt=String(i);alt.append(ai);const fl=document.createElement('label');fl.textContent='PC 이미지 업로드 (jpg/png/webp · 5MB 이하)';const file=document.createElement('input');file.type='file';file.accept='image/png,image/jpeg,image/webp';file.addEventListener('change',async()=>{const picked=file.files?.[0];if(!picked)return;try{if(picked.size>5*1024*1024)throw new Error('파일이 5MB를 초과합니다.');if(!['image/jpeg','image/png','image/webp'].includes(picked.type))throw new Error('JPG/PNG/WebP만 지원합니다.');const ext=picked.type==='image/png'?'png':picked.type==='image/webp'?'webp':'jpg';const name=`gallery/${crypto.randomUUID()}.${ext}`;message('사진 업로드 중…');const {error}=await sb.storage.from('site-media').upload(name,picked,{contentType:picked.type,upsert:false});if(error)throw error;const {data}=sb.storage.from('site-media').getPublicUrl(name);input.value=data.publicUrl;img.src=data.publicUrl;message('사진 업로드 완료. 아래 사진 배치 저장을 눌러 공개하세요.')}catch(e){message('사진 업로드 실패: '+e.message,true)}});fl.append(file);div.append(h,img,u,alt,fl);root.append(div)}}
$('save-gallery').onclick=async()=>{try{const next=Array.from({length:4},(_,i)=>({src:document.querySelector(`[data-src="${i}"]`).value.trim(),alt:{ko:document.querySelector(`[data-alt="${i}"]`).value.trim()}}));for(const x of next){const u=safeUrl(x.src);if(!u)throw new Error('사진 URL을 모두 입력하세요.');if(!x.src.startsWith('/')&&!x.src.startsWith('../')&&!u.startsWith('https://'))throw new Error('외부 사진은 https:// 주소만 사용할 수 있습니다.')}const {error}=await sb.from('site_content').upsert({key:'gallery',payload:next});if(error)throw error;gallery=next;message('✅ 사진 4장 배치가 공개되었습니다.')}catch(e){message(e.message,true)}};
function renderArticles(){const ul=$('articles-list');ul.replaceChildren();articles.forEach(a=>liButton(ul,a.title_ko||a.title_ja||'(무제)',(a.status==='published'?'공개':'비공개')+' · '+a.created_at.slice(0,10),()=>{articleId=a.id;fillArticle()},a.id===articleId));if(!articleId&&articles.length)articleId=articles[0].id;fillArticle()}
function fillArticle(){const a=articles.find(x=>x.id===articleId)||{};const f=$('article-form');for(const k of ['id','title_ko','title_ja','title_en','body_ko','body_ja','body_en','source_url','status'])field(f,k).value=a[k]|| (k==='status'?'draft':'')}
$('new-article').onclick=()=>{articleId=null;fillArticle();message('새 글은 기본적으로 비공개 상태로 시작합니다.')};
$('article-form').addEventListener('submit',async ev=>{ev.preventDefault();try{const f=ev.currentTarget;const row={};for(const k of ['title_ko','title_ja','title_en','body_ko','body_ja','body_en','source_url','status'])row[k]=formValue(f,k);assertUrl(row.source_url);row.updated_at=new Date().toISOString();if(articleId)row.id=articleId;const {error}=await sb.from('site_articles').upsert(row);if(error)throw error;articleId=null;await refreshAll();message('✅ 글 저장 완료. '+(row.status==='published'?'방문자에게 공개됐습니다.':'임시 저장됐습니다.'))}catch(e){message(e.message,true)}});
$('delete-article').onclick=async()=>{if(!articleId||!confirm('선택한 글을 삭제할까요?'))return;const {error}=await sb.from('site_articles').delete().eq('id',articleId);if(error)return message(error.message,true);articleId=null;await refreshAll();message('글 삭제 완료')};
function proposeEventFromFeed(item){
  const f=$('event-form');
  eventId=''; fillEvent();
  field(f,'title_ko').value=item.title||'';
  field(f,'title_ja').value=item.title||'';
  field(f,'source').value=item.url||'';
  field(f,'status').value='production';
  field(f,'category').value='live';
  field(f,'desc_ko').value='공식 RSS에서 가져온 일정 후보입니다. 날짜·장소·아이코 실제 출연 여부를 반드시 검증한 뒤 저장하세요. ' + (item.description||'').slice(0,350);
  field(f,'desc_ja').value='公式RSSを基にした仮登録です。出演日・会場・キャストを確認してください。';
  const match=String(item.title+' '+(item.description||'')).match(/(20\d{2})[年.\/-]\s*(\d{1,2})[月.\/-]\s*(\d{1,2})(?:日)?/);
  if(match){const ds=match[1]+'-'+match[2].padStart(2,'0')+'-'+match[3].padStart(2,'0');const date=new Date(ds+'T12:00:00Z');if(!Number.isNaN(date.getTime())&&date.toISOString().slice(0,10)===ds)field(f,'date').value=ds;}
  $('tabs').querySelector('[data-tab="events"]').click();
  f.scrollIntoView({behavior:'smooth',block:'start'});
  message('일정 후보를 입력했습니다. 날짜·장소·출연 여부를 확인한 후 「일정 저장」을 눌러야 공개됩니다.');
}
function renderInbox(){const div=$('feed-inbox');div.replaceChildren();if(!inbox.length){div.textContent='아직 수집된 항목이 없습니다. 출처 메뉴에서 기능 연결을 확인하세요.';return}inbox.forEach(x=>{const row=document.createElement('div');row.className='feed-row';const t=document.createElement('div');const title=document.createElement('strong');title.textContent=x.title;const small=document.createElement('small');small.textContent=`${x.source_name} · ${x.published_at?.slice(0,10)||'날짜 미상'} · ${x.status}`;const a=document.createElement('a');const u=safeUrl(x.url);if(u){a.href=u;a.target='_blank';a.rel='noopener noreferrer';a.textContent='원문 확인 ↗'}t.append(title,small,a);const acts=document.createElement('div');acts.className='feed-actions';acts.append(makeButton('📅 일정 후보 작성',()=>proposeEventFromFeed(x)));for(const [status,label] of [['approved','승인·공개'],['rejected','거절'],['pending','대기']]){const b=makeButton(label,async()=>{if(status==='approved'&&!confirm('기사의 출처와 내용을 확인했습니까? 승인하면 방문자에게 바로 공개됩니다.'))return;const {error}=await sb.from('feed_inbox').update({status}).eq('id',x.id);if(error)return message(error.message,true);x.status=status;renderInbox();message('기사 상태 변경 완료: '+label)},status==='approved'?'primary':'');b.disabled=x.status===status;acts.append(b)}row.append(t,acts);div.append(row)})}
$('refresh-inbox').onclick=refreshAll;
function renderSources(){const root=$('sources-list');root.replaceChildren();sourceRows.forEach(s=>{const row=document.createElement('div');row.className='source-row';const left=document.createElement('div');const title=document.createElement('strong');title.textContent=s.name;const u=document.createElement('p');u.textContent=s.url;u.style.overflowWrap='anywhere';const state=document.createElement('span');state.className='badge';state.textContent=s.enabled?'활성':'중지';left.append(title,u,state);const acts=document.createElement('div');acts.className='feed-actions';acts.append(makeButton(s.enabled?'수집 중지':'수집 재개',async()=>{const {error}=await sb.from('feed_sources').update({enabled:!s.enabled}).eq('id',s.id);if(error)return message(error.message,true);await refreshAll()}));acts.append(makeButton('삭제',async()=>{if(!confirm('이 출처를 삭제할까요?'))return;const {error}=await sb.from('feed_sources').delete().eq('id',s.id);if(error)return message(error.message,true);await refreshAll()},'danger'));row.append(left,acts);root.append(row)})}
$('new-source').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget,name=formValue(f,'name'),url=formValue(f,'url');let host;try{const u=new URL(url);host=u.hostname;if(u.protocol!=='https:'||!['mfi-inc.tokyo','ovalsistem.work','www.youtube.com'].includes(host)||u.username||u.password)throw new Error('지원되는 공식 HTTPS 주소만 사용할 수 있습니다.')}catch(err){return message('허용된 공식 RSS URL이 아닙니다.',true)}const {error}=await sb.from('feed_sources').insert({name,url});if(error)return message(error.message,true);f.reset();await refreshAll();message('출처 등록 완료')});
$('collect-now').onclick=async()=>{try{message('공식 피드에서 수집 중…');const {data:{session}}=await sb.auth.getSession();if(!session)throw new Error('다시 로그인하세요.');const response=await fetch('/.netlify/functions/collect-now',{method:'POST',headers:{Authorization:'Bearer '+session.access_token}});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(data.error||'HTTP '+response.status);await refreshAll();message(`✅ 수집 완료 · ${data.inserted||0}건 새 항목 / ${data.checked||0}개 출처 확인 (모두 승인 대기)`) }catch(e){message('수집 실행 실패: '+e.message+' · Netlify Functions와 서버 환경변수를 확인하세요.',true)}};
$('tabs').addEventListener('click',e=>{const b=e.target.closest('button[data-tab]');if(!b)return;document.querySelectorAll('.tabs button').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('[data-pane]').forEach(p=>show(p,p.dataset.pane===b.dataset.tab))});
$('login-form').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;const {error}=await sb.auth.signInWithPassword({email:formValue(f,'email'),password:formValue(f,'password')});if(error){$('login-error').textContent=error.message;return}if(!await verifyAdmin()){await sb.auth.signOut();$('login-error').textContent='등록된 관리자 계정이 아닙니다. schema.sql 안내를 확인하세요.';return}$('login-error').textContent='';await loginState()});
$('logout').onclick=async()=>{await sb.auth.signOut();await loginState()};
if(!configured){show($('setup'),true);show($('login'),false);show($('dashboard'),false)}
else{
 try{
  const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
  sb=createClient(cfg.url,cfg.publishableKey,{auth:{persistSession:true,autoRefreshToken:true}});broadcastEditor=createBroadcastEditor(sb,message);await loginState();
 }catch(error){show($('setup'),true);$('setup').querySelector('p').textContent='Supabase 연결에 실패했습니다. 인터넷 연결, cms-config.js 설정, Supabase 키를 확인하세요. 상세: '+error.message;message(error.message,true)}
}
