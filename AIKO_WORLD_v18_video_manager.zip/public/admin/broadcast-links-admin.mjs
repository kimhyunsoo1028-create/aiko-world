/* 관리자 전용 영상 링크 편집기. 읽기/쓰기 권한은 Supabase RLS에서 강제합니다. */
export function createBroadcastEditor(sb,message){
  const core=window.AIKO_BROADCAST_LINKS;
  const $=id=>document.getElementById(id);
  const records=[];
  for(const e of window.AIKO_EPISODES||[]){
    for(const s of e.songs||[]){records.push({id:core.episodeId(e,s),type:e.show,
      name:s.title||'(곡명 확인 중)',subtitle:`${e.show==='king'?'한일가왕전':'한일톱텐쇼'} ${e.episode}회 · ${e.date}${s.partner?' · '+s.partner:''}`,
      legacy:core.legacyEpisode(s)})}
  }
  for(const x of window.AIKO_TV_SPECIALS||[]){records.push({id:core.specialId(x),type:'special',
    name:x.name,subtitle:`방송 특별 출연 · ${x.date} · ${x.station} · ${(x.songs||[]).join(' / ')||'곡명 확인 중'}`,
    legacy:core.legacySpecial(x)})}
  const changed=new Map();let selectedId=null,dbReady=false;
  const current=()=>records.find(r=>r.id===selectedId);
  const urlsFor=r=>changed.has(r.id)?changed.get(r.id):r.legacy;
  function addRow(item={label:'',url:''}){
    const box=$('video-rows');if(box.children.length>=12){message('한 항목에는 최대 12개 링크를 등록할 수 있습니다.',true);return}
    const row=document.createElement('div');row.className='video-edit-row';
    const labels=typeof item.label==='object'?item.label:{ko:item.label||''};
    const l=document.createElement('label');l.textContent='링크 이름 · 한국어';const name=document.createElement('input');name.className='video-label';name.maxLength=80;name.placeholder='예: MBN MUSIC 공식';name.value=labels.ko||'';l.append(name);
    const lj=document.createElement('label');lj.textContent='링크 이름 · 日本語 (선택)';const ja=document.createElement('input');ja.className='video-label-ja';ja.maxLength=80;ja.value=labels.ja||'';lj.append(ja);
    const le=document.createElement('label');le.textContent='링크 이름 · English (선택)';const en=document.createElement('input');en.className='video-label-en';en.maxLength=80;en.value=labels.en||'';le.append(en);
    const u=document.createElement('label');u.textContent='영상 주소 (HTTPS)';const url=document.createElement('input');url.className='video-url';url.type='url';url.inputMode='url';url.placeholder='https://www.youtube.com/watch?v=...';url.value=item.url||'';u.append(url);
    const del=document.createElement('button');del.type='button';del.className='danger';del.textContent='이 링크 삭제';del.addEventListener('click',()=>row.remove());
    row.append(l,lj,le,u,del);box.append(row);
  }
  function showForm(){
    const r=current(),form=$('video-form');form.hidden=!r;
    if(!r)return;
    $('video-selected-name').textContent=r.name;
    $('video-selected-meta').textContent=r.subtitle;
    $('video-link-mode').textContent=changed.has(r.id)?'관리자 저장값 사용':'기본 내장 링크 사용';
    $('video-rows').replaceChildren();
    const links=urlsFor(r);
    for(const link of links)addRow(link);
    if(!links.length)addRow();
    $('video-reset').disabled=!changed.has(r.id)||!dbReady;
    $('video-save').disabled=!dbReady;
    $('video-hide').disabled=!dbReady;
    $('video-add').disabled=!dbReady;
  }
  function renderList(){
    const group=$('video-filter').value,search=$('video-search').value.trim().toLocaleLowerCase();
    const shown=records.filter(r=>(group==='all'||r.type===group)&&`${r.name} ${r.subtitle}`.toLocaleLowerCase().includes(search));
    $('video-total').textContent=`${shown.length}개 항목 · 전체 ${records.length}개`;
    const root=$('video-list');root.replaceChildren();
    if(!shown.some(x=>x.id===selectedId))selectedId=shown[0]?.id||null;
    for(const r of shown){const li=document.createElement('li'),b=document.createElement('button');b.type='button';b.className=r.id===selectedId?'active':'';b.textContent=r.name;
      const subtitle=document.createElement('small');subtitle.textContent=r.subtitle;
      b.append(subtitle);
      if(changed.has(r.id)){const flag=document.createElement('span');flag.className='badge';flag.textContent='관리자 수정';b.append(flag)}
      b.addEventListener('click',()=>{selectedId=r.id;renderList();showForm()});li.append(b);root.append(li)}
    showForm();
  }
  function readRows(){const rows=[];
    for(const row of $('video-rows').children){const label=row.querySelector('.video-label').value.trim();const ja=row.querySelector('.video-label-ja').value.trim();const en=row.querySelector('.video-label-en').value.trim();const value=row.querySelector('.video-url').value.trim();
      if(!label&&!ja&&!en&&!value)continue;
      const url=core.validUrl(value);
      if(!url)throw new Error('영상 주소는 올바른 HTTPS URL이어야 합니다. HTTP 또는 잘못된 주소는 저장할 수 없습니다.');
      rows.push({label:{ko:(label||ja||en||'영상 보기').slice(0,80),ja:ja.slice(0,80),en:en.slice(0,80)},url});
    }
    if(rows.length>12)throw new Error('최대 12개 영상만 등록할 수 있습니다.');
    return rows;
  }
  async function save(links){
    if(!dbReady)throw new Error('먼저 Supabase에 v18 전용 테이블을 생성하세요.');
    const r=current();if(!r)throw new Error('방송 항목을 선택해 주세요.');
    const {error}=await sb.from('broadcast_video_links').upsert({id:r.id,links,updated_at:new Date().toISOString()},{onConflict:'id'});
    if(error)throw error;
    changed.set(r.id,links);renderList();message(`✅ ${r.name} 영상 링크 ${links.length}개 저장 완료 · 일반 홈페이지 새로고침 시 반영됩니다.`);
  }
  $('video-form').addEventListener('submit',async e=>{e.preventDefault();try{await save(readRows())}catch(e){message('영상 링크 저장 실패: '+e.message,true)}});
  $('video-hide').addEventListener('click',async()=>{if(!confirm('이 항목의 공개 영상 링크를 모두 숨길까요? 방송 기록과 곡명은 유지됩니다.'))return;try{await save([])}catch(e){message('링크 숨김 실패: '+e.message,true)}});
  $('video-reset').addEventListener('click',async()=>{const r=current();if(!r||!confirm('관리자가 수정한 링크를 삭제하고 원래 ZIP의 링크로 되돌릴까요?'))return;
    try{const {error}=await sb.from('broadcast_video_links').delete().eq('id',r.id);if(error)throw error;changed.delete(r.id);renderList();message('기본 링크로 복원했습니다. 홈페이지 새로고침 시 반영됩니다.')}
    catch(e){message('복원 실패: '+e.message,true)}
  });
  $('video-add').onclick=()=>addRow();
  $('video-search').addEventListener('input',renderList);$('video-filter').addEventListener('change',renderList);
  async function load(){
    const {data,error}=await sb.from('broadcast_video_links').select('id,links').limit(2000);
    if(error){dbReady=false;changed.clear();renderList();$('video-help').textContent='⚠️ 영상 링크 테이블 연결 실패: '+error.message+' · ZIP 안의 AIKO_WORLD_v18_영상링크_DB설정.sql을 Supabase SQL Editor에서 먼저 실행하세요.';return}
    dbReady=true;changed.clear();for(const item of data||[]){if(typeof item.id==='string'&&Array.isArray(item.links))changed.set(item.id,core.sanitize(item.links))}
    $('video-help').textContent='선택한 방송/곡에 영상 주소를 최대 12개까지 추가할 수 있습니다. 저장 즉시 공개 데이터가 바뀌며 방문자는 새로고침 후 확인할 수 있습니다. 영상 링크가 맞는지는 직접 확인해 주세요.';
    renderList();
  }
  renderList();
  return {load};
}
