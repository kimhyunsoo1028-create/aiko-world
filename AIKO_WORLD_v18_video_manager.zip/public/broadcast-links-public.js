/* Public: fetch approved admin-edited video links (only links; never use a secret key). */
(async()=>{'use strict';
  const core=window.AIKO_BROADCAST_LINKS;
  if(!core)return;
  await (window.AIKO_CMS_READY||Promise.resolve());
  const cfg=window.AIKO_CMS_CONFIG||{};
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')||!cfg.publishableKey)return;
  try{
    const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),8000);
    let response;
    try {
      response=await fetch(cfg.url.replace(/\/$/,'')+'/rest/v1/broadcast_video_links?select=id,links&limit=2000',{
        headers:{apikey:cfg.publishableKey,...(cfg.publishableKey.startsWith('eyJ')?{Authorization:'Bearer '+cfg.publishableKey}:{})},
        signal:controller.signal,cache:'no-store'
      });
    }finally{clearTimeout(timeout)}
    if(!response.ok)throw new Error('HTTP '+response.status);
    core.apply(await response.json());
  }catch(error){console.warn('AIKO WORLD: broadcast link overrides unavailable; showing built-in links.',error)}
})();
