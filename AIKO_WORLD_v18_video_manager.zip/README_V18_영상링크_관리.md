# AIKO WORLD v1.8 — 방송 무대 영상 링크 관리자 기능

기준: 기존 v17 관리자 인증, 공연 일정, 사진, 뉴스, RSS 자동 수집, 서버 함수 5개, 기존 영상 목록과 디자인을 유지합니다. 새 버전은 **방송별/곡별 영상 링크 수정·추가·삭제(숨김)·복원**에만 기능을 추가합니다.

## 무엇이 추가됐나요?

- `/admin/`에 **🎬 방송 영상** 탭
- 한일가왕전 / 한일톱텐쇼 곡별 조회·검색, 기타 한국/일본 방송(럭키팡팡 포함) 방송별 조회·검색
- 개별 항목마다 최대 12개의 HTTPS 영상 링크 추가, 편집, 개별 제거
- 링크 표시 이름 한국어/일본어/영어 지원 (일본어·영어는 미입력 시 한국어로 표시)
- **모두 숨기기** = 방송 기록/곡명 유지, 링크만 숨김
- **기존 기본 링크 복원** = 관리자가 저장한 링크를 삭제하고 ZIP의 원래 링크 사용
- 저장 후 방문자 홈페이지의 방송 무대 및 기타 방송 출연 목록에 바로 반영 (방문자가 새로고침)
- 새 링크는 Supabase `broadcast_video_links` 테이블에 저장됨. GitHub에 다시 올리지 않아도 이후 수정 반영.

## 순서 1 — Supabase SQL (최초 한 번만)

1. https://supabase.com/dashboard → 기존 프로젝트 → SQL Editor → New query
2. ZIP 안의 `AIKO_WORLD_v18_영상링크_DB설정.sql` **전체를 복사**하여 Run
3. `Success`가 표시되고 마지막 SELECT 결과가 0행이면 정상 (아직 변경한 링크가 없다는 뜻)

**주의:** 이 SQL은 방송 전용 새 테이블에만 권한을 부여하며 기존 관리자/기사 테이블에 `anon` 권한을 추가하지 않습니다. `public.is_site_admin()`은 기존 v17에 생성되어 있어야 합니다.

## 순서 2 — GitHub 업로드

1. `AIKO_WORLD_v18_video_manager.zip` 파일을 GitHub `kimhyunsoo1028-create/aiko-world`의 **main 브랜치**에 업로드해 Commit
2. 기존 `AIKO_WORLD_v17_admin_key_fix.zip`은 삭제하지 마세요 (백업)

## 순서 3 — 기존 Netlify 사이트에 배포

1. Netlify → `creative-melomakarona-e53d52` → Project configuration → Developer settings → Build settings → Edit settings
2. **Build command**를 아래와 같이 변경:

   `unzip -o AIKO_WORLD_v18_video_manager.zip`

3. Publish directory `public`, Functions directory `netlify/functions`는 유지
4. Save → Deploys → Trigger deploy → Deploy project
5. 배포 결과 `Published` 및 `5 functions deployed` 확인

이 프로젝트의 ZIP 배포 방식은 Github 저장소에 ZIP 파일을 올린 뒤 Build command로 압축을 해제합니다. Netlify 환경변수 `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY`는 **기존 값을 유지**합니다. 키를 파일에 넣으면 안 됩니다.

## 순서 4 — 링크 수정

1. 관리자: https://creative-melomakarona-e53d52.netlify.app/admin/
2. 로그인 → **🎬 방송 영상** 탭
3. 프로그램 선택, 곡명이나 회차 검색, 왼쪽에서 영상 선택
4. 각 영상의 링크 이름(선택)과 실제 HTTPS 영상 주소 입력
5. 필요하면 `+ 영상 링크 추가`로 두 번째, 세 번째 영상 등록
6. **영상 링크 저장 · 즉시 공개** 클릭
7. 일반 홈페이지 https://creative-melomakarona-e53d52.netlify.app/#broadcast-archive 에서 새로고침 후 확인

`저장`에 성공했는데 홈페이지에 표시되지 않으면 브라우저 Ctrl+F5 후 개발자 도구의 Supabase `broadcast_video_links` 조회 오류를 점검하세요. Supabase RLS는 기존 관리자만 쓰고 방문자는 읽는 방식입니다.

## 한계·주의

- URL만 관리합니다. 외부 영상이 삭제/비공개/지역 제한된 경우에는 해당 플랫폼에서 재생되지 않습니다.
- 저장할 때 HTTPS 주소 형식만 검사하며 **영상이 실제 아이코 무대인지 자동 검증하지 않습니다**.
- 이미 사이트에 들어 있는 방송 기록/곡명은 그대로 유지합니다. 새 방송 편성표나 곡 추가 기능은 별도 개발이 필요합니다.
- Supabase 신규 테이블을 만들지 않아도 기존 홈페이지는 작동하지만 새로운 링크 관리 기능은 작동하지 않습니다.
- 이미 외부에 노출된 Supabase 비밀 키는 반드시 Supabase에서 교체하세요. 비밀 키를 캡처해 전달하지 마세요.
