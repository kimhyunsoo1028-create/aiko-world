/* AIKO WORLD v27 unified stage editor. Run after v24. Data is never mutated at install time. */
'use strict';
const fs=require('node:fs');
const required=['public/admin/index.html','public/admin/concert-stories-admin.mjs','public/admin/concert-admin.mjs','public/admin/stage-admin-hub.mjs'];
for(const f of required)if(!fs.existsSync(f))throw Error('[v27] missing '+f+' (install v21/v22 and v24 first)');
const target='public/admin/index.html';let html=fs.readFileSync(target,'utf8');
for(const tag of ['<link rel="stylesheet" href="stage-unified-v27.css">','<script type="module" src="stage-unified-v27.mjs"></script>']) {
 if(!html.includes(tag)){const before=tag.startsWith('<link')?'</head>':'</body>';if(!html.includes(before))throw Error('[v27] missing '+before);html=html.replace(before,tag+'\n'+before)}
}
fs.writeFileSync(target,html);console.log('[v27] unified admin linked; all existing records and menus remain in place. No SQL/data changes.');
