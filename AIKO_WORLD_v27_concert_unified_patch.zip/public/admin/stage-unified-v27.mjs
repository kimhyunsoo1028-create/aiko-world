/* AIKO WORLD v27: one writable concert_stories record per show; original legacy archive read-only.
   All writes require a logged-in site administrator. All legacy data is preserved.
*/
'use strict';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let root,tab,oldTabs;
for(let i=0;i<150;i++){
 const pane=document.querySelector('[data-pane="stagehub"]');
 const tabs=document.getElementById('tabs');
 if(pane&&tabs?.querySelector('[data-tab="concertstories"]')&&tabs.querySelector('[data-tab="concert"]')){root=pane;tab=tabs.querySelector('[data-tab="stagehub"]');oldTabs=tabs;break}
 await sleep(100);
}
if(root&&tab){
 const $=id=>document.getElementById(id);
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clean=s=>String(s??'').trim();
 const validUrl=s=>{try{const u=new URL(s);return u.protocol==='https:'&&!u.username&&!u.password?u.href:''}catch{return ''}};
 const norm=s=>clean(s).toLocaleLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
 const category=s=>({solo:'solo',rent:'rent',tour:'yamanotation',kichijoji:'oval',orbit:'oval',seoul:'oval',festival:'festival'}[s]||'other');
 const make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
 root.id='stagehub-v27';
 root.innerHTML=`<div class="section-head"><div><h2>🎤 공연 통합 관리</h2><p>공연별 제목·설명(한·일·영), 세트리스트, 사진 및 영상 등록을 한 곳에서 관리합니다.</p></div><a href="../#concert-archive" target="_blank" rel="noopener noreferrer">홈페이지 보기 ↗</a></div>
 <p class="s27-lead">기존 공연 기록과 세트리스트를 불러와 연결합니다. <b>저장은 공연별 통합 기록(concert_stories)에만 수행</b>하며, 기존 공연 목록·캘린더·사진·영상은 삭제하지 않습니다.</p>
 <div class="s27-actions"><button id="s27-refresh" type="button">↻ 목록 새로고침</button><button id="s27-create" type="button">+ 새 공연</button><button id="s27-backup" type="button">⬇ 기존 자료 JSON 백업</button></div>
 <div class="s27-workspace"><aside class="s27-sidebar"><label>공연 검색<input id="s27-search" type="search" placeholder="날짜·제목·장소"></label><p id="s27-count" class="s27-list-note"></p><ul id="s27-list" class="s27-list"></ul></aside>
 <div class="s27-editor"><form id="s27-form"><input type="hidden" name="id"><input type="hidden" name="source_performance_id"><p class="s27-muted" id="s27-origin">공연을 선택해 주세요.</p><label>기존 공연 기록과 연결 (선택사항)<select id="s27-link-source"><option value="">연결 없음 · 새로운 공연</option></select></label>
 <div class="s27-grid"><label>공연 날짜<input type="date" name="show_date" required></label><label>공연 시작 시간<input type="time" name="show_time"></label><label>공연 분류<select name="category"><option value="solo">아이코 솔로</option><option value="oval">OVAL SISTEM</option><option value="yamanotation">야마노테이션</option><option value="rent">RENT</option><option value="festival">페스티벌</option><option value="other">기타</option></select></label><label>공연 장소<input name="venue" maxlength="180"></label></div>
 <label>공연명 (한국어)<input name="title_ko" maxlength="200" required></label><label>공연명 (일본어)<input name="title_ja" maxlength="200"></label><label>공연명 (영어)<input name="title_en" maxlength="200"></label><label>공연 정보 출처 HTTPS<input type="url" name="source_url" placeholder="https://..."></label>
 <fieldset><legend>공연 설명 (한국어·일본어·영어)</legend><label>한국어<textarea name="description_ko" maxlength="1500" rows="3"></textarea></label><label>日本語<textarea name="description_ja" maxlength="1500" rows="3"></textarea></label><label>English<textarea name="description_en" maxlength="1500" rows="3"></textarea></label></fieldset>
 <fieldset><legend>🎼 세트리스트</legend><label>한 줄에 한 곡씩<textarea name="setlist" rows="8" placeholder="01. いのちの名前&#10;02. もしもピアノが弾けたなら"></textarea></label><div class="s27-grid"><label>확인 상태<select name="setlist_status"><option value="pending">확인 중</option><option value="fan">팬 현장 기록</option><option value="confirmed">출처 확인</option></select></label><label>세트리스트 출처 HTTPS<input name="setlist_source" type="url" placeholder="https://..."></label></div></fieldset>
 <fieldset><legend>📷 사진 · 🎥 영상</legend><p class="s27-muted">사진·영상 링크를 여러 개 연결할 수 있습니다. 파일은 권한 확인 후 업로드하며, 공연 저장을 눌러야 최종 연결됩니다.</p><div id="s27-medias"></div><div class="s27-actions"><button type="button" id="s27-add-photo">+ 사진 링크</button><button type="button" id="s27-add-video">+ 영상 링크</button></div><div class="s27-grid"><label>사진/영상 파일 선택<input id="s27-file" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"></label><label>촬영자·제공처<input id="s27-credit" maxlength="200" placeholder="직접 촬영 / 공식 제공"></label></div><label><input id="s27-consent" type="checkbox"> 이 공연의 자료이며 게시 및 촬영 권한을 확인했습니다.</label><button type="button" id="s27-upload">파일 업로드 (사진 5MB / 영상 45MB)</button><p class="s27-warning">파일 업로드는 저장소에 파일을 만들지만, 공연 저장 전에 취소하면 미연결 파일이 남을 수 있습니다.</p></fieldset>
 <label><input type="checkbox" name="is_published"> 확인된 기록만 방문자에게 공개</label><div class="s27-actions"><button type="submit" class="primary" id="s27-save">통합 공연 기록 저장</button><button type="button" id="s27-delete" class="danger">통합 기록 삭제</button></div><p class="s27-warning">삭제는 통합 기록(concert_stories)에만 적용하며, 기존 공연·캘린더·업로드 파일은 삭제하지 않습니다.</p></form></div></div><p id="s27-status" class="s27-status" role="status"></p>`;
 const form=$('s27-form'),f=k=>form.elements.namedItem(k),v=k=>clean(f(k)?.value),set=(k,val)=>{if(f(k))f(k).value=val??''};
 const cfg=window.AIKO_CMS_CONFIG||{};let sb=null,legacy=[],stories=[],items=[],selected=null,loading=false,archivePayload=null;
 const notify=(s,error=false)=>{const e=$('s27-status');e.textContent=s;e.classList.toggle('error',error);e.classList.toggle('ok',!error)};
 const catalog=()=>Array.isArray(window.AIKO_PERFORMANCES)?window.AIKO_PERFORMANCES:[];
 async function client(){
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')||!cfg.publishableKey)throw Error('Supabase 연결 설정이 없습니다.');
  if(!sb){const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');sb=createClient(cfg.url,cfg.publishableKey,{auth:{persistSession:true,autoRefreshToken:true}})}
  const {data:{user},error}=await sb.auth.getUser();if(error||!user)throw Error('관리자 로그인 후 다시 선택하세요.');
  const {data,error:e}=await sb.from('site_admins').select('user_id').eq('user_id',user.id).maybeSingle();if(e||!data)throw Error('관리자 권한을 확인할 수 없습니다.');return sb;
 }
 function match(st,lg){
  if(st?.source_performance_id&&lg?.id===st.source_performance_id)return true;
  if(!lg||!st||st.show_date!==lg.date)return false;
  // Do not combine two matinee/evening performances merely because date and venue match.
  if(!st.show_time||!lg.time||st.show_time!==lg.time)return false;
  const tn=[st.title_ko,st.title_ja,st.title_en].map(norm).filter(Boolean);
  return !!(norm(lg.title)&&tn.includes(norm(lg.title))&&norm(st.venue)&&norm(st.venue)===norm(lg.venue)&&st.show_time===lg.time);
 }
 function rebuild(){
  const all=[...stories.map(s=>({type:'story',key:'story:'+s.id,story:s,legacy:null}))];const used=new Set();
  for(const lg of legacy){const matches=all.filter(x=>match(x.story,lg));if(matches.length===1&&!used.has(matches[0].key)){matches[0].legacy=lg;used.add(matches[0].key)}else all.push({type:'legacy',key:'legacy:'+lg.id,story:null,legacy:lg});}
  items=all.sort((a,b)=>String(b.story?.show_date||b.legacy?.date||'').localeCompare(String(a.story?.show_date||a.legacy?.date||'')));
 }
 function render(){const q=vSearch();const display=items.filter(x=>[x.story?.show_date||x.legacy?.date,x.story?.title_ko,x.story?.title_ja,x.legacy?.title,x.story?.venue,x.legacy?.venue].join(' ').toLocaleLowerCase().includes(q));$('s27-count').textContent=`공연 ${items.length}건 · 검색 결과 ${display.length}건 · 통합 저장 ${stories.length}건`;$('s27-list').replaceChildren();for(const x of display){const li=make('li'),b=make('button');b.type='button';b.classList.toggle('active',x.key===selected?.key);b.textContent=`${x.story?.show_date||x.legacy?.date||''} · ${x.story?.title_ko||x.story?.title_ja||x.legacy?.title||'제목 없음'}`;b.append(make('small',null,x.story?(x.story.is_published?'공개':'초안')+' · 세트리스트 '+(x.story.setlist?.length||0)+'곡': '기존 공연 · 통합 기록 미등록'));b.onclick=()=>choose(x);li.append(b);$('s27-list').append(li)}}
 function vSearch(){return clean($('s27-search').value).toLocaleLowerCase()}
 function addMedia(data={}){
  if($('s27-medias').children.length>=30){notify('한 공연에 30개까지만 추가할 수 있습니다.',true);return}
  const m=make('div','s27-media-item');m.innerHTML=`<div class="s27-grid"><label>종류<select data-key="kind"><option value="photo">사진</option><option value="video">영상</option></select></label><label>제목<input data-key="caption" maxlength="180"></label><label>출처·촬영자<input data-key="credit" maxlength="200"></label><label>URL (HTTPS)<input type="url" data-key="url" placeholder="https://..."></label></div><label><input type="checkbox" data-key="permission"> 촬영·공개 권한 확인</label><button type="button" data-remove>항목 제거</button>`;
  const e=k=>m.querySelector(`[data-key="${k}"]`);for(const k of ['kind','caption','credit','url'])e(k).value=data[k]||(k==='kind'?'photo':'');e('permission').checked=data.permission===true;
  m.querySelector('[data-remove]').onclick=()=>m.remove();$('s27-medias').append(m);
 }
 function fill(row,source){form.reset();$('s27-medias').replaceChildren();const r=row||{};const lg=source||{};
  for(const k of ['id','source_performance_id','show_date','show_time','category','title_ko','title_ja','title_en','venue','description_ko','description_ja','description_en','source_url','setlist_status','setlist_source'])set(k,r[k]||'');
  if(source&&!row){set('show_date',lg.date);set('show_time',/^\d\d:\d\d$/.test(lg.time||'')?lg.time:'');set('category',category(lg.series));set('title_ko',lg.title);set('title_ja',lg.title);set('title_en',lg.title);set('venue',lg.venue);set('description_ko',lg.description);set('source_url',lg.source);set('source_performance_id',lg.id);set('setlist_source',lg.setsrc);set('setlist_status',lg.setlist?.length?'fan':'pending')}
  $('s27-link-source').value=v('source_performance_id');
  if(!v('category'))set('category','solo');if(!v('setlist_status'))set('setlist_status','pending');
  f('setlist').value=(Array.isArray(r.setlist)?r.setlist:Array.isArray(lg.setlist)?lg.setlist:[]).join('\n');
  f('is_published').checked=r.is_published===true;
  const media=Array.isArray(r.media)?r.media:(!row&&Array.isArray(lg.media)?lg.media.filter(m=>m.verified&&validUrl(m.url)).map(m=>({kind:'video',url:m.url,caption:m.title,credit:m.credit,permission:true})):[]);
  for(const m of media)addMedia(m);
  $('s27-delete').disabled=!r.id;
  $('s27-origin').textContent=r.id?`통합 기록 편집 · ID: ${r.id}${source?' · 기존 공연과 연결됨':''}`:source?`기존 공연 원본: ${source.id} · 저장하면 연결된 통합 기록을 생성합니다.`:'새 공연 (비공개 초안)';
 }
 function choose(x){selected=x;fill(x.story,x.legacy);render();notify(x.story?'통합 공연 기록을 불러왔습니다.':'기존 공연 정보를 불러왔습니다. 세트리스트·사진·영상 저장 시 통합 기록으로 연결합니다.')}
 function unsaved(){selected={key:'new',type:'new',story:null,legacy:null};fill();render();notify('새 공연은 저장 전까지 공개되지 않습니다.')}
 async function load(){if(loading)return;loading=true;try{await client();notify('기존 공연 및 통합 자료를 읽고 있습니다…');const [a,b]=await Promise.all([sb.from('site_content').select('payload').eq('key','concert_archive').maybeSingle(),sb.from('concert_stories').select('*').order('show_date',{ascending:false}).limit(1000)]);if(a.error)throw a.error;if(b.error)throw b.error;
   archivePayload=a.data?.payload??null;const overrides=Array.isArray(archivePayload?.records)?archivePayload.records:[];const map=new Map(catalog().filter(c=>c.id).map(c=>[c.id,{...c}]));for(const row of overrides)if(row?.id)map.set(row.id,{...(map.get(row.id)||{}),...row});legacy=[...map.values()];stories=b.data||[];
   const select=$('s27-link-source');select.replaceChildren();const empty=make('option',null,'연결 없음 · 새로운 공연');empty.value='';select.append(empty);
   for(const lg of [...legacy].sort((a,b)=>String(b.date).localeCompare(String(a.date)))){const op=make('option',null,`${lg.date} · ${lg.title} · ${lg.time||'시간 미상'}`);op.value=lg.id;select.append(op)}
   rebuild();const focus=items.find(x=>x.story?.id&&x.story.id===selected?.story?.id)||items.find(x=>x.legacy?.id&&x.legacy.id===selected?.legacy?.id);if(focus)choose(focus);else if(items.length)choose(items[0]);else unsaved();notify(`✅ 공연 ${items.length}건을 조회했습니다. 원본 공연 기록은 수정하지 않았습니다.`);
  }catch(e){notify('자료 불러오기 실패: '+e.message+' · 기존 관리자 메뉴에서 정상 연결되는지 확인하세요.',true)}finally{loading=false}}
 function parse(){const date=v('show_date');if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(date+'T12:00:00Z')))throw Error('공연 날짜를 확인하세요.');if(!v('title_ko'))throw Error('한국어 공연 제목을 입력하세요.');if(f('is_published').checked&&!v('venue'))throw Error('공개 공연은 장소가 필요합니다.');
  for(const key of ['source_url','setlist_source'])if(v(key)&&!validUrl(v(key)))throw Error(key+'는 올바른 HTTPS URL이어야 합니다.');const lines=v('setlist').split(/\r?\n/).map(clean).filter(Boolean);if(lines.length>100)throw Error('세트리스트는 100곡 이하로 입력하세요.');if(v('setlist_status')==='confirmed'&&lines.length&&!v('setlist_source'))throw Error('출처 확인 상태라면 세트리스트 근거 URL이 필요합니다.');
  const media=[];for(const el of $('s27-medias').children){const g=k=>el.querySelector(`[data-key="${k}"]`),url=validUrl(clean(g('url').value)),credit=clean(g('credit').value);if(!url)throw Error('첨부 자료 URL은 HTTPS여야 합니다.');if(!g('permission').checked)throw Error('사진·영상의 공개 권한을 확인하세요.');if(!credit)throw Error('자료 출처·촬영자를 입력하세요.');media.push({kind:g('kind').value,caption:clean(g('caption').value),credit,url,permission:true})}
  return {source_performance_id:v('source_performance_id')||null,show_date:date,show_time:v('show_time'),category:v('category')||'other',title_ko:v('title_ko'),title_ja:v('title_ja'),title_en:v('title_en'),venue:v('venue'),description_ko:v('description_ko'),description_ja:v('description_ja'),description_en:v('description_en'),source_url:v('source_url'),setlist:lines,setlist_status:v('setlist_status'),setlist_source:v('setlist_source'),media,is_published:f('is_published').checked,updated_at:new Date().toISOString(),...(v('id')?{id:v('id')}:{})};
 }
 async function save(ev){ev.preventDefault();const btn=$('s27-save');try{await client();const row=parse();
  // The unique source ID prevents creation of a second story for the same verified source performance.
  if(row.source_performance_id){const lg=legacy.find(x=>x.id===row.source_performance_id);if(!lg&&(!row.id||!stories.some(s=>s.id===row.id&&s.source_performance_id===row.source_performance_id)))throw Error('연결할 원본 공연 기록을 찾을 수 없습니다. 다시 새로고침하세요.');if(lg&&lg.date!==row.show_date)throw Error('원본 공연과 날짜가 다릅니다. 날짜를 확인하세요.');if(lg&&lg.time&&row.show_time&&lg.time!==row.show_time)throw Error('원본 공연과 시작 시간이 다릅니다. 다른 회차인지 확인하세요.');}
  if(!row.id&&row.source_performance_id&&stories.some(s=>s.source_performance_id===row.source_performance_id))throw Error('이미 연결된 공연이 있습니다. 새로고침하여 기존 기록을 선택하세요.');
  if(!row.id){const same=stories.filter(s=>s.show_date===row.show_date&&norm(s.title_ko)===norm(row.title_ko)&&norm(s.venue)===norm(row.venue)&&(!s.show_time||!row.show_time||s.show_time===row.show_time));if(same.length)throw Error('같은 날짜·제목·장소의 통합 기록이 이미 있습니다. 기존 기록을 열어서 수정하세요.');}
  btn.disabled=true;notify('통합 기록 저장 중…');const {data,error}=await sb.from('concert_stories').upsert(row).select('id').single();if(error)throw error;selected={story:{id:data.id},legacy:selected?.legacy};await load();notify('✅ 통합 공연 기록 저장 완료. 기존 공연 기록·일정·미디어는 유지됩니다.');
 }catch(e){notify('저장 실패: '+e.message,true)}finally{btn.disabled=false}}
 async function upload(){const file=$('s27-file').files?.[0];try{await client();if(!file)throw Error('파일을 선택하세요.');if(!$('s27-consent').checked)throw Error('게시 및 촬영 권한 확인이 필요합니다.');const credit=clean($('s27-credit').value);if(!credit)throw Error('출처 또는 촬영자를 입력하세요.');const image={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'},video={'video/mp4':'mp4','video/webm':'webm'};
  const photo=!!image[file.type],ext=image[file.type]||video[file.type];if(!ext)throw Error('JPG/PNG/WebP 또는 MP4/WebM 파일만 지원합니다.');if(!file.size||file.size>(photo?5:45)*1024*1024)throw Error(photo?'사진은 5MB 이하입니다.':'영상은 45MB 이하입니다.');
  const bucket=photo?'site-media':'concert-videos';const path=photo?`concert-stories/${crypto.randomUUID()}.${ext}`:`performances/unified/${crypto.randomUUID()}.${ext}`;notify('파일 업로드 중…');$('s27-upload').disabled=true;
  const {error}=await sb.storage.from(bucket).upload(path,file,{contentType:file.type,upsert:false});if(error)throw error;const {data}=sb.storage.from(bucket).getPublicUrl(path);if(!validUrl(data.publicUrl))throw Error('업로드 주소를 확인할 수 없습니다.');addMedia({kind:photo?'photo':'video',url:data.publicUrl,caption:file.name.replace(/\.[^.]+$/,''),credit,permission:true});$('s27-file').value='';$('s27-consent').checked=false;notify('✅ 파일이 업로드되었습니다. 반드시 통합 공연 기록 저장을 눌러 연결하세요.');
 }catch(e){notify('업로드 실패: '+e.message,true)}finally{$('s27-upload').disabled=false}}
 function download(){if(!stories.length&&!legacy.length){notify('먼저 관리자 로그인 후 기존 데이터를 불러오세요.',true);return}const payload={created_at:new Date().toISOString(),note:'Browser snapshot: legacy concert_archive (readonly) and concert_stories. Not a live database backup.',legacy_concert_archive_payload:archivePayload,legacy_merged_catalog:legacy,concert_stories:stories};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=make('a');a.href=u;a.download='AIKO_WORLD_공연통합_백업_'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);notify('백업 JSON 파일을 생성했습니다. 저장 여부를 확인하세요.')}
 async function drop(){if(!v('id'))return;const expected=v('title_ko');if(!confirm('통합 기록만 삭제할까요? 기존 공연·일정·사진 파일은 그대로 남습니다.'))return;if(prompt('삭제할 공연 제목을 정확히 입력해 주세요.')!==expected)return notify('삭제를 취소했습니다.');try{await client();const {error}=await sb.from('concert_stories').delete().eq('id',v('id'));if(error)throw error;selected=null;await load();notify('선택한 통합 기록만 삭제했습니다. 원본 공연과 파일은 유지됩니다.')}catch(e){notify('삭제 실패: '+e.message,true)}}
 $('s27-link-source').addEventListener('change',e=>set('source_performance_id',e.target.value));$('s27-search').addEventListener('input',render);$('s27-refresh').onclick=load;$('s27-create').onclick=unsaved;$('s27-backup').onclick=download;$('s27-add-photo').onclick=()=>addMedia({kind:'photo'});$('s27-add-video').onclick=()=>addMedia({kind:'video'});$('s27-upload').onclick=upload;$('s27-delete').onclick=drop;form.addEventListener('submit',save);tab.addEventListener('click',()=>{if(!loading&&!stories.length)load()});
 // Keep legacy fallback screens in the DOM, but remove redundant choices from the navigation.
 for(const x of ['concert','concertstories']){const button=oldTabs.querySelector(`[data-tab="${x}"]`);if(button){button.hidden=true;button.style.setProperty('display','none','important');button.setAttribute('aria-hidden','true');button.tabIndex=-1}}
 tab.textContent='🎤 공연 통합 관리';
 // Remove the two old shortcut cards from v23's dashboard as well.
 const shortcuts=$('v23-shortcuts');
 if(shortcuts){
  for(const button of shortcuts.querySelectorAll('button')){
   const label=button.querySelector('strong')?.textContent||'';
   if(label.includes('공연 상세·영상')||label.includes('공연별 세트리스트·사진'))button.style.setProperty('display','none','important');
  }
  if(!shortcuts.querySelector('[data-v27-shortcut]')){
   const link=make('button','v23-card');link.type='button';link.dataset.v27Shortcut='true';
   const title=make('strong',null,'🎤 공연 통합 관리');const sub=make('small',null,'공연 소개, 세트리스트, 사진과 영상을 한 번에 편집');
   link.append(title,sub);link.addEventListener('click',()=>tab.click());shortcuts.prepend(link);
  }
 }
 console.info('[AIKO WORLD v27] unified editor loaded; v21/v22 legacy panels kept for recovery.');
}
