AIKO WORLD v27 — 공연 통합 관리자 (중복 입력 방지 패치)
===================================================

무엇을 바꾸나요?
- 관리자에 기존의 🎤 공연별 상세 기록 · 영상 등록 및 🎼 공연별 세트리스트 · 사진 · 영상의 중복 메뉴를 숨기고
  🎤 공연 통합 관리 화면 하나를 제공합니다.
- 기존 공연 기록 목록(concert_archive)을 읽어서 공연을 선택하고,
  기존 공연별 상세자료(concert_stories)가 있으면 같은 공연으로 연결해서 편집합니다.
- 수정·신규 세트리스트, 공연 설명(한/일/영), 사진·영상 링크 및 직접 업로드를
  concert_stories 한 곳에만 새로 저장합니다.
- 원본 공연의 정보와 별도 공연 스토리 중 같은 날짜+시간+장소+제목이 일치하는 경우만 연결합니다.
  source_performance_id가 있으면 이를 우선합니다. 시간 정보가 모호한 공연은 수동 연결할 수 있습니다.
- 사진은 site-media 버킷에 최대 5MB (JPG/PNG/WebP), 영상 파일은 concert-videos 버킷에
  최대 45MB (MP4/WebM)를 업로드합니다. 기존 영상 업로드 권한과 저장소 설정을 이용합니다.
- 기존 공연을 선택해 노래·사진·영상이 이미 있다면 자동으로 해당 통합 자료를 엽니다.
  아직 통합 자료가 없는 공연이면 기존 제목/날짜/장소 등을 불러와 새 초안을 작성합니다.

매우 중요 — 보존 범위
- 기존 Supabase concert_archive, concert_stories, events, history_media, 일정, 사진/영상 파일은
  패치 설치 시 삭제·초기화·수정되지 않습니다.
- 신규/수정 저장은 concert_stories 테이블에만 반영됩니다.
  원본 concert_archive의 필드는 읽기 전용으로 보존됩니다.
- 기존 두 편집 패널 코드는 유지하며 관리자 상단 탭에서만 숨깁니다(문제 발생 시 복구 가능).
- 기존 방문자 화면에는 v24의 공연 목록/세트리스트 아카이브 탭이 그대로 유지됩니다.
  이번 패치는 관리자의 '중복 입력'을 줄이는 안전한 1차 통합이며,
  물리적으로 Supabase 데이터 테이블을 하나로 합치거나 중복 기록을 삭제하는 패치는 아닙니다.
- 행사 날짜만 같다고 자동으로 공연을 병합하지 않습니다. 다른 회차가 섞일 수 있기 때문입니다.
- 보안 키, 인증 정보는 프로젝트 파일에 추가하지 않았습니다.

설치 방법 (기존 설치 순서 유지)
1) https://github.com/kimhyunsoo1028-create/aiko-world 접속
2) Code → Add file → Upload files → AIKO_WORLD_v27_concert_unified_patch.zip 파일 그대로 업로드 → Commit
   (압축을 풀어 올리는 방식이 아닙니다. 기존 ZIP과 소스는 삭제하지 마세요.)
3) Netlify → 해당 프로젝트 → Project configuration → Build settings → Build command 편집
4) 기존 명령 전체를 백업하고, 현재 사용 중인 모든 기존 명령의 **맨 마지막에** 아래를 한 번만 추가:

   && unzip -o AIKO_WORLD_v27_concert_unified_patch.zip && node install-aiworld-v27.cjs

5) 기존 v21/v22, v24 및 v26 설치 명령은 유지합니다.
6) GitHub Commit으로 Netlify 자동 배포됨 → Deploys → Published 확인
7) https://aiko-world.com/admin/ 접속, 로그인 후 '🎤 공연 통합 관리' 선택
8) 첫 단계 '⬇ 기존 자료 JSON 백업' 누르고 안전한 곳에 보관
9) '2025-03-01 住田愛子 First Solo Concert' 선택 → 기존 정보 확인
   → 세트리스트 12곡 입력 → 한국어/일본어/영어 소개 입력 → 비공개로 먼저 저장
   → 미리보기 후 공개 전환

설치에 따른 SQL 실행: 없음. 기존 concert_stories + site-media + concert-videos 설정이 필요합니다.

검수
- Node.js --check 통과 (installer / module)
- 기존 v21 기본 프로젝트 + v21/v22 + v24(+v23) + v26 + v27 통합 빌드 시뮬레이션 성공
- 설치 스크립트 2회 실행시 CSS/JS 참조가 중복 삽입되지 않음
- 실제 운영 중인 GitHub, Supabase 자료, 로그인, 업로드, 배포 및 브라우저 동작은 연결하지 않아 검증하지 못했습니다.
- 오류가 발생하면 Netlify Build command 끝에 추가한 v27 부분만 제거하고 재배포하세요.
  기존 데이터는 그대로입니다.
