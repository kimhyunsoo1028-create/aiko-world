AIKO WORLD v47 · 관리자 '공연 일정' 날짜 자동 정렬
====================================================

무엇을 수정하나요?
- 관리자 화면의 '공연 일정' 왼쪽 목록을 공연 시작 날짜 오름차순(빠른 날짜 먼저)으로 표시합니다.
- 같은 날짜는 시작 시간 순으로 정렬합니다. 시간이 없는 '작품 기간' 항목은 같은 날짜의 시간 있는 공연 앞에 표시합니다.
- 신규 일정 추가, 기존 일정 수정/삭제, 초기 목록 불러오기 시 재정렬합니다.
- 원래 HTML/JS의 데이터 저장 로직을 수정하지 않습니다. 정렬은 관리자 목록 표시 순서에만 적용합니다.
- 홈 화면, RENT 캘린더, 공연 아카이브, 방문자 통계 및 DB는 그대로 유지합니다.
- Supabase SQL 실행 및 환경변수 추가는 필요 없습니다.

설치 방법 (Netlify의 기존 GitHub 자동 배포 방식)
1. ZIP 파일 AIKO_WORLD_v47_schedule_autosort_patch.zip을 GitHub 저장소
   kimhyunsoo1028-create/aiko-world 의 main 브랜치 최상위에 업로드합니다.
2. Netlify > Project configuration > Build & deploy > Build settings > Build command에서
   기존 전체 명령을 그대로 유지하고, 마지막에 아래 명령을 추가합니다.

   && unzip -o AIKO_WORLD_v47_schedule_autosort_patch.zip && node install-aiworld-v47-schedule-sort.cjs

3. Save 후 Netlify Deploys에서 배포하고 Published 상태인지 확인하세요.
4. https://aiko-world.com/admin/ 접속 후 로그인해 '공연 일정' 탭에서 날짜 순서 확인.
5. 새 일정을 하나 저장해 왼쪽 목록의 올바른 날짜 위치에 나타나는지 확인합니다.

안전/복구
- 기존 코드는 덮어쓰지 않습니다. public/admin/index.html에 v47 스크립트 태그 1개만 추가합니다.
- 설치 스크립트는 여러 번 실행해도 스크립트 태그를 중복 추가하지 않습니다.
- 오류가 나거나 기존 UI와 충돌하면 Netlify Build command의 v47 명령어만 제거해 재배포하세요.
- 관리자 목록에서 보이는 순서만 수정하며 공개 사이트 일정 배열 정렬은 변경하지 않습니다.
- 관리자 페이지 DOM 구조가 이후 크게 바뀌면 정렬 기능이 동작하지 않을 수 있습니다.
