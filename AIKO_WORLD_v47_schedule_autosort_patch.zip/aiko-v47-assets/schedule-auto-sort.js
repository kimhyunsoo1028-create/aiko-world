/* AIKO WORLD v47 – auto-sort ONLY the admin performance schedule list.
   Kept separate from the original CMS. No changes to Supabase data, form fields,
   public calendar, archive, or event save/delete code. */
(() => {
  'use strict';
  if (window.__AIKO_V47_SCHEDULE_SORT__) return;
  window.__AIKO_V47_SCHEDULE_SORT__ = true;

  const DATE_RE = /\b((?:19|20)\d{2})[-./](\d{1,2})[-./](\d{1,2})\b/;
  const TIME_RE = /(?:^|[^\d])([01]?\d|2[0-3]):([0-5]\d)(?!\d)/;
  const MAX_ITEMS = 500;
  let observer;
  let pending = false;

  function dateInfo(el) {
    if (!el || !el.textContent) return null;
    const text = String(el.textContent).replace(/\s+/g, ' ').trim();
    const value = String(el.getAttribute?.('data-date') || el.getAttribute?.('data-event-date') || '') + ' ' + text;
    const d = DATE_RE.exec(value);
    if (!d) return null;
    const y = +d[1], m = +d[2], day = +d[3];
    const checked = new Date(Date.UTC(y, m - 1, day));
    if (checked.getUTCFullYear() !== y || checked.getUTCMonth() !== m - 1 || checked.getUTCDate() !== day) return null;
    const t = TIME_RE.exec(text);
    // Period-wide entries without a start time appear before timed events on the same date.
    const minute = t ? (+t[1] * 60 + +t[2]) : -1;
    return { dayIndex: Date.UTC(y, m - 1, day) / 86400000, minute };
  }

  function isScheduleHeading(el) {
    return /^(공연\s*일정|公演\s*日程|Performance\s*Schedule)$/i.test(String(el.textContent || '').trim());
  }

  function findSchedulePanel() {
    const heading = [...document.querySelectorAll('h1,h2,h3,h4')].find(isScheduleHeading);
    if (!heading) return null;
    let node = heading.parentElement;
    while (node && node !== document.body) {
      const buttons = node.querySelectorAll('button');
      const hasNewSchedule = [...buttons].some(b => /\+\s*새\s*일정/.test(b.textContent || ''));
      if (hasNewSchedule) return node;
      node = node.parentElement;
    }
    return null;
  }

  function findList(panel) {
    let winner = null, winnerScore = -Infinity;
    // List rows may be <button>, <li> or div: select the common DIRECT parent
    // instead of guessing an existing CMS element ID.
    for (const parent of panel.querySelectorAll('ul,ol,div')) {
      if (parent.closest('form') || parent.closest('select')) continue;
      const children = Array.from(parent.children);
      if (children.length < 2 || children.length > MAX_ITEMS) continue;
      const dated = children.filter(child => dateInfo(child));
      if (dated.length < 2 || dated.length / children.length < 0.7) continue;
      const score = dated.length * 100 - (children.length - dated.length) * 30;
      if (score > winnerScore || (score === winnerScore && parent.contains(winner))) {
        winnerScore = score;
        winner = parent;
      }
    }
    return winner;
  }

  function sortList() {
    const panel = findSchedulePanel();
    if (!panel) return;
    const list = findList(panel);
    if (!list) return;
    const children = Array.from(list.children);
    const indexed = children.map((el, i) => ({ el, i, info: dateInfo(el) }));
    if (indexed.some(item => !item.info)) return; // Do not reorder unrelated controls.
    const ordered = indexed.slice().sort((a, b) =>
      (a.info.dayIndex - b.info.dayIndex) || (a.info.minute - b.info.minute) || (a.i - b.i)
    );
    if (ordered.every((item, i) => item.el === children[i])) return;

    // Re-parenting existing nodes keeps their click handlers and editing state.
    const previousScroll = list.scrollTop;
    observer?.disconnect();
    const fragment = document.createDocumentFragment();
    ordered.forEach(({el}) => fragment.appendChild(el));
    list.appendChild(fragment);
    list.scrollTop = previousScroll;
    observe();
  }

  function scheduleSort() {
    if (pending) return;
    pending = true;
    // Debounce list redraws after saves, edits, deletes and asynchronous fetches.
    setTimeout(() => {
      pending = false;
      try { sortList(); } catch (err) { console.warn('[AIKO v47] 일정 정렬 건너뜀:', err); }
    }, 60);
  }

  function observe() {
    observer?.observe(document.body, {subtree: true, childList: true});
  }

  function init() {
    observer = new MutationObserver(scheduleSort);
    observe();
    scheduleSort();
    // Optional manual rerun for future CMS integrations.
    window.AIKO_SORT_SCHEDULES = scheduleSort;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
  else init();
})();
