'use strict';
/** Additive admin schedule-sort patch. Run AFTER existing v18-v46 installers. */
const fs = require('node:fs');
const path = require('node:path');
const root = process.cwd();
const input = path.join(root, 'aiko-v47-assets', 'schedule-auto-sort.js');
const adminHtml = path.join(root, 'public', 'admin', 'index.html');
const dest = path.join(root, 'public', 'admin', 'aiko-schedule-auto-sort-v47.js');
if (!fs.existsSync(adminHtml) || !fs.existsSync(input)) {
  throw new Error('[AIKO v47] 관리자 홈페이지 또는 v47 설치 파일이 없습니다. 기존 빌드를 확인하세요.');
}
let html = fs.readFileSync(adminHtml, 'utf8');
if (!/<\/body\s*>/i.test(html)) throw new Error('[AIKO v47] admin/index.html에 </body>가 없습니다.');
fs.mkdirSync(path.dirname(dest), {recursive:true});
fs.copyFileSync(input, dest);
const tag = '<script defer src="/admin/aiko-schedule-auto-sort-v47.js"></script>';
if (!html.includes('aiko-schedule-auto-sort-v47.js')) {
  html = html.replace(/<\/body\s*>/i, `${tag}\n</body>`);
  fs.writeFileSync(adminHtml, html, 'utf8');
}
console.log('[AIKO WORLD v47] Admin performance schedule list auto-sort installed. Existing data and layout unchanged.');
