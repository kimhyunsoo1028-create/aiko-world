AIKO WORLD v26 — 기존 자료 보존형 5차 연대표 검수·업로드·삭제
==========================================================
구성
- AIKO_WORLD_v26_timeline_admin.zip : 관리자 확장 패치
- AIKO_WORLD_v26_timeline.sql : Supabase 신규 테이블 설치 SQL
- AIKO_WORLD_v26_250_records_for_upload.txt : 5차 원본 250건 (검수 전)
- README_INSTALL_KO.txt : 이 안내문

기존 자료 보호
- 공연 일정, 세트리스트, 방송 영상, 사진, RENT 출연 달력, 관리자 기능은 삭제·덮어쓰기 하지 않습니다.
- SQL은 새 public.timeline_review_entries 테이블만 생성합니다.
- TXT 원본은 사용자의 컴퓨터에서 열어 관리자 브라우저에 선택해 불러옵니다.
  파일을 고르기만 해서는 DB에 전송하거나 공개하지 않습니다.
- 실제 항목을 선택하고 '선택 기록 비공개 초안 저장'을 확인해야 신규 테이블에 기록됩니다.
- 공개는 반드시 저장 후 개별 기록 편집에서 '검수 완료·공개'를 체크해야 합니다.
- 삭제는 이번에 새로 등록된 timeline_review_entries 행만 삭제합니다.
  기존 공연 일정/방송/사진/세트리스트 테이블에는 영향을 주지 않습니다.
- 같은 날짜에 기존 자료가 있으면 '중복 의심'으로 표시해 자동 추가를 피합니다.
- 자동 비교는 제목·날짜·출처 중심의 보조 판단이며 원본 비교 100% 확정이 아닙니다.

설치 방법 (Netlify + GitHub + Supabase)
1) Supabase 프로젝트 > SQL Editor > New query
   AIKO_WORLD_v26_timeline.sql 전체 내용 붙여넣고 Run (1회, 반복 실행도 안전).
   'v26 timeline ready' 확인.
2) AIKO_WORLD_v26_timeline_admin.zip 을 GitHub aiko-world 저장소 최상위 경로에
   ZIP 파일 그대로 업로드하고 Commit changes.
3) Netlify > Project configuration > Build settings > Build command
   기존 명령 전체 유지, 맨 마지막에 정확히 아래 부분만 이어 붙이기:

   && unzip -o AIKO_WORLD_v26_timeline_admin.zip && node install-aiworld-v26.cjs

   기존의 v18/v21-v22/v24/v25 명령을 지우지 마세요.
   반드시 v24 설치 명령 다음에 v26을 붙입니다.
   만약 v23을 이미 별도 설치했다면 그대로 유지합니다.
4) GitHub Commit으로 자동 배포가 시작되면 Deploys > Published 확인.
   추가 수동 배포 버튼을 중복 클릭할 필요 없습니다.

실제 사용
1) https://aiko-world.com/admin/ 로그인
2) '📥 연대표 비교·관리' 메뉴로 이동
3) Supabase 기존 자료 비교가 준비됐는지 확인; 준비 안 되면 '사이트 데이터 다시 비교'
4) '연대표 TXT/JSON 선택'에서 이 ZIP에 포함된 250건 TXT 파일 선택
   (혹은 본인이 수정한 동일 형식 TXT 파일 선택)
5) '신규 후보 / 중복 의심 / 기존 등록' 배지를 보고 출처와 날짜 검수
6) 선택한 항목을 '비공개 초안 저장' -> 신규 테이블에만 추가
7) 오른쪽 '저장된 연대표 관리'에서 개별 수정, 공개, 삭제 가능
   여러 건 삭제: 저장된 항목 체크 -> 선택 기록 삭제 -> 최종 '삭제' 입력
8) 보관용 'JSON 백업'과 '비교 결과 CSV 저장' 제공
9) 공개한 항목만 홈페이지 '공연마다, 다른 아이코 → 이어지는 시간' 아래
   '추가된 활동 연대표' 영역에 나타납니다.

주의
- A/B/C/D/P 검수 표시는 원본의 기록 상태일 뿐 모두 진실로 검증됐다는 뜻이 아닙니다.
- v26은 고유한 연대표를 추가하는 기능이며 기존 공연 세트리스트에 자동 연결하지 않습니다.
- 중복 비교 결과는 관리자가 확인해야 합니다. 검색과 제목 비교로는 완벽한 판정 불가.
- 기존 Supabase site_content, concert_stories, history_media 테이블을 비교시 읽기만 합니다.
  권한 오류 등으로 읽지 못하면 비교·업로드를 중단하며 기존 데이터는 변경하지 않습니다.
- Supabase 관리자 권한을 이미 설정해 둔 기존 사이트 환경을 사용합니다.
- 기존 Netlify 배포를 저절로 수정하지 않습니다. ZIP 업로드·SQL 실행을 직접 해야 합니다.
- 업로드할 TXT는 ZIP에 동봉했으며 GitHub ZIP 안에 보관되나 public/ 경로에는 배포하지 않습니다.
