-- AIKO WORLD v26: 5차 연대표 개별 검수/공개/삭제용 테이블
-- Supabase SQL Editor에서 1회 실행 (여러 번 실행 가능).
-- 기존 공연, 방송, 발자취 테이블/데이터를 삭제하거나 변경하지 않습니다.
-- 이 사이트의 기존 public.is_site_admin() 관리자 검증 함수가 필요합니다.
CREATE TABLE IF NOT EXISTS public.timeline_review_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  import_key text NOT NULL UNIQUE,
  event_date date NOT NULL,
  title text NOT NULL,
  category text NOT NULL DEFAULT '기타',
  verification text NOT NULL DEFAULT 'C' CHECK (verification IN ('A','B','C','D','P')),
  venue text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  source_url text NOT NULL DEFAULT '',
  source_text text NOT NULL DEFAULT '',
  review_note text NOT NULL DEFAULT '',
  is_published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_timeline_review_date ON public.timeline_review_entries(event_date DESC);
CREATE INDEX IF NOT EXISTS idx_timeline_review_public ON public.timeline_review_entries(is_published,event_date DESC);
ALTER TABLE public.timeline_review_entries ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.timeline_review_entries FROM anon,authenticated;
GRANT SELECT ON TABLE public.timeline_review_entries TO anon,authenticated;
GRANT INSERT,UPDATE,DELETE ON TABLE public.timeline_review_entries TO authenticated;
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='timeline_review_entries' AND policyname='aiko_timeline_public_or_admin_read') THEN
   CREATE POLICY aiko_timeline_public_or_admin_read ON public.timeline_review_entries
   FOR SELECT TO anon,authenticated
   USING (is_published OR (SELECT public.is_site_admin()));
 END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='timeline_review_entries' AND policyname='aiko_timeline_admin_insert') THEN
   CREATE POLICY aiko_timeline_admin_insert ON public.timeline_review_entries
   FOR INSERT TO authenticated WITH CHECK ((SELECT public.is_site_admin()));
 END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='timeline_review_entries' AND policyname='aiko_timeline_admin_update') THEN
   CREATE POLICY aiko_timeline_admin_update ON public.timeline_review_entries
   FOR UPDATE TO authenticated USING ((SELECT public.is_site_admin())) WITH CHECK ((SELECT public.is_site_admin()));
 END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='timeline_review_entries' AND policyname='aiko_timeline_admin_delete') THEN
   CREATE POLICY aiko_timeline_admin_delete ON public.timeline_review_entries
   FOR DELETE TO authenticated USING ((SELECT public.is_site_admin()));
 END IF;
END $$;
-- anon이 비공개 초안을 읽지 못하는지 RLS를 유지하세요. service_role 키를 브라우저에 배포하지 마세요.
SELECT 'v26 timeline ready' AS result, count(*) AS existing_rows FROM public.timeline_review_entries;
