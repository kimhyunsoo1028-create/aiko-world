'use strict';
/* Additive installer; runs after v24 stage-unified package. Idempotent. */
const fs=require('node:fs');
const files=['public/index.html','public/admin/index.html','public/stage-unified.js','public/admin/stage-admin-hub.mjs','public/cms-config.js'];
for(const p of files)if(!fs.existsSync(p))throw Error('[v26] Missing '+p+'; install v24 before v26.');
function attach(file,anchor,html){const original=fs.readFileSync(file,'utf8');if(original.includes(html)){console.log('[v26] already installed '+file);return}if(!original.includes(anchor))throw Error('[v26] Missing anchor '+anchor+' in '+file);fs.writeFileSync(file,original.replace(anchor,html+'\n'+anchor));console.log('[v26] linked '+file)}
attach('public/admin/index.html','</head>','<link rel="stylesheet" href="timeline-review-admin.css">');
attach('public/admin/index.html','</body>','<script type="module" src="timeline-review-admin.mjs"></script>');
attach('public/index.html','</head>','<link rel="stylesheet" href="timeline-review-public.css">');
attach('public/index.html','</body>','<script src="timeline-review-public.js" defer></script>');
// Dataset is a JSON preview only. No data is imported until an authenticated admin approves it.
console.log('[v26] Finished. Execute AIKO_WORLD_v26_timeline.sql before using admin upload.');
