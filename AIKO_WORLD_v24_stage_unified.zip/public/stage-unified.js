/* AIKO WORLD v24 — consolidate the existing stage archives without touching their data. */
(()=>{'use strict';
 const root=document.getElementById('concert-archive');
 const history=document.getElementById('history');
 if(!root||!history||root.querySelector('#asu-tabs'))return;
 const text={
  ko:{headline:'공연마다, 다른 아이코',intro:'공연 한 편씩 펼쳐보는 아이코의 무대 기록. 날짜·장소부터 확인된 세트리스트, 사진과 영상, 시간순 발자취까지 한곳에서 살펴보세요.',shows:'공연 무대 모음',stories:'세트리스트 · 사진 · 영상',media:'사진 · 영상 발자취',time:'이어지는 시간',search:'공연·장소·노래 검색',mediaSearch:'사진·영상 제목 검색',disclaimer:'실제 확인된 기록만 공개합니다. 공연 일정의 확인과 곡·영상의 확인은 별도입니다.',empty:'사진·영상이 아직 등록되지 않았습니다.',count:'건',connected:'이 공연의 세트리스트·사진 보기',fallback:'해당 자료가 아직 등록되지 않았습니다.'},
  ja:{headline:'ステージごとの、愛子',intro:'一公演ずつ振り返る愛子のステージ。日付・会場、確認済みのセットリスト、写真・映像、年表をひとつの場所で。',shows:'公演一覧',stories:'セットリスト・写真・映像',media:'写真・映像ダイアリー',time:'つながる時間',search:'公演・会場・曲名検索',mediaSearch:'写真・動画を検索',disclaimer:'確認済みの記録のみ掲載。公演情報とセットリスト・映像の確認状況は別です。',empty:'写真・動画はまだ登録されていません。',count:'件',connected:'この公演の曲目・写真を見る',fallback:'該当する資料はまだ登録されていません。'},
  en:{headline:'A different Aiko, every show',intro:'One show at a time: dates, venues, verified setlists, photos, videos and a chronological archive in one place.',shows:'Show archive',stories:'Setlists · photos · videos',media:'Photo & video diary',time:'Through the years',search:'Search show, venue or song',mediaSearch:'Search photos or videos',disclaimer:'Only documented material is published. Event verification is distinct from setlist and video verification.',empty:'No photos or videos have been added.',count:'records',connected:'See this show’s songs and photos',fallback:'No linked materials have been added yet.'}
 };
 const lang=()=>text[document.documentElement.lang]||text.ko;
 const create=(tag,cls,id)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(id)n.id=id;return n};
 const archiveParent=root.parentElement;
 const tabs=create('div','asu-tabs','asu-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','공연 아카이브 보기');
 const views=create('div','asu-views','asu-views');
 const keys=['shows','stories','media','time'];const panels={};const buttons={};
 for(const key of keys){
  const b=create('button','asu-tab');b.type='button';b.dataset.asuTab=key;b.setAttribute('role','tab');b.id='asu-tab-'+key;b.setAttribute('aria-controls','asu-panel-'+key);
  const icon=create('span','asu-tab-icon');icon.textContent=({shows:'🎤',stories:'🎼',media:'📷',time:'🕰️'})[key];
  const title=create('span','asu-tab-label');const count=create('small','asu-tab-count');
  b.append(icon,title,count);tabs.append(b);buttons[key]={button:b,title,count};
  const panel=create('div','asu-panel','asu-panel-'+key);panel.dataset.asuPanel=key;panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',b.id);
  panels[key]=panel;views.append(panel);
 }
 const heading=root.querySelector('.ca-top');
 const intro=document.createElement('p');intro.className='asu-intro';intro.id='asu-intro';
 const note=document.createElement('p');note.className='asu-note';note.id='asu-note';
 const head=document.createElement('div');head.className='asu-heading';head.innerHTML='<span class="asu-eyebrow">LIVE STORYBOOK · STAGE MEMORIES</span>';
 const title=document.createElement('h3');title.id='asu-headline';head.append(title,intro);
 for(const selector of ['.ca-top','.ca-controls','.ca-counterline','#ca-results','#ca-more','.ca-footer']){
  const original=root.querySelector(selector);if(original)panels.shows.append(original);
 }
 const stageRecords=history.querySelector('#concert-stories-archive');
 if(stageRecords)panels.stories.append(stageRecords);
 else{const p=create('p','asu-unavailable');p.textContent='공연별 기록 기능이 배포되지 않았습니다 (v21·v22).';panels.stories.append(p)}
 const notes=history.querySelector('.setlist-area');
 if(notes){const wrap=create('div','asu-existing-setlists');wrap.append(notes);panels.stories.append(wrap)}
 const historyMedia=history.querySelector('#history-media-archive');
 const mediaControls=create('div','asu-media-controls');mediaControls.innerHTML='<label><span class="asu-filter-title"></span><input type="search" id="asu-media-query" autocomplete="off"></label>';
 panels.media.append(mediaControls);
 if(historyMedia)panels.media.append(historyMedia);
 else{const p=create('p','asu-unavailable');p.textContent='발자취 미디어 기능이 배포되지 않았습니다 (v21·v22).';panels.media.append(p)}
 const chronology=history.querySelector(':scope > .container > .section-head');
 if(chronology){chronology.classList.add('asu-chronology-head');panels.time.append(chronology)}
 for(const id of ['era-intro','era-grid','history-timeline-heading','history-filters','history-list']){
  if(id==='history-filters')continue;
  const el=document.getElementById(id);if(el&&history.contains(el)){
   if(id==='history-list'){
    const controls=history.querySelector('.history-controls');if(controls)panels.time.append(controls)
   }
   panels.time.append(el)
  }
 }
 root.classList.add('asu-root');root.prepend(head,tabs,note,views);
 function countLabels(){
  const showCount=document.getElementById('ca-ct')?.textContent.trim();buttons.shows.count.textContent=/^\d+$/.test(showCount||'')?showCount:'';
  const sc=document.getElementById('acs-total')?.textContent.trim();buttons.stories.count.textContent=sc?sc.split('/').pop().trim():'';
  const photoCount=document.querySelectorAll('#ahm-grid .ahm-card').length;buttons.media.count.textContent=photoCount?String(photoCount):'';
 }
 function applyLang(){const tx=lang();title.textContent=tx.headline;intro.textContent=tx.intro;note.textContent=tx.disclaimer;
  for(const key of keys)buttons[key].title.textContent=tx[key];
  const filter=mediaControls.querySelector('.asu-filter-title');filter.textContent=tx.mediaSearch;
  const input=document.getElementById('asu-media-query');input.placeholder=tx.mediaSearch;
  countLabels();
 }
 let current='shows';
 function select(key,{focus=false,scroll=false}={}){
  if(!panels[key])return;current=key;
  for(const k of keys){const active=key===k;panels[k].hidden=!active;buttons[k].button.setAttribute('aria-selected',String(active));buttons[k].button.tabIndex=active?0:-1;buttons[k].button.classList.toggle('active',active)}
  if(focus)buttons[key].button.focus({preventScroll:true});
  if(scroll)root.scrollIntoView({behavior:'smooth',block:'start'});
  countLabels();
 }
 for(const key of keys){buttons[key].button.addEventListener('click',()=>{select(key);const anchor=key==='shows'?'concert-archive':'asu-panel-'+key;window.history.replaceState?.(null,'','#'+anchor)})}
 tabs.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
  e.preventDefault();const i=keys.indexOf(current);const target=e.key==='Home'?0:e.key==='End'?3:e.key==='ArrowRight'?(i+1)%4:(i+3)%4;select(keys[target],{focus:true})});
 const mediaInput=document.getElementById('asu-media-query');
 function filterMedia(){const q=mediaInput.value.trim().toLocaleLowerCase();
  const cards=[...document.querySelectorAll('#ahm-grid .ahm-card')];let visible=0;
  for(const c of cards){const show=c.textContent.toLocaleLowerCase().includes(q);c.hidden=!show;if(show)visible++}
  let empty=document.getElementById('asu-media-empty');if(!empty){empty=create('p','asu-no-results','asu-media-empty');panels.media.append(empty)}empty.hidden=!cards.length||visible>0;empty.textContent=lang().empty;
 }
 mediaInput.addEventListener('input',filterMedia);
 // Link the same performance between the main archive and the per-show media table
 // only if both date and venue (or exact title) match unambiguously. No guessed associations.
 function normal(s){return String(s||'').toLocaleLowerCase().replace(/[\s\p{P}\p{S}]/gu,'')}
 function addCrossLinks(){const source=[...document.querySelectorAll('#acs-grid .acs-card')];
  if(!source.length)return;
  const index=new Map();
  for(const card of source){const date=card.querySelector('.acs-date')?.textContent.match(/\d{4}-\d{2}-\d{2}/)?.[0];
   if(!date)continue;const venue=normal(card.querySelector('.acs-meta')?.textContent);const title=normal(card.querySelector('h4')?.textContent);
   const arr=index.get(date)||[];arr.push({card,venue,title});index.set(date,arr)
  }
  for(const card of document.querySelectorAll('#ca-results .ca-card')){
   if(card.querySelector('.asu-related'))continue;
   const date=card.querySelector('.ca-time')?.textContent.match(/\d{4}-\d{2}-\d{2}/)?.[0];if(!date)continue;
   const title=normal(card.querySelector('h4')?.textContent);
   const venue=normal((card.querySelectorAll('.ca-meta')[1]?.textContent||'').replace(/^⌁\s*/,''));
   const matches=(index.get(date)||[]).filter(row=>(venue&&row.venue&&venue===row.venue)||(title.length>=5&&row.title===title));
   if(matches.length!==1)continue;
   const dest=matches[0].card;const detail=card.querySelector('.ca-detail');if(!detail)continue;
   const link=create('button','asu-related');link.type='button';link.textContent='🎼 '+lang().connected;
   link.addEventListener('click',()=>{select('stories',{scroll:true});
    const search=document.getElementById('acs-search');if(search){search.value=dest.querySelector('h4')?.textContent||date;search.dispatchEvent(new Event('input',{bubbles:true}))}
    const toFind=[...document.querySelectorAll('#acs-grid .acs-card')].find(el=>el.querySelector('h4')?.textContent===dest.querySelector('h4')?.textContent && el.querySelector('.acs-date')?.textContent.includes(date));
    if(toFind){const btn=toFind.querySelector('button[aria-expanded]');if(btn?.getAttribute('aria-expanded')==='false')btn.click();toFind.scrollIntoView({behavior:'smooth',block:'center'})}
   });detail.append(link)
  }
 }
 const srcGrid=document.getElementById('ca-results');const extraGrid=document.getElementById('acs-grid');
 let pending=false;function sync(){if(pending)return;pending=true;requestAnimationFrame(()=>{pending=false;countLabels();addCrossLinks();filterMedia()})}
 if(srcGrid)(new MutationObserver(sync)).observe(srcGrid,{childList:true,subtree:false});
 if(extraGrid)(new MutationObserver(sync)).observe(extraGrid,{childList:true,subtree:false});
 const historyGrid=document.getElementById('ahm-grid');if(historyGrid)(new MutationObserver(sync)).observe(historyGrid,{childList:true,subtree:false});
 const caCt=document.getElementById('ca-ct');if(caCt)(new MutationObserver(sync)).observe(caCt,{childList:true,characterData:true,subtree:true});
 (new MutationObserver(()=>{applyLang();document.querySelectorAll('.asu-related').forEach(x=>{x.textContent='🎼 '+lang().connected})})).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 const hash=window.location.hash;
 if(hash==='#concert-stories-archive'||hash==='#asu-panel-stories')current='stories';
 else if(hash==='#history-media-archive'||hash==='#asu-panel-media')current='media';
 else if(hash==='#asu-panel-time'||hash==='#history-list')current='time';
 select(current);applyLang();sync();
 window.addEventListener('hashchange',()=>{const h=location.hash;if(h==='#concert-stories-archive'||h==='#asu-panel-stories')select('stories');else if(h==='#history-media-archive'||h==='#asu-panel-media')select('media');else if(h==='#asu-panel-time')select('time');else if(h==='#concert-archive')select('shows')});
 console.info('[AIKO WORLD v24] Stage archive consolidated; original records unchanged.');
})();
