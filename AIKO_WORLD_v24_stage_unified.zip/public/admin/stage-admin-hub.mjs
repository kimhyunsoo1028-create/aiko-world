/* AIKO WORLD v24: one admin entry point for existing stage editing tools. No writes. */
'use strict';
const wait=()=>new Promise(resolve=>{
 let n=0;const tick=()=>{const tabs=document.getElementById('tabs'),dashboard=document.getElementById('dashboard');if(tabs&&dashboard&&tabs.querySelector('[data-tab="concertstories"]')&&tabs.querySelector('[data-tab="concert"]'))resolve({tabs,dashboard});else if(++n<120)setTimeout(tick,120);else resolve(null)};tick();
});
const ctx=await wait();
if(ctx){const {tabs,dashboard}=ctx;if(!tabs.querySelector('[data-tab="stagehub"]')){
 const btn=document.createElement('button');btn.type='button';btn.dataset.tab='stagehub';btn.textContent='🎤 공연 통합 관리';tabs.insertBefore(btn,tabs.querySelector('[data-tab="concert"]'));
 const pane=document.createElement('section');pane.className='panel pane stage-admin-hub';pane.dataset.pane='stagehub';pane.hidden=true;
 pane.innerHTML=`<div class="section-head"><div><h2>🎤 공연마다, 다른 아이코 · 통합 관리</h2><p>공연·세트리스트·사진·영상·시간순 기록의 수정 화면을 한곳에서 찾아갈 수 있습니다. 저장 데이터는 기존 Supabase 테이블을 그대로 사용합니다.</p></div><a href="../#concert-archive" target="_blank" rel="noopener noreferrer">공연 아카이브 보기 ↗</a></div>
 <p class="stage-admin-warning">등록 원칙: 실제 공연 날짜와 출처가 확인된 기록만 공개합니다. 곡명·영상·사진은 해당 공연 자료로 확인된 경우에만 추가하세요.</p>
 <div class="stage-admin-grid">
 <button type="button" data-open-pane="concert"><strong>① 공연별 무대</strong><span>기존 공연 정보, 공식 출처, 세트리스트, MP4/WebM 직접 업로드</span></button>
 <button type="button" data-open-pane="concertstories"><strong>② 공연별 세트리스트 · 사진 · 영상</strong><span>공연을 선택해 세트리스트와 사진 여러 장, 확인된 영상 링크 등록</span></button>
 <button type="button" data-open-pane="historymedia"><strong>③ 사진 · 영상 발자취</strong><span>일반 사진 업로드, 사진·영상 링크를 날짜순 아카이브에 표시</span></button>
 <button type="button" data-open-pane="v23timeline"><strong>④ 이어지는 시간 · 활동 기록</strong><span>연도별 기록의 날짜·내용·출처 수정</span></button>
 <button type="button" data-open-pane="events"><strong>⑤ 공연 캘린더</strong><span>미래 공연 일정 및 출연 확정 기록 수정</span></button>
 <button type="button" data-open-pane="videos"><strong>⑥ 방송 무대 모음</strong><span>방송 회차별 영상 링크 관리 (공연 기록과 별개)</span></button>
 </div><p class="stage-admin-tip">같은 공연을 이미 등록했다면 새 공연을 중복 생성하지 말고 기존 기록을 선택하세요. ‘공연별 세트리스트’에서는 <b>기존 공연 기록에서 불러오기</b> 기능을 사용하면 날짜·제목·장소를 재입력하지 않아도 됩니다.</p>
 <p id="stage-admin-status" role="status"></p>`;
 const s=document.getElementById('status');if(s)s.before(pane);else dashboard.append(pane);
 pane.addEventListener('click',e=>{const b=e.target.closest('[data-open-pane]');if(!b)return;const name=b.dataset.openPane;const dest=tabs.querySelector(`button[data-tab="${name}"]`);if(!dest){pane.querySelector('#stage-admin-status').textContent='해당 메뉴가 아직 설치되지 않았습니다. v21·v22·v23 설치 상태를 확인하세요.';return}dest.click()});
 tabs.addEventListener('click',e=>{const active=e.target.closest('button[data-tab]');if(!active)return;for(const tab of tabs.querySelectorAll('button[data-tab]'))tab.classList.toggle('active',tab===active);for(const p of dashboard.querySelectorAll('[data-pane]'))p.hidden=p.dataset.pane!==active.dataset.tab});
 console.info('[AIKO WORLD v24] Stage admin shortcut installed without database changes.');
}}
