/* AIKO WORLD v23: add verified content editing to the EXISTING admin; no seeded events or videos. */
'use strict';
await (window.AIKO_CMS_READY || Promise.resolve());
const cfg=window.AIKO_CMS_CONFIG||{};
const dash=document.getElementById('dashboard'),tabs=document.getElementById('tabs');
if(!dash||!tabs)throw new Error('기존 관리자 대시보드가 없어 v23을 연결하지 못했습니다.');
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const text=s=>String(s??'').trim();
const langs=['ko','ja','en'];
const langLabel={ko:'한국어',ja:'日本語',en:'English'};
const strictUrl=s=>{if(!s)return '';try{const u=new URL(s);if(u.protocol==='https:'&&!u.username&&!u.password)return u.href}catch{}throw new Error('링크는 실제로 확인한 https:// 주소만 입력하세요.');};
const copyFields=[
 ['home','note','상단 문구'],['home','heroEyebrow','첫 화면 작은 제목'],['home','heroLine1','첫 화면 큰 제목 1'],['home','heroLine2','첫 화면 큰 제목 2'],['home','heroBody','첫 화면 소개'],['home','heroJapanese','일본어 슬로건'],
 ['spotlight','spotTitle','지금의 공연 제목'],['spotlight','spotIntro','지금의 공연 설명'],['spotlight','rentTitle','RENT 카드 제목'],['spotlight','rentDetail','RENT 카드 설명'],
 ['latest','latestTitle','새 소식 제목'],['latest','latestIntro','새 소식 설명'],['latest','sideNote','출처 확인 안내'],
 ['schedule','scheduleTitle','공연 달력 제목'],['schedule','scheduleIntro','공연 달력 설명'],
 ['music','musicTitle','음악 영역 제목'],['music','musicIntro','음악 영역 설명'],['music','musicNote','영상 안내 문구'],
 ['history','historyTitle','발자취 제목'],['history','historyIntro','발자취 설명'],
 ['gallery','galleryTitle','사진 제목'],['gallery','galleryIntro','사진 설명'],
 ['about','aboutTitle1','아티스트 제목 1'],['about','aboutTitle2','아티스트 제목 2'],['about','aboutIntro','아티스트 소개'],
 ['connect','connectTitle','연결 영역 제목'],['connect','connectIntro','연결 영역 설명'],['footer','footerWords','하단 문구']
];
const copyGroupNames={home:'첫 화면',spotlight:'주목할 공연 / RENT',latest:'새 소식',schedule:'공연 달력',music:'음악',history:'발자취',gallery:'사진',about:'프로필',connect:'SNS / 공식 채널',footer:'하단'};
const linkNames={agency:'소속사 뉴스',artist:'공식 프로필',unit:'음악 영역 OVAL SISTEM',x:'X 계정',instagram:'인스타그램',oval:'OVAL SISTEM',hpp:'HppRecords'};
function addTab(id,label,markup){
 let b=tabs.querySelector(`button[data-tab="${id}"]`);
 if(!b){b=document.createElement('button');b.type='button';b.dataset.tab=id;b.textContent=label;tabs.append(b)}
 let pane=dash.querySelector(`[data-pane="${id}"]`);
 if(!pane){pane=document.createElement('section');pane.className='panel pane v23-editors';pane.dataset.pane=id;pane.hidden=true;pane.innerHTML=markup;
  const status=$('status');if(status)status.before(pane);else dash.append(pane)}
 return [b,pane];
}
let supabase=null;
async function auth(){
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')||!cfg.publishableKey)throw Error('Supabase 공개 설정이 아직 연결되지 않았습니다.');
 if(!supabase){const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');supabase=createClient(cfg.url,cfg.publishableKey,{auth:{persistSession:true,autoRefreshToken:true}})}
 const {data:{user},error}=await supabase.auth.getUser();if(error||!user)throw Error('관리자 로그인 후 이용할 수 있습니다.');
 const {data,error:permError}=await supabase.from('site_admins').select('user_id').eq('user_id',user.id).maybeSingle();
 if(permError||!data)throw Error('관리자 권한이 확인되지 않았습니다.');
 return supabase;
}
async function readPayload(key,fallback){const sb=await auth();const {data,error}=await sb.from('site_content').select('payload').eq('key',key).maybeSingle();if(error)throw error;return data?.payload??JSON.parse(JSON.stringify(fallback))}
async function savePayload(key,payload){const sb=await auth();const {error}=await sb.from('site_content').upsert({key,payload,updated_at:new Date().toISOString()});if(error)throw error}
function status(id,value,isError=false){const e=$(id);if(!e)return;e.textContent=value;e.style.color=isError?'#a43240':'#126a3e'}
function control(label,name,value='',type='text',required=false){const isLong=type==='textarea';return `<label>${esc(label)}${isLong?`<textarea name="${esc(name)}" rows="3" ${required?'required':''}>${esc(value)}</textarea>`:`<input name="${esc(name)}" type="${esc(type)}" value="${esc(value)}" ${required?'required':''}>`}</label>`}
function val(f,name){return text(f.elements.namedItem(name)?.value)}
function defaultArchive(){return Array.isArray(window.AIKO_DATA?.archive)?window.AIKO_DATA.archive:[]}
function defaultMedia(){return Array.isArray(window.AIKO_DATA?.media)?window.AIKO_DATA.media:[]}
// === HOME EDITOR ===
addTab('v23home','🏠 홈페이지 편집',`<h2>🏠 홈페이지 문구 · 공식 링크 편집</h2><p>방문자 첫 화면의 문구를 한국어·일본어·영어별로 수정합니다. 비워 둔 항목은 사이트 기존 문구가 유지됩니다.</p>
<div id="v23-hub"><div class="v23-cards" id="v23-shortcuts"></div></div>
<form id="v23-copy-form"><label>수정할 화면 구역<select id="v23-copy-group"></select></label><div id="v23-copy-fields"></div><fieldset><legend>공식 채널 링크</legend><p class="v23-alert">링크는 실제 공식 주소를 확인했을 때만 교체하세요. 비워 두면 기존 링크를 그대로 사용합니다.</p><div id="v23-links"></div></fieldset><div class="actions"><button class="primary" type="submit">문구·링크 저장 · 즉시 반영</button><button type="button" id="v23-copy-reload">저장된 내용 다시 불러오기</button></div><p id="v23-copy-msg" role="status" class="status"></p></form>`);
addTab('v23timeline','📚 발자취 편집',`<h2>📚 연도별 활동 기록 편집</h2><p>홈페이지의 기존 발자취 타임라인을 수정합니다. 없는 공연이나 출연은 추가하지 마세요.</p>
<div class="v23-grid"><aside><input id="v23-timeline-search" type="search" placeholder="연도·활동 검색"><div class="v23-action"><button id="v23-timeline-new" type="button" class="primary">+ 검증된 기록 추가</button></div><p id="v23-timeline-count" class="muted"></p><ul class="v23-list" id="v23-timeline-list"></ul></aside><form id="v23-timeline-form"><p class="v23-alert">새 기록은 날짜·내용·실제 출처가 확인될 때만 공개하세요. 저장하면 사이트에 반영됩니다.</p>
<div class="two"><label>날짜·기간<input name="date" required placeholder="예: 2026.10.27"></label><label>구분<select name="cat"><option value="stage">무대</option><option value="music">음악</option><option value="media">방송</option></select></label></div>
<div id="v23-timeline-fields"></div>${control('공식 출처 URL','source','','url',true)}<div class="actions"><button type="submit" class="primary">발자취 기록 저장</button><button type="button" class="danger" id="v23-timeline-delete">선택 기록 삭제</button></div><p class="status" id="v23-timeline-msg"></p></form></div>`);
addTab('v23music','🎵 음악 카드 편집',`<h2>🎵 메인 음악 카드 · 영상 링크 관리</h2><p>홈페이지의 「목소리가 남긴 장면들」 영역입니다. 방송 영상 링크 관리와 별도로 적용됩니다.</p>
<div class="v23-grid"><aside><input id="v23-music-search" type="search" placeholder="노래·활동명 검색"><div class="v23-action"><button type="button" id="v23-music-new" class="primary">+ 확인된 음악 카드</button></div><p id="v23-music-count" class="muted"></p><ul class="v23-list" id="v23-music-list"></ul></aside>
<form id="v23-music-form"><div class="two"><label>구분<input name="kind" required placeholder="OVAL SISTEM / RENT"></label><label>곡·카드 제목<input name="title" required></label></div><div class="v23-row" id="v23-music-sub"></div><div class="two"><label>대표 링크 (HTTPS)<input name="url" type="url" placeholder="https://..."></label><label>링크 방식<select name="linkType"><option value="video">공식/확인된 영상</option><option value="search">검색 결과 링크</option></select></label></div><fieldset><legend>세부 영상 링크</legend><p class="v23-alert">없는 영상 주소는 입력하지 마세요. 영상 링크 대신 실제 영상 파일 업로드가 필요하면 「공연 상세·영상」을 사용하세요.</p><div id="v23-music-clips"></div><button type="button" id="v23-music-addclip">+ 확인된 링크 추가</button></fieldset>
<div class="actions"><button class="primary" type="submit">음악 카드 저장</button><button class="danger" type="button" id="v23-music-delete">선택 카드 삭제</button></div><p id="v23-music-msg" class="status"></p></form></div>`);

// Existing concert editor from v21: the installer embeds its static form into this old v18 admin.
let concertEditor=null;
if($('concert-editor')&&!tabs.querySelector('[data-tab="concert"]')){
 const b=document.createElement('button');b.type='button';b.dataset.tab='concert';b.textContent='🎤 공연 상세·영상';tabs.insertBefore(b,tabs.querySelector('[data-tab="videos"]')||tabs.firstChild);
}
if($('concert-editor')){
 const b=tabs.querySelector('[data-tab="concert"]');
 b?.addEventListener('click',async()=>{
  try{const sb=await auth();if(!concertEditor){const {createConcertEditor}=await import('./concert-admin.mjs');concertEditor=createConcertEditor(sb,(msg,error)=>status('status',msg,error))}await concertEditor.load()}
  catch(e){status('status','공연 편집 연결 실패: '+e.message,true)}
 });
}
// Existing v21/v22 add-on tabs should be present when their scripts are installed correctly.
const shortcuts=[['events','📅 공연 일정','날짜, 공연장, 출연 확인'],['concert','🎤 공연 상세·영상','세트리스트, MP4/WebM 업로드'],['concertstories','🎼 공연별 세트리스트·사진','공연별 사진과 여러 영상 링크'],['historymedia','🎞️ 발자취 사진·영상','발자취 이미지/영상 링크'],['v23timeline','📚 기존 발자취','활동 이력 수정·추가'],['v23music','🎵 음악 카드','대표 곡과 외부 영상'],['videos','🎬 방송 영상','방송 회차별 영상 링크'],['gallery','🖼️ 사진 4장','메인 사진 교체'],['articles','✍️ 새 소식·공지','글 추가/수정/비공개']];
for(const [id,label,detail] of shortcuts){const btn=document.createElement('button');btn.type='button';btn.className='v23-card';btn.innerHTML=`<strong>${esc(label)}</strong><small>${esc(detail)}</small>`;
 btn.addEventListener('click',()=>{const tab=tabs.querySelector(`[data-tab="${id}"]`);if(!tab){status('v23-copy-msg','해당 관리 기능이 현재 배포본에 없습니다. v21·v22 ZIP 적용 여부를 확인하세요.',true);return}tab.click();});$('v23-shortcuts').append(btn)}
// Add a safe tab handler for environments where the old admin bound tabs before v23 insertion.
tabs.addEventListener('click',e=>{const tab=e.target.closest('button[data-tab]');if(!tab)return;
 document.querySelectorAll('.tabs button[data-tab]').forEach(x=>x.classList.toggle('active',x===tab));
 document.querySelectorAll('[data-pane]').forEach(p=>p.hidden=p.dataset.pane!==tab.dataset.tab);
});

let copyData={texts:{},links:{}},archive=[],timelineSel=-1,media=[],musicSel=-1;
function initCopySelectors(){for(const [id,label] of Object.entries(copyGroupNames)){const opt=document.createElement('option');opt.value=id;opt.textContent=label;$('v23-copy-group').append(opt)}
 $('v23-copy-group').addEventListener('change',renderCopy);$('v23-copy-form').addEventListener('submit',saveCopy);$('v23-copy-reload').addEventListener('click',reloadCopy);
 for(const [key,label] of Object.entries(linkNames))$('v23-links').insertAdjacentHTML('beforeend',control(label,key,'','url'));
}
function renderCopy(){const group=$('v23-copy-group').value;const root=$('v23-copy-fields');root.replaceChildren();
 for(const [,key,label] of copyFields.filter(x=>x[0]===group)){
  const block=document.createElement('fieldset');block.className='v23-block';block.innerHTML=`<legend>${esc(label)}</legend><div class="v23-row">${langs.map(l=>control(langLabel[l],key+'_'+l,copyData.texts?.[key]?.[l]||'','textarea')).join('')}</div>`;root.append(block);
 }
 for(const key of Object.keys(linkNames))$('v23-copy-form').elements.namedItem(key).value=copyData.links?.[key]||'';
}
async function reloadCopy(){try{const data=await readPayload('page_copy_v23',{texts:{},links:{}});copyData={texts:data.texts||{},links:data.links||{}};renderCopy();status('v23-copy-msg','수정 가능한 문구를 불러왔습니다. 비어 있는 항목은 원래 문구를 사용합니다.')}catch(e){status('v23-copy-msg','불러오기 실패: '+e.message,true)}}
async function saveCopy(e){e.preventDefault();try{const form=e.currentTarget;const next=JSON.parse(JSON.stringify(copyData));next.texts??={};next.links??={};
  for(const [,key] of copyFields.filter(x=>x[0]===$('v23-copy-group').value)){const multilingual={};for(const l of langs){const s=val(form,key+'_'+l);if(s)multilingual[l]=s}if(Object.keys(multilingual).length)next.texts[key]=multilingual;else delete next.texts[key]}
  for(const key of Object.keys(linkNames)){const v=val(form,key);if(v)next.links[key]=strictUrl(v);else delete next.links[key]}
  await savePayload('page_copy_v23',next);copyData=next;status('v23-copy-msg','✅ 저장했습니다. 방문자 화면을 새로고침하면 반영됩니다.');
 }catch(err){status('v23-copy-msg','저장 실패: '+err.message,true)}}
initCopySelectors();

// === EXISTING CHRONOLOGY ===
function multiFields(prefix,values={}){return `<fieldset class="v23-block"><legend>${esc(prefix)}</legend><div class="v23-row">${langs.map(l=>control(langLabel[l],prefix+'_'+l,values?.[l]||'','textarea')).join('')}</div></fieldset>`}
function timelineFill(){const r=archive[timelineSel]||{};const form=$('v23-timeline-form');form.reset();form.elements.namedItem('date').value=r.date||'';form.elements.namedItem('cat').value=r.cat||'stage';form.elements.namedItem('source').value=r.source||'';
 $('v23-timeline-fields').innerHTML=multiFields('tag',r.tag)+multiFields('title',r.title)+multiFields('desc',r.desc);$('v23-timeline-delete').disabled=timelineSel<0;
}
function timelineList(){const ul=$('v23-timeline-list');ul.replaceChildren();const q=valSearch('v23-timeline-search');let shown=0;
 archive.forEach((r,i)=>{if(![r.date,r.title?.ko,r.title?.ja,r.desc?.ko].join(' ').toLowerCase().includes(q))return;shown++;
 const li=document.createElement('li'),b=document.createElement('button');b.type='button';b.className=i===timelineSel?'active':'';b.textContent=`${r.date||'날짜 없음'} · ${r.title?.ko||r.title?.ja||'제목 없음'}`;b.addEventListener('click',()=>{timelineSel=i;timelineFill();timelineList()});li.append(b);ul.append(li)});
 $('v23-timeline-count').textContent=`표시 ${shown} / 전체 ${archive.length}건`;
}
function valSearch(id){return text($(id).value).toLowerCase()}
async function reloadTimeline(){try{archive=await readPayload('archive',defaultArchive());if(!Array.isArray(archive))throw Error('발자취 목록 형식이 올바르지 않습니다.');timelineSel=archive.length?0:-1;timelineFill();timelineList();status('v23-timeline-msg','발자취 목록을 불러왔습니다.')}catch(e){status('v23-timeline-msg','불러오기 실패: '+e.message,true)}}
$('v23-timeline-search').addEventListener('input',timelineList);
$('v23-timeline-new').addEventListener('click',()=>{timelineSel=-1;timelineFill();timelineList();status('v23-timeline-msg','새 기록을 입력하세요. 공식 출처를 반드시 확인해야 합니다.')});
$('v23-timeline-form').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;try{
 const entry={date:val(f,'date'),cat:val(f,'cat'),source:strictUrl(val(f,'source'))};
 if(!/^(19|20)\d{2}/.test(entry.date)||!entry.source)throw Error('날짜와 공식 출처 링크를 입력하세요.');
 for(const group of ['tag','title','desc']){entry[group]={};for(const l of langs)entry[group][l]=val(f,group+'_'+l)}
 if(!entry.title.ko&&!entry.title.ja)throw Error('확인된 활동 제목이 필요합니다.');
 const next=archive.slice();if(timelineSel<0)next.push(entry);else next[timelineSel]=entry;
 await savePayload('archive',next);archive=next;timelineSel=next.indexOf(entry);timelineList();timelineFill();status('v23-timeline-msg','✅ 발자취 기록 저장 완료. 방문자 타임라인에 반영됩니다.');
 }catch(err){status('v23-timeline-msg','저장 실패: '+err.message,true)}});
$('v23-timeline-delete').addEventListener('click',async()=>{if(timelineSel<0||!confirm('선택 발자취를 공개 목록에서 삭제할까요?'))return;
 try{const next=archive.filter((_,i)=>i!==timelineSel);await savePayload('archive',next);archive=next;timelineSel=-1;timelineFill();timelineList();status('v23-timeline-msg','기록을 삭제했습니다.')}catch(e){status('v23-timeline-msg',e.message,true)}});

// === MUSIC CARDS AND REAL LINKS ===
function renderClip(clip={}){const fs=document.createElement('fieldset');fs.className='v23-block v23-clip';fs.innerHTML=`<legend>🎬 링크</legend><div class="two">${control('링크 이름 · 한국어','clip_label_ko',clip.label?.ko||'')}${control('링크 이름 · 日本語','clip_label_ja',clip.label?.ja||'')}${control('링크 이름 · English','clip_label_en',clip.label?.en||'')}${control('구분 (MV / TV / LIVE)','clip_category',clip.category||'')}${control('실제 영상 URL','clip_url',clip.url||'','url')}${control('출처/채널','clip_credit',clip.credit||'')}</div><button type="button" class="danger">이 링크 제거</button>`;
 fs.querySelector('button').addEventListener('click',()=>fs.remove());$('v23-music-clips').append(fs);return fs}
function musicFill(){const m=media[musicSel]||{};const f=$('v23-music-form');f.reset();for(const k of ['kind','title','url','linkType'])f.elements.namedItem(k).value=m[k]|| (k==='linkType'?'video':'');
 $('v23-music-sub').innerHTML=langs.map(l=>control('설명 · '+langLabel[l],'subtitle_'+l,m.subtitle?.[l]||'','textarea')).join('');
 $('v23-music-clips').replaceChildren();for(const link of (m.links||[]))renderClip(link);$('v23-music-delete').disabled=musicSel<0;
}
function musicList(){const ul=$('v23-music-list');ul.replaceChildren();const q=valSearch('v23-music-search');let shown=0;
 media.forEach((m,i)=>{if(![m.title,m.kind,m.subtitle?.ko].join(' ').toLowerCase().includes(q))return;shown++;
 const li=document.createElement('li'),b=document.createElement('button');b.type='button';b.className=i===musicSel?'active':'';b.textContent=`${m.title||'제목 없음'} · ${m.kind||''}`;
 b.addEventListener('click',()=>{musicSel=i;musicFill();musicList()});li.append(b);ul.append(li)});$('v23-music-count').textContent=`표시 ${shown} / 전체 ${media.length}건`;
}
async function reloadMusic(){try{media=await readPayload('media',defaultMedia());if(!Array.isArray(media))throw Error('음악 목록 형식이 올바르지 않습니다.');musicSel=media.length?0:-1;musicFill();musicList();status('v23-music-msg','음악 카드와 기존 연결 영상을 불러왔습니다.')}catch(e){status('v23-music-msg','불러오기 실패: '+e.message,true)}}
$('v23-music-search').addEventListener('input',musicList);
$('v23-music-new').addEventListener('click',()=>{musicSel=-1;musicFill();musicList();status('v23-music-msg','실제로 확인한 음악 카드만 입력하세요.')});
$('v23-music-addclip').addEventListener('click',()=>renderClip());
$('v23-music-form').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget;try{
 const base=musicSel>=0?media[musicSel]:{};
 const entry={...base,id:base.id||`admin-music-${crypto.randomUUID()}`,n:base.n||String(media.length+1).padStart(2,'0'),kind:val(f,'kind'),title:val(f,'title'),url:strictUrl(val(f,'url')),linkType:val(f,'linkType'),subtitle:{}};
 for(const l of langs)entry.subtitle[l]=val(f,'subtitle_'+l);
 if(!entry.kind||!entry.title)throw Error('음악 종류와 곡명을 입력하세요.');
 entry.links=[];
 for(const row of $('v23-music-clips').querySelectorAll('.v23-clip')){
 const g=name=>val(row,name),url=strictUrl(g('clip_url'));
 if(!url)throw Error('비어 있거나 확인하지 않은 링크 항목은 제거하세요.');
 if(!g('clip_label_ko')&&!g('clip_label_ja'))throw Error('한국어 또는 일본어 링크 이름을 입력하세요.');
 entry.links.push({label:{ko:g('clip_label_ko'),ja:g('clip_label_ja'),en:g('clip_label_en')},category:g('clip_category'),url,credit:g('clip_credit')});
 }
 if(!entry.url&&!entry.links.length)throw Error('실제 확인된 대표 링크 또는 세부 링크가 최소 1개 필요합니다.');
 if(!entry.url)entry.url=entry.links[0].url;
 const next=media.slice();if(musicSel<0)next.push(entry);else next[musicSel]=entry;
 await savePayload('media',next);media=next;musicSel=next.findIndex(r=>r.id===entry.id);musicFill();musicList();status('v23-music-msg','✅ 음악 카드 저장 완료. 홈페이지 새로고침 후 확인하세요.');
 }catch(err){status('v23-music-msg','저장 실패: '+err.message,true)}});
$('v23-music-delete').addEventListener('click',async()=>{if(musicSel<0||!confirm('이 음악 카드를 방문자 페이지에서 삭제할까요?'))return;
 try{const next=media.filter((_,i)=>i!==musicSel);await savePayload('media',next);media=next;musicSel=-1;musicFill();musicList();status('v23-music-msg','음악 카드를 삭제했습니다.')}catch(e){status('v23-music-msg',e.message,true)}});
// Load only when panel opened. Base admin handles authentication, so this never seeds public data.
const loads={v23home:reloadCopy,v23timeline:reloadTimeline,v23music:reloadMusic};
for(const [id,loader] of Object.entries(loads))tabs.querySelector(`[data-tab="${id}"]`).addEventListener('click',()=>{if(!dash.hidden)loader()});
