/* AIKO WORLD concert curator. Saves manual overrides only, never guesses events or video URLs. */
const get=id=>document.getElementById(id);
const clean=s=>String(s??'').trim();
const isHttps=s=>{try{return new URL(s).protocol==='https:'}catch{return false}};
const originals=Array.isArray(window.AIKO_PERFORMANCES)?window.AIKO_PERFORMANCES:[];
const clone=x=>JSON.parse(JSON.stringify(x));
const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el};
const val=(form,name)=>clean(form.elements.namedItem(name)?.value);
const msgErr=e=>e?.message||String(e);
const validDate=d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(new Date(d+'T12:00:00Z').getTime());
const seriesList=[['solo','아이코 솔로'],['rent','RENT 2026 · 모린'],['orbit','orbit CLUB'],['tour','Prologue Tour O'],['kichijoji','키치조지'],['festival','페스티벌·합동'],['seoul','한국 공연'],['fanmeet','팬미팅']];
function mediaRow(data={}){
 const wrap=node('fieldset',undefined,'concert-video-row');
 wrap.innerHTML=`<legend>공연 영상</legend><div class="two"><label>영상 이름<input name="media_title" placeholder="실제 무대 영상 제목"></label><label>구분<select name="media_kind"><option value="external">외부 링크</option><option value="upload">업로드 파일</option></select></label></div><label>영상 URL (https://)<input name="media_url" type="url" placeholder="https://..."></label><label>촬영자·제공처·근거<input name="media_credit" placeholder="직접 촬영 또는 공식 업로드 채널"></label><label class="concert-consent"><input type="checkbox" name="media_verified">실제 해당 공연 영상이며 공개 권한·촬영 허용 여부를 확인했습니다</label>`;
 for(const k of ['title','kind','url','credit']){const f=wrap.querySelector(`[name="media_${k}"]`);f.value=data[k]|| (k==='kind'?'external':'')}
 wrap.querySelector('[name="media_verified"]').checked=data.verified===true;
 const remove=node('button','영상 항목 제거','danger');remove.type='button';remove.onclick=()=>wrap.remove();wrap.append(remove);
 return wrap;
}
export function createConcertEditor(sb,message){
 const root=get('concert-editor');if(!root)return{load:async()=>{}};
 const list=get('concert-record-list'),search=get('concert-record-search'), form=get('concert-record-form'), rows=get('concert-media-rows');
 const builtin=clone(originals);
 let overrides=[], active=builtin[0]?.id||'', current=[];
 const setMsg=(s,error=false)=>message(s,error);
 function combined(){const map=new Map(builtin.map(e=>[e.id,e]));for(const item of overrides)map.set(item.id,{...(map.get(item.id)||{}),...item});return [...map.values()].sort((a,b)=>b.date.localeCompare(a.date)||a.title.localeCompare(b.title));}
 function lookup(id){return current.find(e=>e.id===id)}
 function render(){current=combined();list.replaceChildren();const q=clean(search.value).toLocaleLowerCase();let count=0;for(const e of current){if(![e.title,e.date,e.venue,e.city].join(' ').toLocaleLowerCase().includes(q))continue;count++;const li=node('li'),b=node('button',`${e.date} · ${e.title}`);b.type='button';if(e.id===active)b.className='active';const small=node('small',(e.visibility==='draft'?'🔒 비공개 · ':'')+(e.media?.length||0)+'개 영상 · '+(e.source?'출처 있음':'출처 없음'));b.append(small);b.onclick=()=>{active=e.id;fill(e);render()};li.append(b);list.append(li)}get('concert-record-count').textContent=`${count}건 · 저장된 수정 ${overrides.length}건`;}
 function fill(item){const e=item||{};form.reset();for(const k of ['id','date','title','venue','city','time','description','source','setsrc','notes'])form.elements.namedItem(k).value=e[k]||'';
  for(const k of ['series','status','visibility']){const f=form.elements.namedItem(k);f.value=e[k]||(k==='series'?'solo':k==='status'?'confirmed':'draft')}
  form.elements.namedItem('solo').checked=e.solo===true;
  form.elements.namedItem('setlist').value=Array.isArray(e.setlist)?e.setlist.join('\n'):'';
  rows.replaceChildren();(Array.isArray(e.media)?e.media:[]).forEach(m=>rows.append(mediaRow(m)));
  get('concert-selected-help').textContent=e.id?`기존 공연 ID: ${e.id} · 원본 기록을 지우지 않고 수정사항만 저장합니다.`:'새 공연은 공식 출처를 확인하고 직접 입력하세요. 기본값은 비공개입니다.';
 }
 function parse(){const e={};for(const k of ['id','date','title','venue','city','time','description','source','setsrc','notes','series','status','visibility'])e[k]=val(form,k);
  e.id=e.id||`manual-${crypto.randomUUID()}`;e.solo=form.elements.namedItem('solo').checked;
  e.setlist=val(form,'setlist').split(/\n/).map(clean).filter(Boolean);
  e.media=[...rows.children].map(w=>({title:clean(w.querySelector('[name="media_title"]').value),kind:w.querySelector('[name="media_kind"]').value,url:clean(w.querySelector('[name="media_url"]').value),credit:clean(w.querySelector('[name="media_credit"]').value),verified:w.querySelector('[name="media_verified"]').checked})).filter(m=>m.url||m.title);
  if(!validDate(e.date))throw Error('공연 날짜를 YYYY-MM-DD 형식으로 입력하세요.');
  if(!e.title||!e.venue)throw Error('공연 제목과 공연장을 입력하세요.');
  if(!isHttps(e.source))throw Error('공연 근거가 되는 실제 HTTPS 출처 링크를 입력하세요.');
  if(e.setsrc&&!isHttps(e.setsrc))throw Error('세트리스트 출처는 HTTPS 링크만 허용합니다.');
  if(e.visibility==='published'&&!['confirmed','scheduled','secondary','fan'].includes(e.status))throw Error('공개 상태가 올바르지 않습니다.');
  for(const m of e.media){if(!m.title||!isHttps(m.url))throw Error('영상마다 실제 제목과 HTTPS 영상 URL이 필요합니다.');if(!m.verified)throw Error('영상 실존·공개 권한을 확인한 항목만 저장할 수 있습니다.');}
  // Editing old fan-sourced records retains original notes; no invented titles or media.
  return e;
 }
 async function save(){try{const e=parse();const next=overrides.filter(x=>x.id!==e.id).concat(e);const {error}=await sb.from('site_content').upsert({key:'concert_archive',payload:{records:next},updated_at:new Date().toISOString()});if(error)throw error;overrides=next;active=e.id;render();fill(e);setMsg('✅ 공연 기록 저장 완료. 공개 기록은 새로고침하면 반영됩니다.')}catch(err){setMsg('공연 저장 실패: '+msgErr(err),true)}}
 async function dropOverride(){if(!active)return;if(!overrides.some(x=>x.id===active)){setMsg('기존 기본 공연은 삭제할 수 없습니다. 수정사항만 초기화할 수 있습니다.');return}if(!confirm('선택 공연의 관리자 수정 기록을 초기화할까요? 신규 수동 추가 공연은 공개 목록에서 사라집니다.'))return;
 const next=overrides.filter(x=>x.id!==active);const {error}=await sb.from('site_content').upsert({key:'concert_archive',payload:{records:next}});if(error){setMsg(error.message,true);return}overrides=next;active=builtin.some(x=>x.id===active)?active:builtin[0]?.id;render();fill(lookup(active));setMsg('관리자 수정사항을 초기화했습니다.');}
 async function uploadVideo(){const file=get('concert-upload-file')?.files?.[0],consent=get('concert-upload-permission')?.checked;
  try{if(!file)throw Error('업로드할 동영상 파일을 선택하세요.');if(!active&&!val(form,'title'))throw Error('먼저 연결할 공연을 선택하세요.');
   if(!consent)throw Error('촬영·공개 권한과 실제 공연 날짜 확인에 동의해야 업로드할 수 있습니다.');
   if(file.size>45*1024*1024)throw Error('한 파일은 45MB 이하만 지원합니다. 큰 영상은 공개 가능한 유튜브 영상 링크를 이용하세요.');
   const allowed={'video/mp4':'mp4','video/webm':'webm'};const ext=allowed[file.type];if(!ext)throw Error('MP4 또는 WebM 파일만 업로드할 수 있습니다.');
   const folder=(active||'draft').replace(/[^A-Za-z0-9_-]/g,'').slice(0,65)||'draft';
   const path=`performances/${folder}/${crypto.randomUUID()}.${ext}`;
   setMsg('동영상 업로드 중… 파일 크기에 따라 시간이 걸릴 수 있습니다.');
   const {error}=await sb.storage.from('concert-videos').upload(path,file,{cacheControl:'3600',contentType:file.type,upsert:false});if(error)throw error;
   const {data}=sb.storage.from('concert-videos').getPublicUrl(path);if(!isHttps(data.publicUrl))throw Error('올바른 공개 영상 주소를 받지 못했습니다.');
   const item=mediaRow({title:file.name.replace(/\.[^.]+$/,''),kind:'upload',url:data.publicUrl,credit:'관리자 확인 업로드',verified:true});rows.append(item);
   get('concert-upload-file').value='';get('concert-upload-permission').checked=false;
   setMsg('✅ 업로드 완료. 아직 공개되지 않았습니다. 반드시 아래 「공연 기록 저장」을 눌러 연결하세요.');
  }catch(err){setMsg('업로드 실패: '+msgErr(err)+' · Supabase 저장소 설정과 파일 제한을 확인하세요.',true)}
 }
 get('concert-new').onclick=()=>{active='';fill(null);render();setMsg('새 공연은 비공개 초안입니다. 확인된 기록만 공개하세요.');};
 get('concert-media-add').onclick=()=>rows.append(mediaRow());
 get('concert-upload-submit').onclick=uploadVideo;
 get('concert-reset').onclick=dropOverride;
 search.addEventListener('input',render);
 form.addEventListener('submit',e=>{e.preventDefault();save()});
 async function load(){try{const {data,error}=await sb.from('site_content').select('payload').eq('key','concert_archive').maybeSingle();if(error)throw error;overrides=Array.isArray(data?.payload?.records)?data.payload.records:[];render();fill(lookup(active)||current[0]);}catch(err){setMsg('공연 기록 불러오기 실패: '+msgErr(err),true)}}
 return{load};
}
