/* AIKO WORLD: verified admin-edited homepage copy. Empty overrides retain built-in translations. */
(()=>{
'use strict';
const entries={
 note:'[data-t="note"]',heroEyebrow:'[data-t="heroEyebrow"]',heroLine1:'[data-t="heroLine1"]',heroLine2:'[data-t="heroLine2"]',heroBody:'[data-t="heroBody"]',heroJapanese:'.hero-jp',
 spotTitle:'[data-t="spotTitle"]',spotIntro:'[data-t="spotIntro"]',rentTitle:'[data-t="rentTitle"]',rentDetail:'[data-t="rentDetail"]',
 latestTitle:'[data-t="latestTitle"]',latestIntro:'[data-t="latestIntro"]',sideNote:'[data-t="sideNote"]',
 scheduleTitle:'[data-t="scheduleTitle"]',scheduleIntro:'[data-t="scheduleIntro"]',
 musicTitle:'[data-t="musicTitle"]',musicIntro:'[data-t="musicIntro"]',musicNote:'[data-t="musicNote"]',
 historyTitle:'[data-t="historyTitle"]',historyIntro:'[data-t="historyIntro"]',
 galleryTitle:'[data-t="galleryTitle"]',galleryIntro:'[data-t="galleryIntro"]',
 aboutTitle1:'[data-t="aboutTitle1"]',aboutTitle2:'[data-t="aboutTitle2"]',aboutIntro:'[data-t="aboutIntro"]',
 connectTitle:'[data-t="connectTitle"]',connectIntro:'[data-t="connectIntro"]',footerWords:'[data-t="footerWords"]'
};
const linkSelectors={agency:'.news-aside a',artist:'.about-body a',unit:'.music .section-head a',x:'.connect-links a:nth-child(1)',instagram:'.connect-links a:nth-child(2)',oval:'.connect-links a:nth-child(3)',hpp:'.connect-links a:nth-child(4)'};
const url=s=>{try{const u=new URL(String(s));return u.protocol==='https:'&&!u.username&&!u.password?u.href:null}catch{return null}};
const lang=()=>document.documentElement.lang?.slice(0,2)||'ko';
let cfgData=null;
function apply(){if(!cfgData)return;const strings=cfgData.texts||{};
 for(const [key,selector] of Object.entries(entries)){
  const selected=document.querySelector(selector);const variants=strings[key];if(!selected||!variants)continue;
  const t=variants[lang()];
  if(typeof t==='string'&&t.trim())selected.textContent=t;
 }
 for(const [key,selector] of Object.entries(linkSelectors)){
  const el=document.querySelector(selector),link=url(cfgData.links?.[key]);if(el&&link)el.href=link;
 }
}
async function load(){await(window.AIKO_CMS_READY||Promise.resolve());const cfg=window.AIKO_CMS_CONFIG||{};
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')||!cfg.publishableKey)return;
 const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),7000);
 try{const hdr={apikey:cfg.publishableKey};if(cfg.publishableKey.startsWith('eyJ'))hdr.Authorization='Bearer '+cfg.publishableKey;
  const res=await fetch(`${cfg.url.replace(/\/$/,'')}/rest/v1/site_content?key=eq.page_copy_v23&select=payload`,{headers:hdr,cache:'no-store',signal:ctrl.signal});
  if(!res.ok)throw Error('HTTP '+res.status);
  const rows=await res.json();if(rows?.[0]?.payload&&typeof rows[0].payload==='object')cfgData=rows[0].payload;
  apply();
 }catch(err){console.warn('AIKO WORLD homepage editor: keeping original copy',err)}finally{clearTimeout(timer)}
}
new MutationObserver(apply).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
// Original site sets translations on language-button clicks. Apply customization once after that handler completes.
document.addEventListener('click',e=>{if(e.target.closest('[data-lang]'))queueMicrotask(apply)});
load();
})();
