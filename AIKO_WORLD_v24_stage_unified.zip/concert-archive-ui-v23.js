/* Concert explorer: each event is individually expandable. No unverified setlists inferred. */
(()=>{'use strict';
const builtin=Array.isArray(window.AIKO_PERFORMANCES)?window.AIKO_PERFORMANCES:[]; let list=[...builtin];
const by=id=>document.getElementById(id), root=by('concert-archive');if(!root)return;
const series=by('ca-series'),year=by('ca-year'),mode=by('ca-mode'),query=by('ca-query'),results=by('ca-results'),more=by('ca-more'),found=by('ca-found');
const active=new Set(); let limit=12;
const dict={
ko:{title:'공연마다, 다른 아이코',intro:'OVAL SISTEM 공연과 아이코의 솔로 무대, 럭키팡팡 팬 행사까지 날짜별로 정리했습니다. 각 카드를 열면 공연 정보·곡목·자료 출처를 확인할 수 있습니다.', shows:'공연·팬 행사',song:'곡목이 기록된 공연',solo:'솔로 관련',series:'공연 구분',year:'연도',mode:'무대 유형',search:'공연·장소·노래 검색',all:'전체',allTypes:'모든 무대',soloOnly:'아이코 솔로 포함',withSongs:'곡목 기록이 있는 공연',tour:'Prologue Tour O',orbit:'orbit CLUB',kichijoji:'키치조지 전 11회',festival:'페스티벌·합동',seoul:'한국 공연',rent:'RENT 2026 · 모린',soloS:'아이코 솔로',fanmeet:'팬미팅·팬사인회',fanInfo:'팬 교류 행사로, 노래 세트리스트는 적용되지 않습니다.',asSolo:'아이코 솔로 코너',check:'상세 보기',close:'접기',pending:'세트리스트 확인 중 — 확실한 곡만 추가합니다.',songHead:'그날의 노래',detail:'공연 이야기',src:'공식·관련 자료 보기 ↗',songSrc:'곡목 기록 출처 ↗',fannote:'곡목은 비공식 팬 기록입니다. 공연 전곡 또는 순서를 확정한 공식 자료가 아닙니다.',statusSecondary:'일정 보조자료 기준',statusFan:'팬 기록',statusScheduled:'예정',date:'일시',place:'장소',filt:'조건에 해당하는',items:'개 기록',more:'12개 더 보기',no:'일치하는 공연이 없습니다.',blurb:'확인된 공연을 먼저 기록하고 세트리스트는 검증되는 대로 업데이트합니다.',info:'공연 정보의 확인 상태와 세트리스트 검증 상태는 서로 다를 수 있습니다. 발매 음원 목록을 실제 공연 선곡으로 오인하지 않도록 구분했습니다.',setlist:'곡목 확인',setlistUnknown:'곡목 확인 중'},
ja:{title:'ステージごとの、愛子',intro:'OVAL SISTEMの公演、愛子のソロ出演、Lucky PangPangのファンイベントを日付ごとに紹介。各カードから会場・日時・歌唱曲・参考資料を確認できます。',shows:'公演・ファンイベント',song:'曲目記録あり',solo:'ソロ関連',series:'公演シリーズ',year:'年',mode:'ステージ',search:'公演・会場・曲を検索',all:'すべて',allTypes:'全公演',soloOnly:'愛子のソロあり',withSongs:'曲目記録あり',tour:'Prologue Tour O',orbit:'orbit CLUB',kichijoji:'吉祥寺 全11回',festival:'フェス・合同',seoul:'韓国公演',rent:'RENT 2026 · モーリーン',soloS:'ソロ出演',fanmeet:'ファンミーティング・サイン会',fanInfo:'ファン交流イベントのため、セットリストの対象外です。',asSolo:'愛子ソロ',check:'詳細を見る',close:'閉じる',pending:'セットリスト調査中。確認できた曲のみ追加します。',songHead:'歌唱曲メモ',detail:'公演概要',src:'資料・公式情報 ↗',songSrc:'セットリスト出典 ↗',fannote:'セットリストはファン記録によるもので、公式な全曲・曲順の保証ではありません。',statusSecondary:'補助資料',statusFan:'ファン記録',statusScheduled:'予定',date:'日時',place:'会場',filt:'条件に合う',items:'件',more:'さらに12件',no:'該当する公演はありません。',blurb:'確認できた公演から掲載。曲順・曲目は裏付けが取れ次第追加します。',info:'公演日程の確度とセットリストの確度は別々に扱っています。',setlist:'曲目あり',setlistUnknown:'曲目調査中'},
en:{title:'A different Aiko, every show',intro:'Individual OVAL SISTEM shows, Aiko solo performances and Lucky PangPang fan events, with dates, details and sources.',shows:'Shows & fan events',song:'With song notes',solo:'Solo highlights',series:'Series',year:'Year',mode:'Stage type',search:'Search show, venue or song',all:'All',allTypes:'Every show',soloOnly:'Includes Aiko solo',withSongs:'Songs documented',tour:'Prologue Tour O',orbit:'orbit CLUB',kichijoji:'Kichijoji all 11',festival:'Festivals & guests',seoul:'Korea shows',rent:'RENT 2026 · Maureen',soloS:'Aiko solo',fanmeet:'Fan meeting & signing',fanInfo:'Fan interaction event; a concert setlist is not applicable.',asSolo:'Aiko solo segment',check:'Show details',close:'Close details',pending:'Setlist unverified; no titles have been guessed.',songHead:'Song notes',detail:'About this show',src:'Event information ↗',songSrc:'Setlist source ↗',fannote:'Fan-submitted setlist; not an official complete or ordered performance record.',statusSecondary:'Secondary source',statusFan:'Fan record',statusScheduled:'Upcoming',date:'Date',place:'Venue',filt:'Matching',items:'shows',more:'Show 12 more',no:'No shows match.',blurb:'Verified event information first; add setlists only when supported.',info:'Event verification and setlist verification are separate; a recording of an original song is not evidence it was performed here.',setlist:'Setlist notes',setlistUnknown:'Setlist pending'}};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const lang=()=>['ko','ja','en'].includes(document.documentElement.lang)?document.documentElement.lang:'ko';const t=k=>dict[lang()][k]||dict.ko[k]||k;
function tr(){root.querySelectorAll('[data-ca]').forEach(el=>el.textContent=t(el.dataset.ca));query.placeholder=t('search');}
function seriesName(x){return t(x==='solo'?'soloS':x)}
function summary(e){if(lang()==='ko')return e.description;
const messages={
rent:{ja:'ミュージカルRENT 2026の愛子モーリーン出演回。歌唱曲・撮影映像は未確認です。',en:'Verified Aiko-as-Maureen performance in RENT 2026. No songs or videos added without evidence.'},
solo:{ja:'愛子の個人歌唱・ソロコーナーに関する記録です。',en:'Documented solo appearance or solo segment.'},tour:{ja:'山手線を巡ったPrologue Tour Oの個別公演です。',en:'Individual stop on the Prologue Tour O around the Yamanote Line.'},kichijoji:{ja:'吉祥寺SHUFFLEで開催されたシリーズ公演です。',en:'A show from the Kichijoji SHUFFLE series.'},seoul:{ja:'韓国・ソウルでのライブ公演です。',en:'Live event in Seoul, South Korea.'},orbit:{ja:'OVAL SISTEMのコンパクトライブシリーズです。',en:'Part of the OVAL SISTEM Compact Live series.'},festival:{ja:'フェスティバル・ゲスト公演の記録です。',en:'Festival or guest-stage appearance.'},fanmeet:{ja:'ラッキーパンパンのファン交流イベントです。',en:'Lucky PangPang fan event.'}};
return messages[e.series]?.[lang()]||'';}
function https(u){try{const p=new URL(String(u||''));return p.protocol==='https:'?p.href:''}catch{return ''}}
function mediaBlock(e){
 const entries=(Array.isArray(e.media)?e.media:[]).filter(m=>m&&m.verified===true&&https(m.url));
 if(!entries.length)return `<p class="ca-note">${lang()==='ja'?'公開確認済みの公演映像は未登録です。':lang()==='en'?'No verified performance video has been added.':'확인된 공연 영상은 아직 등록되지 않았습니다.'}</p>`;
 return `<div class="ca-media"><strong>${lang()==='ja'?'公演映像':lang()==='en'?'Performance videos':'공연 영상'} · ${entries.length}</strong>${entries.map(m=>{
 const label=esc(m.title||'공연 영상'); const url=esc(https(m.url));
 const via=esc(m.credit||'');
 return `<div class="ca-media-item"><span>🎬 ${label}${via?` <small>· ${via}</small>`:''}</span>${m.kind==='upload'?`<video controls preload="none" playsinline src="${url}" aria-label="${label}"></video>`:''}<a href="${url}" target="_blank" rel="noopener noreferrer">${m.kind==='upload'?'영상 새 창으로 열기 ↗':'영상 링크 열기 ↗'}</a></div>`
 }).join('')}</div>`;
}
function card(e){
 const isOpen=active.has(e.id),isSolo=Boolean(e.solo),flagged=e.status!=='confirmed';
 const songs=Array.isArray(e.setlist)?e.setlist:[];
 const id=esc(e.id);
 return `<article class="ca-card"><button type="button" class="ca-expand" data-id="${id}" aria-expanded="${isOpen}" aria-controls="${id}-detail"><div class="ca-tags"><span class="ca-tag ${isSolo?'solo':''}">${esc(seriesName(e.series))}</span>${isSolo?'<span class="ca-tag solo">SOLO</span>':''}${songs.length?`<span class="ca-tag">♪ ${t('setlist')}</span>`:''}${flagged?`<span class="ca-tag ${esc(e.status)}">${t(e.status==='fan'?'statusFan':e.status==='secondary'?'statusSecondary':'statusScheduled')}</span>`:''}<span class="ca-time">${esc(e.date)}</span></div><h4>${esc(e.title)}</h4><div class="ca-meta">◷ ${esc(e.time||'—')}${e.city?' · '+esc(e.city):''}</div><div class="ca-meta">⌁ ${esc(e.venue||'—')}</div><p class="ca-excerpt">${esc(summary(e)||'')}</p><span class="ca-show">${t(isOpen?'close':'check')} ${isOpen?'−':'＋'}</span></button><div class="ca-detail" id="${id}-detail" ${isOpen?'':'hidden'}><strong>${t('detail')}</strong><div>${esc(summary(e)||'')}</div>${songs.length?`<p style="margin-top:12px"><strong>${t('songHead')} · ${songs.length}</strong></p><ol>${songs.map(song=>`<li>${esc(song)}</li>`).join('')}</ol><div class="ca-note">${t('fannote')} ${esc(lang()==='ko'?e.notes:'')}</div>`:`<p class="ca-note">${e.series==='fanmeet'?t('fanInfo'):t('pending')}</p>`}${e.status==='secondary'?`<p class="ca-note">${t('statusSecondary')}: ${lang()==='ko'?'날짜와 장소는 공식 개별 페이지를 추가 확인해야 합니다.':t('info')}</p>`:''}${https(e.source)?`<a href="${esc(https(e.source))}" target="_blank" rel="noopener noreferrer">${t('src')}</a>`:''}${https(e.setsrc)&&e.setsrc!==e.source?` <a href="${esc(https(e.setsrc))}" target="_blank" rel="noopener noreferrer">${t('songSrc')}</a>`:''}<div class="ca-video-wrapper">${mediaBlock(e)}</div></div></article>`
}
function update(){tr();const q=query.value.trim().toLocaleLowerCase();const rows=list.filter(e=>(series.value==='all'||e.series===series.value)&&(year.value==='all'||e.date.startsWith(year.value))&&(mode.value==='all'||(mode.value==='solo'?e.solo:e.setlist.length>0))&&[e.title,e.date,e.venue,e.city,e.description,...(Array.isArray(e.setlist)?e.setlist:[]),...(Array.isArray(e.media)?e.media.map(m=>m.title||''):[])].join(' ').toLocaleLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date)||b.time.localeCompare(a.time));found.textContent=`${t('filt')} ${rows.length}${lang()==='en'?' ':''}${t('items')}`;results.innerHTML=rows.length?rows.slice(0,limit).map(card).join(''):`<div class="ca-none">${t('no')}</div>`;more.classList.toggle('ca-hidden',limit>=rows.length);more.textContent=t('more');}
const ss=['rent','tour','orbit','kichijoji','seoul','festival','solo','fanmeet'];series.innerHTML='<option value="all"></option>'+ss.map(x=>`<option value="${x}"></option>`).join('');
series.children[0].dataset.ca='all';ss.forEach((x,i)=>series.children[i+1].dataset.ca=x==='solo'?'soloS':x);
year.innerHTML='<option value="all" data-ca="all"></option>'+[...new Set(list.map(x=>x.date.slice(0,4)))].sort().reverse().map(y=>`<option value="${y}">${y}</option>`).join('');
mode.innerHTML='<option value="all" data-ca="allTypes"></option><option value="solo" data-ca="soloOnly"></option><option value="song" data-ca="withSongs"></option>';
for(const x of [series,year,mode,query])x.addEventListener(x===query?'input':'change',()=>{limit=12;update();});
more.addEventListener('click',()=>{limit+=12;update()});
results.addEventListener('click',e=>{const btn=e.target.closest('.ca-expand');if(!btn)return;const id=btn.dataset.id;if(active.has(id))active.delete(id);else active.add(id);update();const node=results.querySelector(`.ca-expand[data-id="${id}"]`);if(node)node.focus({preventScroll:true});});
function rebuild(){
 const oldSeries=series.value, oldYear=year.value, oldMode=mode.value;
 const years=[...new Set(list.map(e=>e.date.slice(0,4)))].sort().reverse();
 year.innerHTML='<option value="all" data-ca="all"></option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
 if(years.includes(oldYear))year.value=oldYear;
 if([...series.options].some(o=>o.value===oldSeries))series.value=oldSeries;
 if([...mode.options].some(o=>o.value===oldMode))mode.value=oldMode;
 root.querySelector('#ca-ct').textContent=list.length;
 root.querySelector('#ca-sc').textContent=list.filter(e=>Array.isArray(e.setlist)&&e.setlist.length).length;
 root.querySelector('#ca-solo').textContent=list.filter(e=>e.solo).length;
 update();
}
async function loadCuratedRecords(){
 const cfg=window.AIKO_CMS_CONFIG||{};
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'')||!cfg.publishableKey)return;
 try{
  const uri=cfg.url.replace(/\/$/,'')+'/rest/v1/site_content?key=eq.concert_archive&select=payload';
  const h={'apikey':cfg.publishableKey};if(cfg.publishableKey.startsWith('eyJ'))h.Authorization='Bearer '+cfg.publishableKey;
  const resp=await fetch(uri,{headers:h,cache:'no-store'});if(!resp.ok)throw Error('HTTP '+resp.status);
  const res=await resp.json();const overrides=res?.[0]?.payload?.records;
  if(!Array.isArray(overrides))return;
  const merged=new Map(builtin.map(e=>[e.id,e]));
  for(const item of overrides){
   if(!item||typeof item.id!=='string'||!item.id||!/^\d{4}-\d{2}-\d{2}$/.test(item.date||''))continue;
   if(item.visibility==='draft')continue;
   if(!https(item.source))continue;
   const base=merged.get(item.id)||{};
   merged.set(item.id,{...base,...item,setlist:Array.isArray(item.setlist)?item.setlist:[],media:Array.isArray(item.media)?item.media:[]});
  }
  list=[...merged.values()];rebuild();
 }catch(err){console.warn('Concert records: showing saved built-in archive',err)}
}
document.querySelectorAll('[data-lang]').forEach(b=>b.addEventListener('click',()=>requestAnimationFrame(update)));
rebuild();loadCuratedRecords();
})();
