'use strict';
/* Idempotent v23 addon. Run after existing v18 website extraction and v21+v22 installation. */
const fs=require('node:fs');
const path=require('node:path');
const must=['public/index.html','public/admin/index.html','public/admin/admin.mjs','public/concert-archive.js'];
for(const file of must)if(!fs.existsSync(file))throw Error('[v23] Missing original site file: '+file+'. Check build command order.');
function modify(file,fn){let before=fs.readFileSync(file,'utf8'),after=fn(before);if(after!==before){fs.writeFileSync(file,after);console.log('[v23] Updated',file)}else console.log('[v23] Already installed',file)}
function head(html,htmlTag){if(!html.includes(htmlTag))html=html.replace('</head>',htmlTag+'\n</head>');return html}
function body(html,htmlTag){if(!html.includes(htmlTag))html=html.replace('</body>',htmlTag+'\n</body>');return html}
modify('public/admin/index.html',html=>{
 html=head(html,'<link rel="stylesheet" href="v23-admin.css">');
 if(!html.includes('data-pane="concert"')){
  const panel=fs.readFileSync(path.join(__dirname,'concert-panel-v23.html'),'utf8');
  if(!html.includes('<p id="status"'))throw Error('[v23] Cannot find admin status anchor.');
  html=html.replace('<p id="status"',panel+'\n<p id="status"');
 }
 if(!html.includes('src="../concert-archive.js"'))html=html.replace('<script src="../episode-catalog.js">','<script src="../concert-archive.js"></script><script src="../episode-catalog.js">');
 html=body(html,'<script type="module" src="v23-admin.mjs"></script>');
 return html;
});
modify('public/index.html',html=>body(html,'<script src="aiko-page-v23.js" defer></script>'));
// Existing v18 version lacks the admin-backed concert overrides. Upgrade the renderer but preserve data/catalog.
const renderer='public/concert-archive-ui.js';
if(!fs.existsSync(renderer)||!fs.readFileSync(renderer,'utf8').includes('loadCuratedRecords')){
 fs.copyFileSync(path.join(__dirname,'concert-archive-ui-v23.js'),renderer);
 console.log('[v23] Activated concert record overrides and permitted video players (no catalog data changed)');
}
console.log('[v23] Complete: admin and homepage editable. No schedule/video records inserted.');
