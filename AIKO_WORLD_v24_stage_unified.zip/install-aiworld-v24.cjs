/* Non-destructive, repeatable v24 installer. Run after base site + v21/v22 + v23. */
'use strict';
const fs=require('node:fs');
// Include the v23 editor extension when an older admin has not yet been upgraded.
require('./install-aiworld-v23.cjs');
const assertFile=x=>{if(!fs.existsSync(x))throw Error('[v24] missing '+x+'; check install order')};
['public/index.html','public/admin/index.html','public/concert-archive-ui.js','public/concert-stories.js','public/history-media.js','public/admin/v23-admin.mjs'].forEach(assertFile);
function add(file,tag,anchor){let s=fs.readFileSync(file,'utf8');if(!s.includes(tag)){if(!s.includes(anchor))throw Error('[v24] no '+anchor+' in '+file);s=s.replace(anchor,tag+'\n'+anchor);fs.writeFileSync(file,s);console.log('[v24] linked '+tag)}else console.log('[v24] already linked '+file)}
add('public/index.html','<link rel="stylesheet" href="stage-unified.css">','</head>');
add('public/index.html','<script src="stage-unified.js" defer></script>','</body>');
add('public/admin/index.html','<link rel="stylesheet" href="stage-admin-hub.css">','</head>');
add('public/admin/index.html','<script type="module" src="stage-admin-hub.mjs"></script>','</body>');
console.log('[v24] Existing dates, media, setlists, broadcast archives, permissions and Supabase data preserved.');
