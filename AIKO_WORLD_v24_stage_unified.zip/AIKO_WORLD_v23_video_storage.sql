-- 愛子 WORLD v21 · 공연 영상 전용 저장소와 최소 권한
-- Supabase → SQL Editor에서 관리자 계정으로 실행. 다시 실행해도 안전합니다.
-- 기존 site_content, site_admins, broadcast_video_links 데이터에는 영향을 주지 않습니다.
-- site_content의 기존 RLS 및 public.is_site_admin() 함수를 그대로 사용합니다.
-- 실제 공개 권한이 있는 영상만 업로드하세요.

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('concert-videos', 'concert-videos', true, 47185920, ARRAY['video/mp4','video/webm'])
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 47185920,
  allowed_mime_types = ARRAY['video/mp4','video/webm'];

DROP POLICY IF EXISTS "AIKO concert videos public view" ON storage.objects;
CREATE POLICY "AIKO concert videos public view" ON storage.objects
 FOR SELECT TO anon, authenticated
 USING (bucket_id = 'concert-videos');

DROP POLICY IF EXISTS "AIKO concert videos admin upload" ON storage.objects;
CREATE POLICY "AIKO concert videos admin upload" ON storage.objects
 FOR INSERT TO authenticated
 WITH CHECK (bucket_id = 'concert-videos' AND name LIKE 'performances/%' AND (SELECT public.is_site_admin()));

DROP POLICY IF EXISTS "AIKO concert videos admin update" ON storage.objects;
CREATE POLICY "AIKO concert videos admin update" ON storage.objects
 FOR UPDATE TO authenticated
 USING (bucket_id = 'concert-videos' AND (SELECT public.is_site_admin()))
 WITH CHECK (bucket_id = 'concert-videos' AND (SELECT public.is_site_admin()));

DROP POLICY IF EXISTS "AIKO concert videos admin remove" ON storage.objects;
CREATE POLICY "AIKO concert videos admin remove" ON storage.objects
 FOR DELETE TO authenticated
 USING (bucket_id = 'concert-videos' AND (SELECT public.is_site_admin()));

-- Note: Supabase project-wide upload limit may be less than the bucket's maximum.
SELECT id,name,public,file_size_limit,allowed_mime_types
FROM storage.buckets WHERE id='concert-videos';
