愛子 WORLD · v23 관리자 통합 보강 패치
==================================

기존 v18 + v21/v22 통합 설치를 유지하면서 누락됐던 관리자 편집 기능을 추가합니다.
웹사이트의 공연 일정·영상·사진·자료 기록을 자동으로 생성하거나 초기화하지 않습니다.

[관리자 새 메뉴]
- 🏠 홈페이지 편집 : 첫화면/소개/각 영역 제목·설명(한국어/일본어/영어), 공식 링크
- 📚 발자취 편집 : 기존 활동 연대표 수정·추가·삭제
- 🎵 음악 카드 편집 : 첫 화면 음악 콘텐츠 및 등록된 영상 링크 수정
- 🎤 공연 상세·영상 : 기존 공연 기록의 출처·세트리스트·영상 링크, MP4/WebM 파일 업로드(권리 확인 필수)
- v21/v22 통합 메뉴(발자취 미디어 및 공연별 세트리스트·사진)는 계속 유지됩니다.

[설치]
1. 현재 정상 작동하는 Netlify Build command 전체를 미리 복사해 백업합니다.
2. GitHub aiko-world 저장소의 최상위에 AIKO_WORLD_v23_admin_patch.zip을 압축 해제하지 않고 업로드·Commit합니다.
3. Netlify Project configuration -> Build settings -> Configure -> Build command 마지막에 한 번만 추가합니다.

   && unzip -o AIKO_WORLD_v23_admin_patch.zip && node install-aiworld-v23.cjs

4. GitHub에 Commit하여 자동 배포가 완료되었다면 Trigger deploy를 또 누르지 않습니다.
   설정 변경 후에는 새 커밋 또는 수동 배포가 필요할 수 있습니다.
5. Netlify Deploys가 Published인지 확인합니다.
6. https://aiko-world.com/admin/ 접속 -> 관리자 로그인 -> 새로운 메뉴 확인.

[기존 Build command 주의]
- AIKO_WORLD_v18_video_manager.zip 추출 및 복사 명령, v21/v22 통합 ZIP 명령을 지우면 안 됩니다.
- v23 명령은 마지막에 추가합니다. 동일 설치 명령을 중복 추가하지 않습니다.
- 패치는 원래의 public/data.js, 공연 기록 JS 데이터, Supabase 기존 자료를 삭제하지 않습니다.
- 관리자 메뉴가 안 보일 때에는 Ctrl+Shift+R로 새로고침하고 Netlify 배포 로그를 확인합니다.

[동영상 파일 업로드 - 최초 1회 SQL 필요]
- 실제 MP4/WebM 파일을 올리려면 AIKO_WORLD_v23_video_storage.sql 을 Supabase SQL Editor에서 실행해야 합니다.
- 기존에 concert-videos 저장소 SQL을 실행했다면 중복 실행할 필요는 없습니다.
- 45MB 이하, 공연 촬영과 게시가 허용된 자신의 영상만 업로드. 업로드한 뒤 공연 기록 저장 버튼을 눌러야 공개 페이지에 연결됩니다.
- v22 공연별 카드 메뉴는 유튜브 영상 링크 + 사진 업로드 기능입니다. 동영상 파일은 🎤 공연 상세·영상 메뉴에서 업로드할 수 있습니다.

[운영 원칙]
- 새 일정, 세트리스트, 미확인 동영상은 자동 추가하지 않습니다.
- 관리자 수정사항은 site_content 테이블에 저장됩니다. 기존 데이터가 우선 보존됩니다.
- 발자취 신규 항목은 출처 URL 필수, 공연 신규 항목은 실제 출연 근거 URL 필수.
- 변경 후에는 사이트를 새로고침하여 한국어/일본어/영어를 각각 확인합니다.

[검수]
- Node.js --check 문법 검사 및 설치 2회 반복(중복 방지) 확인.
- 실제 귀하의 Supabase 계정 로그인과 동영상 업로드의 성공 여부는 이 환경에서 검증하지 못했습니다.
