愛子 WORLD v24 | 공연마다, 다른 아이코 통합 아카이브
================================================

목표:
- 기존 '공연마다, 다른 아이코' 안에 4개 보기 통합
  (공연 목록 / 공연별 세트리스트·사진·영상 / 발자취 사진·영상 / 시간순 발자취)
- 기존 방송 무대 모음은 별도 유지
- 기존 v21 history_media, v22 concert_stories, v23 concert_archive의 모든 기록 보존
- 관리자 메뉴 '🎤 공연 통합 관리'에 각 편집 메뉴 연결
- 공연/영상/곡목 데이터를 자동 생성하지 않음. SQL 실행 없음.

설치:
1) 기존 GitHub 사이트 저장소 최상위 경로에 AIKO_WORLD_v24_stage_unified.zip 업로드(압축 해제 X)
2) Netlify → Project configuration → Build settings
   기존 Build command의 맨 끝에 다음 부분을 추가:
   && unzip -o AIKO_WORLD_v24_stage_unified.zip && node install-aiworld-v24.cjs
3) 반드시 기존 v18 → v21·v22 뒤에 실행합니다. v23 관리자 확장 기능은 v24 ZIP 안에 포함돼 자동 적용됩니다. 이미 설치했다면 중복 적용을 방지합니다.
4) 변경사항을 GitHub에 Commit 하면 Netlify 자동 배포. 중복 Trigger deploy 하지 마세요.
5) Published 후 https://aiko-world.com/#concert-archive 에서 4개 보기 확인
6) 관리자 https://aiko-world.com/admin/ → 🎤 공연 통합 관리 확인

주의:
- '사진/영상 발자취'는 공연별 기록이 아닌 일반 활동 미디어이므로 별도 탭으로 표시합니다.
- 기존 공연 카드와 '공연별 기록' 카드는 날짜+장소(또는 동일 제목)가 유일하게 맞을 때만 연결 버튼을 표시합니다.
- 모든 공연을 임의로 합치거나 없는 세트리스트/영상/공연을 추가하지 않습니다.
- 본 패치는 사이트 코드를 변경할 뿐, Supabase 기존 데이터나 일정을 삭제·덮어쓰지 않습니다.
- 기존 사진/동영상 파일 업로드는 기존 v21·v22·v23의 스토리지 설정과 권한이 있어야 합니다.
- 실제 배포된 사용자 계정과 Supabase를 통한 읽기/쓰기 검증은 별도 확인이 필요합니다.
