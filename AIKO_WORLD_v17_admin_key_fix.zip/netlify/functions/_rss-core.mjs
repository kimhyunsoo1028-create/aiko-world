/* Server-only RSS intake. Reads Supabase service key from Functions environment.
   All items are inserted with pending status; never publish without approval. */
const hosts=new Set(['mfi-inc.tokyo','ovalsistem.work','www.youtube.com']);
const env=name => typeof Netlify!=='undefined'&&Netlify.env?Netlify.env.get(name):process.env[name];
const DB=()=>{
  const url=env('SUPABASE_URL');const key=env('SUPABASE_SERVICE_ROLE_KEY');
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(url||'')||!key)throw new Error('Server Supabase environment variables are not set');
  return {url:url.replace(/\/$/,''),key};
};
function validateFeed(s){const u=new URL(s);if(u.protocol!=='https:'||!hosts.has(u.hostname)||u.username||u.password)throw new Error('RSS host is not approved');return u.href}
const entities=x=>String(x||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/&(#x[0-9a-f]+|#[0-9]+|amp|lt|gt|quot|apos|nbsp);/gi,(full,a)=>{const table={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' '};if(a[0]==='#'){const n=a[1].toLowerCase()==='x'?parseInt(a.slice(2),16):parseInt(a.slice(1),10);return Number.isFinite(n)?String.fromCodePoint(n):full}return table[a.toLowerCase()]||full}).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
const xmlTag=(item,name)=>{const esc=name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const m=item.match(new RegExp(`<${esc}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${esc}>`,'i'));return m?m[1]:''};
function readItems(xml){
 const chunks=[...xml.matchAll(/<(item|entry)(?:\s[^>]*)?>([\s\S]*?)<\/\1>/gi)].slice(0,40);
 return chunks.map(([,kind,item])=>{
    const title=entities(xmlTag(item,'title'));
    let link=entities(xmlTag(item,'link'));
    if(!link){link=item.match(/<link\s+[^>]*href=["']([^"']+)/i)?.[1]||''}
    const description=entities(xmlTag(item,'description')||xmlTag(item,'summary')||xmlTag(item,'content:encoded')).slice(0,700);
    const date=entities(xmlTag(item,'pubDate')||xmlTag(item,'published')||xmlTag(item,'updated'));
    const parsed=Date.parse(date);
    return {title:title.slice(0,240),url:link,description,published_at:Number.isFinite(parsed)?new Date(parsed).toISOString():null}
 }).filter(e=>e.title&&isAllowedArticle(e.url));
}
function isAllowedArticle(s){try{const u=new URL(s);return u.protocol==='https:'&&hosts.has(u.hostname)&&!u.username&&!u.password}catch{return false}}
async function db(path,opts={}){const {url,key}=DB();const r=await fetch(url+'/rest/v1/'+path,{...opts,headers:{apikey:key,...(key.startsWith('eyJ')?{Authorization:'Bearer '+key}:{}),'Content-Type':'application/json',...opts.headers}});if(!r.ok)throw new Error('Supabase REST '+r.status+' '+(await r.text()).slice(0,300));return r.status===204?null:await r.json()}
export async function isEditor(jwt){
 if(!jwt)return false;const {url,key}=DB();
 const u=await fetch(url+'/auth/v1/user',{headers:{apikey:key,Authorization:'Bearer '+jwt}});
 if(!u.ok)return false;const user=await u.json();if(!user?.id)return false;
 const rows=await db('site_admins?select=user_id&user_id=eq.'+encodeURIComponent(user.id));return rows.length>0;
}
export async function collect(){
 const sources=await db('feed_sources?select=id,name,url,enabled&enabled=eq.true&limit=30');let inserted=0,checked=0,errors=[];
 for(const s of sources){
  try{
    const feed=validateFeed(s.url);
    const r=await fetch(feed,{headers:{'User-Agent':'AIKOWORLD-FanSite/0.7 (+public RSS review)',Accept:'application/rss+xml,application/atom+xml,text/xml,application/xml'},redirect:'manual',signal:AbortSignal.timeout(6500)});
    if(!r.ok)throw new Error('RSS HTTP '+r.status);
    const body=await r.text();if(body.length>1000000)throw new Error('Feed is too large');
    const items=readItems(body);checked++;
    for(const x of items){
      const row={...x,source_id:s.id,source_name:s.name,status:'pending'};
      const found=await db('feed_inbox?select=id&url=eq.'+encodeURIComponent(row.url)+'&limit=1');
      if(found.length)continue;
      await db('feed_inbox',{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify(row)});inserted++;
    }
  }catch(e){errors.push(`${s.name}: ${e.message}`)}
 }
 return {checked,inserted,errors};
}
