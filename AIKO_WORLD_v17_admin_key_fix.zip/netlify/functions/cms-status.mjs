/* Read-only function status for integration checks; never returns secrets. */
const env = name => (typeof Netlify !== 'undefined' && Netlify.env) ? Netlify.env.get(name) : process.env[name];
export default async function(request) {
  if(request.method!=='GET') return Response.json({error:'Method not allowed'},{status:405});
  return Response.json({
    name:'AIKO WORLD CMS',
    deployed:true,
    publicConfigPresent:Boolean(env('SUPABASE_URL') && env('SUPABASE_PUBLISHABLE_KEY')),
    serverKeyPresent:Boolean(env('SUPABASE_SERVICE_ROLE_KEY')),
    moderation:'manual approval required',
    note:'This status does not verify database/network access or scheduled execution.'
  },{headers:{'Cache-Control':'no-store'}});
}
