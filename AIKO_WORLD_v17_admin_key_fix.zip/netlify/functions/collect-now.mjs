import {collect,isEditor} from './_rss-core.mjs';
export default async function(request){
 if(request.method!=='POST')return Response.json({error:'Method not allowed'},{status:405});
 try{
  const token=request.headers.get('authorization')?.match(/^Bearer (.+)$/i)?.[1];
  if(!await isEditor(token))return Response.json({error:'관리자 인증이 필요합니다.'},{status:403});
  return Response.json(await collect());
 }catch(e){return Response.json({error:e.message},{status:500})}
}
