import {collect} from './_rss-core.mjs';
export default async function(){try{const result=await collect();console.log('AIKO RSS:',JSON.stringify(result));return Response.json(result)}catch(e){console.error(e);return Response.json({error:e.message},{status:500})}}
export const config={schedule:'0 */6 * * *'};
