/* Read-only live data layer. Original v0.6 continues to work if CMS isn't configured. */
(async () => {
  const cfg = window.AIKO_CMS_CONFIG || {};
  const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url || '') &&
    cfg.publishableKey && !cfg.publishableKey.includes('PASTE_');
  const cleanUrl = s => {
    try {const u=new URL(s, location.href);return ['https:','http:'].includes(u.protocol)?u.href:null}catch{return null}
  };
  const by = id => document.getElementById(id);
  const lang = () => document.querySelector('[data-lang][aria-pressed=true]')?.dataset.lang || 'ko';
  const local = item => typeof item==='string'?item:(item?.[lang()]||item?.ko||item?.ja||'');
  const banner = msg => {
    const note=document.querySelector('.site-cms-info');
    if(note) note.textContent=msg;
  };
  const get = async (table, query) => {
    const c=new AbortController();const timeout=setTimeout(()=>c.abort(),6500);
    try {
      const res=await fetch(`${cfg.url.replace(/\/$/,'')}/rest/v1/${table}?${query}`, {
        headers: {'apikey':cfg.publishableKey,...(cfg.publishableKey.startsWith('eyJ')?{Authorization:`Bearer ${cfg.publishableKey}`}:{})},
        signal:c.signal,cache:'no-store'
      });
      if(!res.ok)throw new Error(`${table}: HTTP ${res.status}`);
      return await res.json();
    } finally{clearTimeout(timeout)}
  };
  const loadScript = src => new Promise((resolve,reject)=>{
    const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=reject;document.body.appendChild(s)
  });
  let articles=[], inbox=[];
  if(configured){
    try {
      const [content,published,approved]=await Promise.all([
        get('site_content','select=key,payload'),
        get('site_articles','select=id,title_ko,title_ja,title_en,body_ko,body_ja,body_en,source_url,created_at&status=eq.published&order=created_at.desc&limit=20'),
        get('feed_inbox','select=id,title,url,source_name,published_at&status=eq.approved&order=published_at.desc&limit=25')
      ]);
      for(const row of content||[]) {
        if(['events','archive','media'].includes(row.key)&&Array.isArray(row.payload)) {
          window.AIKO_DATA[row.key]=row.payload;
        }
        if(row.key==='gallery'&&Array.isArray(row.payload)){
          row.payload.slice(0,4).forEach((item,i)=>{
            const uri=cleanUrl(item.src);if(!uri)return;
            const hero=document.querySelectorAll('.photo-mosaic img')[i];
            const tile=document.querySelectorAll('.character-gallery .gallery-shot')[i];
            if(hero){hero.src=uri;hero.alt=local(item.alt)||'아이코 캐릭터'}
            if(tile){tile.href=uri;const img=tile.querySelector('img');if(img){img.src=uri;img.alt=local(item.alt)||'아이코 캐릭터'}}
          });
        }
      }
      articles=published||[];inbox=approved||[];
      banner('공식 소식은 관리자가 확인한 뒤 게시합니다.');
    } catch (err) {
      console.warn('AIKO WORLD: live data unavailable; showing built-in archive.',err);
      banner('기본 저장 일정 표시 중 · 최신 공지는 공식 출처를 확인하세요.');
    }
  }else{
    banner('관리자 연동 설정 전 · 기존 일정 표시 중');
  }
  function updateNewsLanguage(){
    const name={ko:['愛子 WORLD 새로운 소식 ✳','새 무대, 새 노래, 반가운 이야기. 확인된 소식을 만나보세요.'],ja:['愛子 WORLD ニュース ✳','新しいステージも、新しい歌も。確認できたニュースをお届けします。'],en:['AIKO WORLD news ✳','New stages, new songs, and updates checked before sharing.']}[lang()];
    const h=document.querySelector('.cms-news-title');const p=document.querySelector('.cms-news-sub');
    if(h)h.textContent=name[0];if(p)p.textContent=name[1];
  }
  window.addEventListener('aiko:language',updateNewsLanguage);
  updateNewsLanguage();
  const news=by('cms-news-list');
  if(news){
    const cards=[...articles.map(x=>({type:'FAN UPDATE',date:x.created_at,title:local({ko:x.title_ko,ja:x.title_ja,en:x.title_en}),body:local({ko:x.body_ko,ja:x.body_ja,en:x.body_en}),url:x.source_url})),
      ...inbox.map(x=>({type:'OFFICIAL SOURCE · APPROVED',date:x.published_at,title:x.title,body:x.source_name,url:x.url}))]
      .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).slice(0,9);
    if(!cards.length){news.textContent='등록된 새 소식이 없습니다. 공식 링크에서 최신 공지를 확인해 주세요.';}
    else{
      news.replaceChildren();
      cards.forEach(x=>{
        const card=document.createElement('article');card.className='cms-news-card';
        const small=document.createElement('small');small.textContent=x.type+' · '+String(x.date||'').slice(0,10);
        const h=document.createElement('h3');h.textContent=x.title||'새 소식';
        const p=document.createElement('p');p.textContent=(x.body||'').slice(0,260);
        const a=document.createElement('a');const u=cleanUrl(x.url||'');a.textContent='출처 확인 ↗';a.target='_blank';a.rel='noopener noreferrer';if(u)a.href=u;else a.hidden=true;
        card.append(small,h,p,a);news.append(card)
      });
    }
  }
  /* Initialize existing site scripts AFTER the remote events data has loaded. */
  try {await loadScript('app.js');await loadScript('v02.js');await loadScript('v07-live.js')}
  catch (err) {console.error('Site JS failed to load:',err)}
})();
