/* Historical chapters with source links; official facts, editorial summaries. */
window.AIKO_HISTORY_CHAPTERS=[
  {
    "id": "ash",
    "number": "01",
    "date": "2018—2024",
    "name": "ACTOR’S SCHOOL HIROSHIMA",
    "kind": "THE BEGINNING",
    "badge": {
      "ko": "히로시마에서 시작된 꿈",
      "ja": "広島から始まった夢",
      "en": "Where the dream began"
    },
    "title": {
      "ko": "목소리와 춤을 배운 시간",
      "ja": "歌とダンスを磨いた日々",
      "en": "Learning to sing and move"
    },
    "description": {
      "ko": "2018년 39기생으로 액터즈스쿨 히로시마(ASH)에 입학한 아이코. 보컬과 댄스를 함께 배우며 경험을 쌓았고, SPL∞ASH의 초록색 멤버로 지역 공연과 무대에 섰습니다. 2024년 11월 졸업 라이브까지 이어진 시절입니다.",
      "ja": "2018年、39期生としてアクターズスクール広島（ASH）に入学。歌とダンスを学び、SPL∞ASHの緑色担当として地域のステージを経験。2024年11月の卒業ライブまでをたどります。",
      "en": "Aiko joined Actors School Hiroshima as a 39th-class student in 2018. Training in vocals and dance led to performing with SPL∞ASH as its green member, culminating in a graduation live in November 2024."
    },
    "facts": [
      {
        "date": "2018",
        "desc": {
          "ko": "ASH 39기 입학. 보컬과 댄스 레슨을 시작하며 가수의 꿈에 도전.",
          "ja": "ASH第39期生として入学。ボーカルとダンスを学び始める。",
          "en": "Joined ASH as part of its 39th class and began vocal/dance training."
        }
      },
      {
        "date": "2022.06",
        "desc": {
          "ko": "학교 유닛 SPL∞ASH에 연습생으로 참가.",
          "ja": "スクールユニットSPL∞ASHに研修生として参加。",
          "en": "Joined the school group SPL∞ASH as a trainee."
        }
      },
      {
        "date": "2022.12",
        "desc": {
          "ko": "SPL∞ASH 정식 멤버로 승격. 담당 색은 초록색.",
          "ja": "SPL∞ASH正規メンバーに昇格。担当カラーは緑色。",
          "en": "Promoted to a full SPL∞ASH member; her color was green."
        }
      },
      {
        "date": "2024.03",
        "desc": {
          "ko": "ASH SPRING ACT에서 솔로 〈かもめが翔んだ日〉, Cen4er*의 〈STAND-ALONE〉, 야나기모토 아이와 〈Roar〉 등 다양한 무대에 참여.",
          "ja": "ASH SPRING ACTでソロ「かもめが翔んだ日」、Cen4er*「STAND-ALONE」、柳本愛との「Roar」などを披露。",
          "en": "Performed a solo “Kamome ga Tonda Hi”, joined Cen4er* for “STAND-ALONE”, and sang “Roar” with Ai Yanagimoto at the ASH Spring Act."
        }
      },
      {
        "date": "2024.11.16",
        "desc": {
          "ko": "에디온 가미야초 홀에서 ASH·SPL∞ASH 졸업 라이브 진행.",
          "ja": "エディオン紙屋町ホールにてASH・SPL∞ASH卒業ライブを開催。",
          "en": "Held her ASH/SPL∞ASH graduation live at Edion Kamiyacho Hall."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "ASH 공식 졸업생 기록",
          "ja": "ASH卒業生プロフィール",
          "en": "ASH alumni profile"
        },
        "url": "https://actors-hiroshima.com/obog/sumidaaiko.html"
      },
      {
        "label": {
          "ko": "ASH 시절 인터뷰·공연 이야기",
          "ja": "ASH時代のインタビュー",
          "en": "ASH interview and performances"
        },
        "url": "https://about-ash.com/57interview-sumidaaiko/"
      },
      {
        "label": {
          "ko": "ASH 졸업 공연 공식 기록",
          "ja": "ASH卒業ライブ公式記録",
          "en": "ASH graduation show record"
        },
        "url": "https://actors-hiroshima.com/activities/"
      }
    ],
    "color": "ash"
  },
  {
    "id": "trot",
    "number": "02",
    "date": "2023—2024",
    "name": "TROT GIRLS JAPAN",
    "kind": "THE AUDITION",
    "badge": {
      "ko": "일본 전국 방송에서 만난 무대",
      "ja": "全国オーディションの舞台へ",
      "en": "A nationwide audition stage"
    },
    "title": {
      "ko": "16세의 목소리, 파이널까지",
      "ja": "16歳の歌声がファイナルへ",
      "en": "A finalist at sixteen"
    },
    "description": {
      "ko": "2023년 12월부터 방송된 한일 공동 오디션에서 쇼와 가요를 새로운 감성으로 표현했습니다. 2024년 2월 준결승에서 야마구치 모모에의 〈愛染橋〉로 심사 최고점 198점을 받았고, 결승에서는 〈瀬戸の花嫁〉를 불렀습니다. 우승자가 아니라 결승 진출자(파이널리스트)입니다.",
      "ja": "2023年12月から放送された日韓共同オーディションに出場。2024年2月の準決勝で山口百恵「愛染橋」を歌い、審査員最高得点198点を記録。決勝では「瀬戸の花嫁」を披露し、ファイナリストとなりました（優勝者ではありません）。",
      "en": "Aiko entered the Japan–Korea singing audition that began airing in December 2023. She earned the semifinals’ top judges’ score of 198 with Momoe Yamaguchi’s “Aizenbashi” and sang “Seto no Hanayome” in the final, becoming a finalist, not the winner."
    },
    "facts": [
      {
        "date": "2023.12.01",
        "desc": {
          "ko": "WOWOW·ABEMA에서 오디션 프로그램 방송 시작.",
          "ja": "WOWOW・ABEMAで番組放送開始。",
          "en": "Audition premiered on WOWOW and ABEMA."
        }
      },
      {
        "date": "2024.02.16",
        "desc": {
          "ko": "준결승 〈愛染橋〉 — 심사 최고점 198점으로 결승 진출.",
          "ja": "準決勝「愛染橋」―審査員最高得点198点で決勝進出。",
          "en": "“Aizenbashi” earned the highest judges’ score (198) in the semifinal."
        }
      },
      {
        "date": "2024.02.23",
        "desc": {
          "ko": "결승에서 〈瀬戸の花嫁〉 공연, 9명의 파이널리스트 중 한 명으로 무대에 섬.",
          "ja": "決勝で「瀬戸の花嫁」を披露。9人のファイナリストの一人として出演。",
          "en": "Sang “Seto no Hanayome” as one of nine finalists."
        }
      },
      {
        "date": "2024.03.15",
        "desc": {
          "ko": "결승 방송 음원 〈瀬戸の花嫁〉 디지털 음원 공개.",
          "ja": "決勝歌唱「瀬戸の花嫁」が配信音源としてリリース。",
          "en": "The finale recording of “Seto no Hanayome” was released digitally."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "준결승 〈愛染橋〉 무대 영상",
          "ja": "準決勝「愛染橋」映像",
          "en": "Semifinal “Aizenbashi” video"
        },
        "url": "https://www.youtube.com/watch?v=2BL7ydCLV5o"
      },
      {
        "label": {
          "ko": "결승 〈瀬戸の花嫁〉 공식 영상",
          "ja": "決勝「瀬戸の花嫁」公式映像",
          "en": "Final “Seto no Hanayome” official video"
        },
        "url": "https://www.youtube.com/watch?v=vXI9HjO05N4"
      },
      {
        "label": {
          "ko": "결승 곡 공식 음원 정보",
          "ja": "決勝楽曲の公式配信情報",
          "en": "Official finale music release"
        },
        "url": "https://trot-japan.com/contents/163972"
      },
      {
        "label": {
          "ko": "공식 출연자 명단",
          "ja": "公式出演者一覧",
          "en": "Official contestant list"
        },
        "url": "https://trot-japan.com/contents/menu/78742"
      }
    ],
    "color": "trot"
  },
  {
    "id": "king",
    "number": "03",
    "date": "2024.04—05",
    "name": "韓日歌王戦 · 日韓歌王戦",
    "kind": "THE KOREA CHAPTER",
    "badge": {
      "ko": "한국과 일본, 노래로 만나다",
      "ja": "歌でつながる日韓のステージ",
      "en": "Connecting Korea and Japan"
    },
    "title": {
      "ko": "한국 무대에서 펼쳐진 새로운 도전",
      "ja": "韓国の舞台で広がった新たな挑戦",
      "en": "A new chapter on Korean television"
    },
    "description": {
      "ko": "MBN 《한일가왕전》에서 일본 대표 7인 중 한 명으로 참가해 한국의 《현역가왕》 대표들과 경연했습니다. 4월 9일 김다현과의 1대1 무대에서 〈긴기라기니 사리게나쿠〉로 큰 화제를 모았고, 4월 30일에는 보아의 〈Valenti〉를 선보였습니다. 한국 팬들에게 이름을 알린 중요한 전환점입니다.",
      "ja": "MBN『韓日歌王戦』に日本代表7人の一人として出演。韓国『現役歌王』代表と競演しました。4月9日にはキム・ダヒョンとの対決で「ギンギラギンにさりげなく」を披露し注目を集め、4月30日にはBoAの「Valenti」を歌いました。",
      "en": "Aiko competed as one of Japan’s seven representatives on MBN’s Korea–Japan music series against singers from “Active King of Singers”. Her April 9 face-off with Kim Dahyun featured “Gingiragin ni Sarigenaku”; she later performed BoA’s “Valenti” on April 30."
    },
    "facts": [
      {
        "date": "2024.04.02",
        "desc": {
          "ko": "MBN 《한일가왕전》 첫 방송. 일본 대표 7인에 스미다 아이코 포함.",
          "ja": "MBN『韓日歌王戦』放送開始。日本代表7名の一人として参加。",
          "en": "Korean broadcast premiered with Aiko among seven Japanese representatives."
        }
      },
      {
        "date": "2024.04.09",
        "desc": {
          "ko": "2회 김다현과의 라이벌전에서 〈ギンギラギンにさりげなく〉 무대. 경연 승부는 김다현이 이겼지만 아이코의 공연 영상이 큰 반응을 얻음.",
          "ja": "第2回でキム・ダヒョンと対決し「ギンギラギンにさりげなく」を披露。対決は惜しくも敗れましたが、映像は大きな話題に。",
          "en": "Sang “Gingiragin ni Sarigenaku” against Kim Dahyun in episode 2. Dahyun won the head-to-head, but Aiko’s performance went viral."
        }
      },
      {
        "date": "2024.04.30",
        "desc": {
          "ko": "5회 보아의 〈Valenti〉를 노래와 안무로 표현.",
          "ja": "第5回でBoAの「Valenti」を歌とダンスで披露。",
          "en": "Performed BoA’s “Valenti” with singing and choreography in episode 5."
        }
      },
      {
        "date": "2024.05.07",
        "desc": {
          "ko": "6회로 본 경연 방송 마무리. 이후 한국 방송·공연 활동으로 이어지는 계기.",
          "ja": "第6回で本編最終放送。その後の韓国での出演活動へつながる。",
          "en": "Episode 6 concluded the competition, helping lead to further activities in Korea."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "MBN 공식 〈긴기라기니〉 무대",
          "ja": "MBN公式「ギンギラギン」映像",
          "en": "MBN official “Gingiragin” performance"
        },
        "url": "https://www.youtube.com/watch?v=zqO7fKk1N9k"
      },
      {
        "label": {
          "ko": "MBN 공식 막내 무대 모음",
          "ja": "MBN公式 末っ子ステージ集",
          "en": "MBN official junior performers compilation"
        },
        "url": "https://www.youtube.com/watch?v=6xYjHUCghWw"
      },
      {
        "label": {
          "ko": "MBN 공식 방송 다시보기",
          "ja": "MBN公式番組ページ",
          "en": "MBN official episode page"
        },
        "url": "https://www.mbn.co.kr/vod/programMain/968"
      },
      {
        "label": {
          "ko": "일본 공식 출연 안내",
          "ja": "日本側の公式出演情報",
          "en": "Official Japan-side broadcast announcement"
        },
        "url": "https://trot-japan.com/contents/170300"
      }
    ],
    "color": "king"
  },
  {
    "id": "lucky",
    "number": "04",
    "date": "2024.06—12",
    "name": "Lucky PangPang · 럭키팡팡",
    "kind": "A DUO IS BORN",
    "color": "lucky",
    "badge": {
      "ko": "국경을 넘어 만난 두 목소리",
      "ja": "国境を越えて出会った2人の歌声",
      "en": "Two voices across borders"
    },
    "title": {
      "ko": "김다현 × 스미다 아이코, 노래로 연결되다",
      "ja": "キム・ダヒョン × 住田愛子、歌でつながる",
      "en": "Kim Dahyun × Sumida Aiko"
    },
    "description": {
      "ko": "《한일가왕전》에서 한국과 일본을 대표했던 두 ‘황금막내’ 김다현과 스미다 아이코가 프로젝트 듀오 Lucky팡팡을 결성했습니다. 2024년 6월 첫 싱글 〈담다디〉로 복고 디스코 에너지를 보여준 뒤, 10월에는 새로운 디지털 싱글 〈Sugar〉로 보다 사랑스럽고 산뜻한 음악을 선보였습니다. 언어는 달라도 음악으로 함께하는 한일 듀오의 이야기입니다. 11월에는 서울에서 〈Sugar〉 발매 기념 팬사인회를 열어 팬들과 가까이 만났습니다.",
      "ja": "『韓日歌王戦』で韓国と日本を代表した“黄金の末っ子”キム・ダヒョンと住田愛子が、日韓プロジェクトデュオ Lucky PangPang を結成。2024年6月にレトロなディスコ調「DAMDADI」でデビューし、10月には新曲「Sugar」を発表しました。言葉の違いを越え、音楽でつながった2人の物語です。 11月にはソウルで「Sugar」発売記念サイン会を開催し、ファンと交流しました。",
      "en": "After meeting as the youngest representatives of Korea and Japan on Korea–Japan Song Battle, Kim Dahyun and Sumida Aiko formed the project duo Lucky PangPang. They debuted in June 2024 with the retro disco “DAMDADI,” then released the original track “Sugar” in October—a cross-border friendship expressed through music. They also met fans in Seoul at a “Sugar” release signing event in November."
    },
    "facts": [
      {
        "date": "2024.05.13",
        "desc": {
          "ko": "《불타는 장미단》 57회에서 김다현과 〈약속〉 듀엣. 럭키팡팡 결성 발표 전 함께 노래한 무대입니다.",
          "ja": "『燃えるバラ団』第57回でキム・ダヒョンと「約束」をデュエット。ユニット発表前の共演。",
          "en": "Duet “Promise” with Kim Dahyun on Burning Rose Group ep. 57, before the duo was formally announced."
        }
      },
      {
        "date": "2024.06.07",
        "desc": {
          "ko": "프로젝트 듀오 결성 소식이 공식 발표되었습니다.",
          "ja": "日韓プロジェクトデュオ結成が発表されました。",
          "en": "Formation of the Japan–Korea duo was announced."
        }
      },
      {
        "date": "2024.06.29",
        "desc": {
          "ko": "데뷔 싱글 〈담다디〉 발매. 이상은의 곡을 디스코풍으로 새롭게 편곡했습니다.",
          "ja": "デビュー曲「DAMDADI」を配信。イ・サンウンの楽曲をディスコ風にアレンジ。",
          "en": "Released debut single “DAMDADI,” a disco remake of Lee Sang-eun’s hit."
        }
      },
      {
        "date": "2024.06.29",
        "desc": {
          "ko": "KBS2 《불후의 명곡》 더 프렌즈 특집에서 〈돼지토끼〉 듀엣 무대.",
          "ja": "KBS2『不朽の名曲』THE FRIENDS特集で「豚うさぎ」をデュエット。",
          "en": "Performed “Pig Rabbit” together on KBS2 Immortal Songs."
        }
      },
      {
        "date": "2024.06.30",
        "desc": {
          "ko": "도쿄 TROT GIRLS JAPAN 콘서트 스페셜 스테이지에서 일본어판 〈담다디〉를 공연했습니다.",
          "ja": "東京のTROT GIRLS JAPANコンサートで「DAMDADI」日本語版を披露。",
          "en": "Performed the Japanese rendition of “DAMDADI” at a Tokyo special stage."
        }
      },
      {
        "date": "2024.07.05",
        "desc": {
          "ko": "KBS2 《뮤직뱅크》에서 〈담다디〉 무대를 선보였습니다.",
          "ja": "KBS2『ミュージックバンク』で「DAMDADI」を披露。",
          "en": "Performed “DAMDADI” on KBS2 Music Bank."
        }
      },
      {
        "date": "2024.07.07",
        "desc": {
          "ko": "SBS 《인기가요》에서 럭키팡팡의 〈담다디〉 무대.",
          "ja": "SBS『人気歌謡』で「DAMDADI」を披露。",
          "en": "Performed “DAMDADI” on SBS Inkigayo."
        }
      },
      {
        "date": "2024.08.21",
        "desc": {
          "ko": "〈담다디〉 일본어 버전 디지털 발매.",
          "ja": "「DAMDADI」日本語バージョン配信。",
          "en": "Digital release of “DAMDADI (Japanese ver.).”"
        }
      },
      {
        "date": "2024.10.08",
        "desc": {
          "ko": "두 번째 싱글 〈Sugar〉 발매. 두 사람의 달콤하고 경쾌한 면모를 담은 신곡입니다.",
          "ja": "2ndシングル「Sugar」を配信。2人の甘く軽やかな魅力を表現。",
          "en": "Released their second single, the sweet and upbeat “Sugar.”"
        }
      },
      {
        "date": "2024.10.12",
        "desc": {
          "ko": "MBC 《쇼! 음악중심》에서 〈Sugar〉 무대를 선보였습니다.",
          "ja": "MBC『ショー！音楽中心』で「Sugar」を披露。",
          "en": "Performed “Sugar” on MBC Show! Music Core."
        }
      },
      {
        "date": "2024.11.10",
        "desc": {
          "ko": "〈Sugar〉 발매 기념 럭키팡팡 대면·영상통화 팬사인회(팬미팅). 오후 2시, 서울시립 수서청소년수련관에서 김다현과 아이코가 팬들과 직접 만났습니다. 콘서트와 구분되는 팬 교류 행사입니다.",
          "ja": "「Sugar」発売記念 Lucky PangPang 対面＆ビデオ通話サイン会（ファンイベント）。14:00、ソウル市立水西青少年修練館で開催。コンサートとは別の記録です。",
          "en": "“Sugar” release in-person/video-call fan-sign meeting, 2 p.m. at Seoul Municipal Suseo Youth Training Center. A fan interaction event rather than a full concert."
        }
      },
      {
        "date": "2024.12.25",
        "desc": {
          "ko": "〈Sugar〉 일본어 버전 디지털 발매.",
          "ja": "「Sugar」日本語バージョン配信。",
          "en": "Released “Sugar (Japanese ver.)” digitally."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "팀 결성 인터뷰 · 연합뉴스",
          "ja": "デュオ結成インタビュー · 聯合ニュース",
          "en": "Formation interview · Yonhap"
        },
        "url": "https://www.yna.co.kr/view/AKR20240625118000005"
      },
      {
        "label": {
          "ko": "〈담다디〉 공식 뮤직비디오",
          "ja": "「DAMDADI」公式MV",
          "en": "“DAMDADI” official MV"
        },
        "url": "https://www.youtube.com/watch?v=QKAyXsymXOU"
      },
      {
        "label": {
          "ko": "〈담다디〉 일본어판 공식 안내",
          "ja": "「DAMDADI」日本語版公式案内",
          "en": "Japanese version · official release"
        },
        "url": "https://trot-japan.com/contents/192041"
      },
      {
        "label": {
          "ko": "〈Sugar〉 공식 발매 안내",
          "ja": "「Sugar」公式リリース",
          "en": "“Sugar” official release"
        },
        "url": "https://trot-japan.com/contents/205103"
      },
      {
        "label": {
          "ko": "〈Sugar〉 일본어판 공식 영상",
          "ja": "「Sugar」日本語版公式映像",
          "en": "“Sugar” Japanese MV"
        },
        "url": "https://www.youtube.com/watch?v=p1XyEGhBP44"
      },
      {
        "label": {
          "ko": "2024.11.10 팬사인회 현장 사진 (팬 기록)",
          "ja": "2024.11.10 サイン会 現地写真（ファン記録）",
          "en": "Nov. 10 fan-sign photos (fan documentation)"
        },
        "url": "https://m.dcinside.com/board/sumidaaiko/1015"
      },
      {
        "label": {
          "ko": "팬사인회 날짜·장소 기록 (비공식)",
          "ja": "サイン会の日程・会場（非公式）",
          "en": "Fan-sign date and venue (secondary listing)"
        },
        "url": "https://namu.moe/w/%EC%8A%A4%EB%AF%B8%EB%8B%A4%20%EC%95%84%EC%9D%B4%EC%BD%94"
      },
      {
        "label": {
          "ko": "KBS 공식 〈돼지토끼〉 듀엣 영상",
          "ja": "KBS公式「豚うさぎ」デュエット",
          "en": "KBS official Pig Rabbit duet"
        },
        "url": "https://www.youtube.com/watch?v=MrwoN03KDEs"
      },
      {
        "label": {
          "ko": "방송 활동 정리 보도 (2024.07.09)",
          "ja": "2024年7月テレビ出演報道",
          "en": "July 2024 music show reporting"
        },
        "url": "https://news.nate.com/view/20240709n14116"
      }
    ]
  },
  {
    "id": "korea-live",
    "number": "05",
    "date": "2024.07—11",
    "name": "TROT GIRLS JAPAN · KOREA LIVE",
    "kind": "THREE CONCERTS",
    "color": "korea",
    "badge": {
      "ko": "서울 · 부산 · 다시 서울",
      "ja": "ソウル・釜山・再びソウル",
      "en": "Seoul · Busan · Seoul again"
    },
    "title": {
      "ko": "한국 팬과 가까워진 세 번의 콘서트",
      "ja": "韓国のファンとつながった3公演",
      "en": "Three concert dates in Korea"
    },
    "description": {
      "ko": "2024년 7월 서울 무신사 개러지에서 팬미팅 〈The Beginning〉을 개최한 뒤, 트롯걸즈재팬 출연진은 한국 콘서트 투어 〈돌아와요 부산항에〉를 시작했습니다. 8월 서울과 부산을 찾았으며 11월에는 서울 앙코르 공연으로 다시 만났습니다. 세 날짜는 별개의 콘서트이며, 팬미팅은 콘서트 횟수에 포함하지 않습니다.",
      "ja": "2024年7月、ソウルでファンミーティング「The Beginning」を開催後、トロットガールズジャパンの韓国コンサート「釜山港に帰れ」が開幕。8月のソウル・釜山、11月のソウル・アンコールという3つの公演日に出演しました。7月のファンミーティングは3公演には含めません。",
      "en": "After the July fan meetings “The Beginning” in Seoul, TROT GIRLS JAPAN toured Korea with “Return to Busan Port”: Seoul in August, Busan later that month, and an encore in Seoul in November. These were three concert dates; the fan meetings are separately documented."
    },
    "facts": [
      {
        "date": "2024.07.06–07",
        "desc": {
          "ko": "사전 팬미팅 〈The Beginning〉 · 서울 무신사 개러지. 아이코는 양일 일부 회차에 출연했으며, 아래 3회 콘서트와는 별도 행사입니다.",
          "ja": "プレイベント「The Beginning」ソウル・MUSINSA GARAGE。住田愛子は両日の一部公演に参加。3コンサートとは別イベントです。",
          "en": "Earlier fan meetings at MUSINSA GARAGE, Seoul; Aiko appeared in selected sessions on both days. Not counted among the three concerts."
        }
      },
      {
        "date": "2024.08.17",
        "desc": {
          "ko": "① 서울 · 연세대학교 대강당 · 17:00. 한국 투어 첫 공연. 아이코의 〈긴기라기니 사리게나쿠〉 무대와 출연진의 메들리가 펼쳐졌습니다.",
          "ja": "① ソウル・延世大学大講堂・17:00。韓国ツアー初公演。「ギンギラギンにさりげなく」やメドレーを披露。",
          "en": "① Seoul · Yonsei University Main Auditorium · 17:00. Tour opener, featuring Aiko’s “Gingiragin ni Sarigenaku” and ensemble medleys."
        }
      },
      {
        "date": "2024.08.31",
        "desc": {
          "ko": "② 부산 · 부산 KBS홀 · 17:00. 8월 투어의 두 번째 공연으로 〈긴기라기니〉, 카노 미유와 함께한 〈사쿠란보〉 등이 소개됐습니다.",
          "ja": "② 釜山・KBS釜山ホール・17:00。ツアー2公演目。「ギンギラギン」とかのうみゆとの「さくらんぼ」などを披露。",
          "en": "② Busan · KBS Busan Hall · 17:00. Aiko sang “Gingiragin” and joined Kanou Miyu for “Sakuranbo.”"
        }
      },
      {
        "date": "2024.11.17",
        "desc": {
          "ko": "③ 서울 앙코르 · 이화여자대학교 삼성홀 · 15:00 / 19:00. 한 날짜 두 회차 공연. 〈긴기라기니〉와 나츠코와 함께한 〈혜성〉 등이 소개됐습니다.",
          "ja": "③ ソウル・アンコール・梨花女子大学サムスンホール・15:00 / 19:00。同日2公演。「ギンギラギン」、natsucoとの「彗星」など。",
          "en": "③ Seoul encore · Ewha Womans University Samsung Hall · 15:00 & 19:00. Two sessions on one date; highlights included “Gingiragin” and “Comet” with natsuco."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "한국 콘서트 공식 공지 · 서울/부산",
          "ja": "韓国コンサート公式案内 · ソウル/釜山",
          "en": "Official notice · Seoul & Busan"
        },
        "url": "https://trot-japan.com/contents/183679"
      },
      {
        "label": {
          "ko": "서울 첫 공연 결과 보도",
          "ja": "ソウル公演のレビュー",
          "en": "Seoul concert report"
        },
        "url": "https://www.newsis.com/view/NISX20240819_0002854426"
      },
      {
        "label": {
          "ko": "부산 공연 결과·세트리스트 보도",
          "ja": "釜山公演・セットリスト記事",
          "en": "Busan report & songs"
        },
        "url": "https://www.chosun.com/entertainments/music/2024/09/02/BIHYH4AT62POFUXOUHY54CCYQY/"
      },
      {
        "label": {
          "ko": "서울 앙코르 공식 공지",
          "ja": "ソウル・アンコール公式告知",
          "en": "Official Seoul encore notice"
        },
        "url": "https://trot-japan.com/contents/205562"
      },
      {
        "label": {
          "ko": "서울 앙코르 공연 후기",
          "ja": "ソウル・アンコール公演レビュー",
          "en": "Seoul encore review"
        },
        "url": "https://www.tenasia.co.kr/article/2024111882434"
      },
      {
        "label": {
          "ko": "7월 팬미팅 공식 회차표",
          "ja": "7月ファンミーティング日程",
          "en": "July fan meeting lineup"
        },
        "url": "https://trot-japan.com/schedules/46666"
      }
    ]
  },
  {
    "id": "yongjuam",
    "number": "06",
    "date": "2024.10.26",
    "name": "안동 용주암 수륙재 · 龍珠庵",
    "kind": "LOCAL FESTIVAL",
    "color": "temple",
    "badge": {
      "ko": "방송 밖에서 만난 또 하나의 무대",
      "ja": "テレビを離れた特別なステージ",
      "en": "A stage beyond television"
    },
    "title": {
      "ko": "안동의 가을, 용주암에서 노래하다",
      "ja": "安東の秋、龍珠庵で歌う",
      "en": "Singing at Yongjuam in Andong"
    },
    "description": {
      "ko": "2024년 10월 26일 경북 안동의 용주암 수륙재 연계 무대에 초대 가수로 출연했습니다. 콘서트홀·방송 스튜디오가 아닌 지역 문화 행사에서 한국 관객과 만난 기록으로, 현장 전체 공연 영상이 공개돼 있습니다. 행사 안내의 16:00~18:00는 2부 프로그램 시간이며, 아이코 개인 무대의 정확한 시작 시각을 의미하지 않습니다.",
      "ja": "2024年10月26日、韓国・慶尚北道安東の龍珠庵「水陸斎」関連イベントでゲスト歌手として出演。劇場やテレビとは異なる地域文化行事で韓国の観客と交流した記録です。16:00～18:00はプログラム全体の時間で、本人の出番時刻とは限りません。",
      "en": "On 26 October 2024, Aiko performed as a guest singer at a cultural event associated with the Yongjuam Surukjae ceremony in Andong, Korea. An audience-filmed recording documents the appearance. The advertised 16:00–18:00 refers to the program window, not her exact individual stage time."
    },
    "facts": [
      {
        "date": "2024.10.26",
        "desc": {
          "ko": "경북 안동 용주암 수륙재 연계 공연에 초대 가수로 참가.",
          "ja": "慶尚北道・安東の龍珠庵水陸斎の関連公演にゲスト出演。",
          "en": "Guest performance at Yongjuam Surukjae-related event, Andong."
        }
      },
      {
        "date": "16:00–18:00",
        "desc": {
          "ko": "행사 2부 공연 안내 시간. 개인 출연 시각·정확한 세트리스트는 공식적으로 확인되지 않아 단정하지 않습니다.",
          "ja": "イベント第2部の案内時間。本人の正確な登場時刻・セットリストは未確認です。",
          "en": "Advertised time for the second program; exact individual stage time and setlist remain unverified."
        }
      },
      {
        "date": "기록 영상",
        "desc": {
          "ko": "관객 촬영 전체 공연 영상으로 현장 무대를 다시 확인할 수 있습니다.",
          "ja": "観客撮影のフルステージ映像で当日の様子を見ることができます。",
          "en": "An audience-recorded full performance is available as an external video."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "용주암 수륙재 · 현장 공연 전체 영상",
          "ja": "龍珠庵 水陸斎 · 公演フル映像",
          "en": "Yongjuam · full audience recording"
        },
        "url": "https://www.youtube.com/watch?v=qqLecqFVaew"
      }
    ]
  },
  {
    "id": "ryoma",
    "number": "07",
    "date": "2025.01.25—26",
    "name": "転生八策 · AI坂本龍馬",
    "kind": "DANCE OPERA · OSAKA",
    "color": "ryoma",
    "badge": {
      "ko": "오사카의 새로운 무대",
      "ja": "大阪で挑戦した新しい舞台",
      "en": "A different stage in Osaka"
    },
    "title": {
      "ko": "댄스 오페라의 보컬 게스트",
      "ja": "ダンスオペラにボーカルゲスト出演",
      "en": "Vocal guest in a dance opera"
    },
    "description": {
      "ko": "2025년 1월 25~26일 오사카 COOL JAPAN PARK OSAKA TT홀에서 열린 《転生八策―AI坂本龍馬が創る未来をボクは見てみたい―》에 아이코가 보컬 게스트로 참여했습니다. 배우·댄서와 음악을 결합한 공연으로, 출연 역할을 배우나 주연으로 확대하지 않고 공식 표기대로 보컬 게스트로 기록합니다.",
      "ja": "2025年1月25・26日、COOL JAPAN PARK OSAKA TTホールで上演されたダンスオペラ『転生八策―AI坂本龍馬が創る未来をボクは見てみたい―』に、住田愛子がボーカルゲストとして参加。演技・ダンス・歌が融合する関西発の舞台で、公式発表どおり「ボーカルゲスト」として記録します。",
      "en": "Aiko appeared as a vocal guest for the dance opera Tensei Hassaku — AI Sakamoto Ryoma on January 25–26, 2025, at COOL JAPAN PARK OSAKA TT Hall. Her official credit is vocal guest, not lead actor."
    },
    "facts": [
      {
        "date": "2025.01.25",
        "desc": {
          "ko": "19:00 개연(18:30 개장) · 첫 공연",
          "ja": "19:00開演（18:30開場）・初日",
          "en": "Opening performance at 19:00, doors 18:30"
        }
      },
      {
        "date": "2025.01.26",
        "desc": {
          "ko": "13:00 / 17:00 개연 · 두 차례 공연",
          "ja": "13:00 / 17:00開演・2公演",
          "en": "Two performances at 13:00 and 17:00"
        }
      },
      {
        "date": "공연장",
        "desc": {
          "ko": "COOL JAPAN PARK OSAKA TT홀 · 오사카성 공원",
          "ja": "COOL JAPAN PARK OSAKA TTホール",
          "en": "COOL JAPAN PARK OSAKA TT Hall"
        }
      },
      {
        "date": "출연 형태",
        "desc": {
          "ko": "HppRecords 공식 발표: 보컬 게스트 · 住田愛子",
          "ja": "HppRecords公式出演表記：ボーカルゲスト・住田愛子",
          "en": "Official billing: Vocal guest · Sumida Aiko"
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "HppRecords 공식 공연·캐스팅 공지",
          "ja": "HppRecords公式公演・出演情報",
          "en": "Official HppRecords show and casting notice"
        },
        "url": "https://mfi-inc.tokyo/news/20241208/"
      }
    ]
  },
  {
    "id": "solo-first",
    "number": "08",
    "date": "2025.03.01",
    "name": "FIRST SOLO CONCERT · IWAKUNI",
    "kind": "THE FIRST SOLO",
    "color": "solo",
    "badge": {
      "ko": "고향에서 시작한 첫 번째 단독 무대",
      "ja": "故郷から始まった初のソロステージ",
      "en": "First solo concert in her hometown"
    },
    "title": {
      "ko": "처음으로 오롯이 자신의 이름을 건 콘서트",
      "ja": "住田愛子、初めての単独コンサート",
      "en": "Her very first solo concert"
    },
    "description": {
      "ko": "2025년 3월 1일, 야마구치현 이와쿠니시민문화회관 소홀에서 《住田愛子 ファーストソロコンサート》가 열렸습니다. 그룹이나 방송 경연이 아닌, 아이코 자신의 이름을 내건 첫 솔로 콘서트로 의미 있는 전환점이었습니다. 현장 외에 유료 스트리밍도 안내됐습니다. 확인되지 않은 당일 전체 세트리스트는 임의로 작성하지 않습니다.",
      "ja": "2025年3月1日、山口県岩国市民文化会館小ホールにて『住田愛子 ファーストソロコンサート』を開催。本人名義で初めて行われた単独公演で、有料配信も案内されました。当日の全曲セットリストは確認できていないため掲載していません。",
      "en": "Aiko held her first concert under her own name on March 1, 2025, at the Small Hall of Iwakuni Civic Cultural Hall in Yamaguchi. Paid streaming was also offered. The full setlist remains unverified."
    },
    "facts": [
      {
        "date": "2025.03.01",
        "desc": {
          "ko": "13:30 입장 / 14:00 개연 (16:00 종료 예정)",
          "ja": "13:30開場 / 14:00開演（16:00終演予定）",
          "en": "Doors 13:30 / Show 14:00 (scheduled end 16:00)"
        }
      },
      {
        "date": "장소",
        "desc": {
          "ko": "이와쿠니시민문화회관 소홀 · 야마구치현 이와쿠니시",
          "ja": "岩国市民文化会館 小ホール（山口県岩国市）",
          "en": "Iwakuni Civic Cultural Hall — Small Hall, Yamaguchi"
        }
      },
      {
        "date": "입장권",
        "desc": {
          "ko": "전석 자유석 3,000엔 (공식 사전 공지)",
          "ja": "全席自由 3,000円（公式事前案内）",
          "en": "JPY 3,000 unreserved seating (official pre-show notice)"
        }
      },
      {
        "date": "온라인",
        "desc": {
          "ko": "TwitCasting 유료 스트리밍 2,000엔 · 아카이브 제공 안내",
          "ja": "ツイキャス有料配信 2,000円・アーカイブ案内あり",
          "en": "Paid TwitCasting stream JPY 2,000; archive was offered"
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "TROT GIRLS JAPAN 공식 공연 공지",
          "ja": "TROT GIRLS JAPAN 公式公演案内",
          "en": "Official concert announcement"
        },
        "url": "https://trot-japan.com/contents/229530"
      },
      {
        "label": {
          "ko": "HppRecords 공식 중계 안내",
          "ja": "HppRecords公式配信情報",
          "en": "Official paid streaming announcement"
        },
        "url": "https://mfi-inc.tokyo/news/20250301-casting/"
      },
      {
        "label": {
          "ko": "아이코 본인 공연 후 감사 인사 (X)",
          "ja": "本人による公演後の投稿（X）",
          "en": "Aiko’s post-show thank-you on X"
        },
        "url": "https://x.com/aico2007921/status/1896891511750672495"
      }
    ]
  },
  {
    "id": "korean-tv",
    "number": "09",
    "date": "2024.05—10",
    "name": "KOREAN TV · SPECIAL STAGES",
    "kind": "THE BROADCAST CHAPTER",
    "color": "king",
    "badge": {
      "ko": "가왕전 밖에서 만난 노래",
      "ja": "歌王戦以外の韓国テレビ出演",
      "en": "Beyond the televised song battle"
    },
    "title": {
      "ko": "불타는 장미단부터 음악방송까지",
      "ja": "『燃えるバラ団』から音楽番組まで",
      "en": "Variety shows to music stages"
    },
    "description": {
      "ko": "《한일가왕전》·《한일톱텐쇼》 외에도 2024년 한국 방송에서 다양한 무대를 남겼습니다. 《불타는 장미단》에서는 솔로 2곡과 김다현 듀엣 1곡을, 결성 이후에는 《불후의 명곡》·《뮤직뱅크》·《인기가요》·《쇼! 음악중심》에서 함께 노래했습니다. 아래 ‘방송 특별출연’에서 방송별 근거를 확인할 수 있습니다.",
      "ja": "『韓日歌王戦』『韓日トップテンショー』以外にも、2024年は韓国の複数の番組に出演。『燃えるバラ団』でソロ2曲とキム・ダヒョンとのデュエット、そして『不朽の名曲』『ミュージックバンク』『人気歌謡』『ショー！音楽中心』でも歌唱しました。",
      "en": "Beyond the two main Korean competition series, Aiko appeared on variety and music shows. Two solo stages and a Dahyun duet on Burning Rose Group preceded further performances together on Immortal Songs, Music Bank, Inkigayo and Show! Music Core."
    },
    "facts": [
      {
        "date": "2024.05.13",
        "desc": {
          "ko": "MBN 《불타는 장미단》 57회 — 〈Stay With Me〉, 〈따라따라와〉(솔로), 김다현과 〈약속〉(듀엣).",
          "ja": "MBN『燃えるバラ団』第57回 ― 「Stay With Me」「タラタラワ」（ソロ）、キム・ダヒョンと「約束」。",
          "en": "Burning Rose Group ep. 57: “Stay With Me,” “Ttara Ttara Wa” (solo), and “Promise” with Dahyun."
        }
      },
      {
        "date": "2024.06.29",
        "desc": {
          "ko": "KBS2 《불후의 명곡》 더 프렌즈 특집 — 김다현과 〈돼지토끼〉.",
          "ja": "KBS2『不朽の名曲』でキム・ダヒョンと「豚うさぎ」。",
          "en": "KBS2 Immortal Songs with Dahyun: “Pig Rabbit.”"
        }
      },
      {
        "date": "2024.07.05—07",
        "desc": {
          "ko": "KBS2 《뮤직뱅크》 7월 5일, SBS 《인기가요》 7월 7일 — 〈담다디〉.",
          "ja": "KBS2『ミュージックバンク』7月5日・SBS『人気歌謡』7月7日 ― 「DAMDADI」。",
          "en": "Music Bank (Jul 5), SBS Inkigayo (Jul 7): “DAMDADI.”"
        }
      },
      {
        "date": "2024.10.12",
        "desc": {
          "ko": "MBC 《쇼! 음악중심》 — 신곡 〈Sugar〉.",
          "ja": "MBC『ショー！音楽中心』― 新曲「Sugar」。",
          "en": "MBC Show! Music Core: “Sugar.”"
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "MBN 공식 〈불타는 장미단〉 검색",
          "ja": "MBN公式『燃えるバラ団』検索",
          "en": "MBN show clips search"
        },
        "url": "https://search.mbn.co.kr/MBN/search.jsp?word=%EC%8A%A4%EB%AF%B8%EB%8B%A4%20%EC%95%84%EC%9D%B4%EC%BD%94"
      },
      {
        "label": {
          "ko": "KBS 공식 〈돼지토끼〉 영상",
          "ja": "KBS公式「豚うさぎ」",
          "en": "KBS official duet video"
        },
        "url": "https://www.youtube.com/watch?v=MrwoN03KDEs"
      },
      {
        "label": {
          "ko": "방송 활동 보도",
          "ja": "出演番組についての報道",
          "en": "Broadcast appearances reporting"
        },
        "url": "https://news.nate.com/view/20240709n14116"
      }
    ]
  },
  {
    "id": "solo-tv-2025",
    "number": "10",
    "date": "2025.01—09",
    "name": "2025 · TV & SOLO APPEARANCES",
    "kind": "THE SOLO JOURNEY",
    "color": "solo",
    "badge": {
      "ko": "단독 공연과 새로운 무대를 이어가다",
      "ja": "ソロの歌声と新たなステージ",
      "en": "Solo and new stages"
    },
    "title": {
      "ko": "일본 방송, 오이타 가요제, 팬들과의 만남",
      "ja": "日本のテレビ、大分歌謡祭、ファンとの時間",
      "en": "On television and on stage in 2025"
    },
    "description": {
      "ko": "2025년에도 아이코의 독립된 무대가 이어졌습니다. 1월 김다현과 일본·한국 대표로 다시 함께한 후지TV 《歌ウマ女王日韓決戦 JAPAN ROUND》, 3월 도쿄 TROT GIRLS JAPAN 팬미팅·콘서트, 6월 오이타 《歌魂カラオケ大賞 歌謡祭》 출연까지 별도 기록했습니다. 행사 전체 진행 시간과 아이코 개인 가창 시간은 구분합니다.",
      "ja": "2025年も多彩な出演が続きました。1月のフジテレビ『歌ウマ女王日韓決戦 JAPAN ROUND』ではキム・ダヒョンと日韓代表として再び共演。3月の東京ファンミ＆コンサート、6月の大分『歌魂カラオケ大賞 歌謡祭』なども別記録にしました。",
      "en": "Aiko returned alongside Dahyun on Fuji TV’s Japan Round in January, joined the TROT GIRLS JAPAN fan meeting and concert in Tokyo in March, and appeared at the Utatama music festival in Oita in June. Event-wide times are not presented as her individual performance times."
    },
    "facts": [
      {
        "date": "2025.01.16",
        "desc": {
          "ko": "후지TV 《歌ウマ女王日韓決戦 JAPAN ROUND》 — 아이코 일본 대표, 김다현 한국 대표로 함께 출연.",
          "ja": "フジテレビ『歌ウマ女王日韓決戦 JAPAN ROUND』― 住田愛子が日本代表、キム・ダヒョンが韓国代表として出演。",
          "en": "Fuji TV Japan Round: Aiko representing Japan and Dahyun representing Korea."
        }
      },
      {
        "date": "2025.02.17",
        "desc": {
          "ko": "TV도쿄 《昭和vs令和!》 히트곡 특집에 가창 게스트로 출연.",
          "ja": "テレビ東京『昭和vs令和！』ヒット曲特番に歌唱ゲストとして出演。",
          "en": "TV Tokyo Showa vs. Reiwa music special; singing guest."
        }
      },
      {
        "date": "2025.02.23 / 03.02",
        "desc": {
          "ko": "NHK WORLD-JAPAN 라디오 〈하나카페〉 게스트 2회 방송.",
          "ja": "NHK WORLD-JAPAN『ハナカフェ』ゲスト出演・全2回。",
          "en": "Two episodes as a guest on NHK WORLD-JAPAN Hana Cafe."
        }
      },
      {
        "date": "2025.03.30",
        "desc": {
          "ko": "도쿄 Club eX TROT GIRLS JAPAN 1부 팬미팅 14:30, 2부 콘서트 18:00.",
          "ja": "東京Club eXにてTROT GIRLS JAPAN 1部ファンミ14:30、2部コンサート18:00。",
          "en": "TROT GIRLS JAPAN Tokyo, Club eX — fan meeting 14:30; concert 18:00."
        }
      },
      {
        "date": "2025.06.08",
        "desc": {
          "ko": "제7회 歌魂カラオケ大賞 歌謡祭 · 오이타 J:COM 호ルト홀 대홀, 공식 출연 명단에 아이코 기재. 전체 행사 10:00~19:30(예정), 개인 무대 시간과 선곡은 확인 중.",
          "ja": "第7回 歌魂カラオケ大賞 歌謡祭（J:COMホルトホール大分 大ホール）公式出演者に記載。イベント全体10:00〜19:30予定、本人歌唱時間・曲目は未確認。",
          "en": "Seventh Utatama karaoke and song festival, J:COM Horuto Hall Oita. Aiko appears on the venue cast list. Full event scheduled 10:00–19:30; her individual slot and songs are unverified."
        }
      },
      {
        "date": "2025.06.13",
        "desc": {
          "ko": "TV도쿄 《歌のサンセット》 방송 출연.",
          "ja": "テレビ東京『歌のサンセット』に出演。",
          "en": "TV Tokyo “Uta no Sunset” appearance."
        }
      },
      {
        "date": "2025.09.27",
        "desc": {
          "ko": "한일교류축제 2025 도쿄 K-POP 콘서트 · 고마자와 올림픽공원 중앙광장 출연.",
          "ja": "日韓交流おまつり2025 in Tokyo・K-POPコンサート、駒沢オリンピック公園中央広場に出演。",
          "en": "Japan–Korea Exchange Festival K-pop concert, Komazawa Olympic Park."
        }
      }
    ],
    "links": [
      {
        "label": {
          "ko": "후지TV 공식 출연자 안내",
          "ja": "フジテレビ公式番組案内",
          "en": "Fuji TV official broadcast announcement"
        },
        "url": "https://www.fujitv.co.jp/fujitv/news/20250004.html"
      },
      {
        "label": {
          "ko": "도쿄 공연 공식 일정",
          "ja": "東京公演公式日程",
          "en": "Tokyo concert official schedule"
        },
        "url": "https://trot-japan.com/contents/217486"
      },
      {
        "label": {
          "ko": "오이타 공연장 공식 출연 명단",
          "ja": "大分会場公式出演情報",
          "en": "Oita venue official cast listing"
        },
        "url": "https://www.horutohall-oita.jp/event/3815/"
      },
      {
        "label": {
          "ko": "TV도쿄 공식 출연 공지",
          "ja": "テレビ東京出演情報",
          "en": "TV Tokyo official appearance notice"
        },
        "url": "https://mfi-inc.tokyo/news/20250613-aiko/"
      },
      {
        "label": {
          "ko": "한일교류축제 공식 일정",
          "ja": "日韓交流おまつり出演情報",
          "en": "Japan-Korea festival notice"
        },
        "url": "https://trot-japan.com/contents/294413"
      }
    ]
  }
];
