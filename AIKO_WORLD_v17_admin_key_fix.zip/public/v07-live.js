/* Make highlight cards reflect whatever the admin has saved as upcoming events. */
(() => {
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const loc=(o,lang)=>typeof o==='string'?o:(o?.[lang]||o?.ko||o?.ja||'');
const dateOnly=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const safe=s=>{try{const u=new URL(s);return u.protocol==='https:'?u.href:null}catch{return null}};
function render(){
 const lang=document.querySelector('[data-lang][aria-pressed="true"]')?.dataset.lang||'ko';
 const grid=document.querySelector('#updates .update-grid');if(!grid)return;
 const e=(window.AIKO_DATA?.events||[]).filter(x=>((x.until||x.date)>=dateOnly)&&x.date)
  .sort((a,b)=>a.date.localeCompare(b.date)||(a.time||'').localeCompare(b.time||'')).slice(0,3);
 if(!e.length){grid.innerHTML='<article class="update-card"><h3>CHECK OFFICIAL UPDATES</h3><p>다음 공연 정보는 공식 출처에서 확인해 주세요.</p></article>';return}
 grid.replaceChildren();
 e.forEach(event=>{
  const card=document.createElement('article');card.className='update-card';
  const tag=document.createElement('div');tag.className='update-card-top';
  const label=document.createElement('span');label.className='update-type';label.textContent=event.status==='confirmed'?'LIVE / CONFIRMED':'PRODUCTION / CAST UNCONFIRMED';
  const date=document.createElement('span');date.textContent=event.date;
  tag.append(label,date);
  const h=document.createElement('h3');h.textContent=loc(event.title,lang);
  const p=document.createElement('p');p.textContent=(event.venue||'')+' · '+(event.time?event.time+' JST · ':'')+(event.status==='production'?'작품 전체 일정 / 출연 미확인':'출연 확인');
  const actions=document.createElement('div');actions.className='update-card-actions';
  const url=safe(event.source||'');if(url){const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.textContent=lang==='ja'?'公式出典 ↗':lang==='en'?'Source ↗':'공식 출처 ↗';actions.append(a)}
  const button=document.createElement('button');button.type='button';button.dataset.save=event.id;button.textContent='☆ '+(lang==='ja'?'予定に保存':lang==='en'?'Save show':'내 일정 저장');actions.append(button);
  card.append(tag,h,p,actions);grid.append(card);
 });
}
window.addEventListener('aiko:language',render);render();
})();
