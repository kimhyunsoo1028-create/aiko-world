# 愛子 WORLD v1.6 · 럭키팡팡 영상 링크 확장

기준: v1.5 전체 사이트 유지 (공연, 방송, 사진, 한국어/일본어/영어)

변경 사항
- 음악 > 「DAMDADI · 담다디」: 6개 링크
  1. nCHworld 공식 뮤직비디오
  2. KBS 뮤직뱅크 방송 클립 (2024.07.05)
  3. SBS 인기가요 방송 클립 (2024.07.07)
  4. SBS 인기가요 4K 풀캠
  5. SBS 직캠 모음 재생목록 (개별 아이코 직캠 포함)
  6. DAMDADI 일본어 버전 (공식 안내)
- 음악 > 「Sugar」: 3개 링크
  1. SEOUL MUSIC 공식 뮤직비디오
  2. MBC 쇼! 음악중심 (2024.10.12)
  3. Sugar 일본어 버전 (공식 안내)
- 각 링크를 MV/TV/FANCAM/JAPANESE로 구분
- 모든 링크는 외부 원본 영상으로 이동; 저작권 보호되는 영상을 사이트에 직접 업로드하지 않음
- 모바일 1열, PC 2열 링크 모음

출처 검토: KBS 공식 VOD, SBS 방송, SBSKPOP 풀캠, nCHworld 공식 MV, 서울뮤직 공식 MV, MBCkpop 공식 TV, TROT GIRLS JAPAN 공식 일본어 버전 공지.

배포: 압축 풀기 → 기존 Netlify 프로젝트 Deploys → 폴더 전체 업로드 → Published 확인.
현재 공개 사이트는 자동 업데이트되지 않습니다.
