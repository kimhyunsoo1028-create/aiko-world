window.AIKO_TV_SPECIALS = [
  {
    "date": "2024-05-13",
    "station": "MBN",
    "kind": "joint",
    "name": "불타는 장미단 · 57회",
    "nameJa": "燃えるバラ団 · 第57回",
    "nameEn": "Burning Rose Group · episode 57",
    "songs": [
      "真夜中のドア〜Stay With Me (솔로)",
      "따라따라와 (솔로)",
      "약속 (김다현 듀엣)"
    ],
    "note": "럭키팡팡 결성 전 방송. ‘불타는 세계 속으로’ 특집.",
    "noteJa": "Lucky PangPangの結成発表前の共演。",
    "noteEn": "A variety performance before the duo was formally announced.",
    "link": "https://search.mbn.co.kr/MBN/search.jsp?word=%EC%8A%A4%EB%AF%B8%EB%8B%A4%20%EC%95%84%EC%9D%B4%EC%BD%94",
    "source": "MBN / 스타뉴스"
  },
  {
    "date": "2024-06-29",
    "station": "KBS2",
    "kind": "joint",
    "name": "불후의 명곡 · 더 프렌즈 특집",
    "nameJa": "不朽の名曲 · THE FRIENDS",
    "nameEn": "Immortal Songs · The Friends",
    "songs": [
      "돼지토끼 (김다현 듀엣)"
    ],
    "note": "장윤정의 노래로 두 사람이 함께 꾸민 무대.",
    "noteJa": "キム・ダヒョンと「豚うさぎ」を披露。",
    "noteEn": "“Pig Rabbit” duet with Kim Dahyun.",
    "link": "https://www.youtube.com/watch?v=MrwoN03KDEs",
    "source": "KBS 한국방송 공식 영상"
  },
  {
    "date": "2024-07-05",
    "station": "KBS2",
    "kind": "lucky",
    "name": "뮤직뱅크",
    "nameJa": "ミュージックバンク",
    "nameEn": "Music Bank",
    "songs": [
      "담다디 (럭키팡팡)"
    ],
    "note": "데뷔 싱글 음악방송.",
    "noteJa": "デビュー曲「DAMDADI」の音楽番組出演。",
    "noteEn": "Music-show promotion of the debut single.",
    "link": "https://sports.khan.co.kr/article/202407051953003",
    "source": "스포츠경향 / KBS 화면"
  },
  {
    "date": "2024-07-07",
    "station": "SBS",
    "kind": "lucky",
    "name": "인기가요",
    "nameJa": "人気歌謡",
    "nameEn": "Inkigayo",
    "songs": [
      "담다디 (럭키팡팡)"
    ],
    "note": "7월 7일 SBS 음악방송 출연.",
    "noteJa": "7月7日SBSの音楽番組に出演。",
    "noteEn": "SBS music program performance.",
    "link": "https://news.nate.com/view/20240709n14116",
    "source": "헤럴드경제 보도"
  },
  {
    "date": "2024-10-12",
    "station": "MBC",
    "kind": "lucky",
    "name": "쇼! 음악중심",
    "nameJa": "ショー！音楽中心",
    "nameEn": "Show! Music Core",
    "songs": [
      "Sugar (럭키팡팡)"
    ],
    "note": "두 번째 싱글 발매 후 방송 무대.",
    "noteJa": "2ndシングル「Sugar」披露。",
    "noteEn": "Second-single music-show performance.",
    "link": "https://v.daum.net/v/20241013122414172",
    "source": "헤럴드경제 / 음악중심 방송 보도"
  },
  {
    "date": "2025-01-16",
    "station": "Fuji TV",
    "kind": "japan",
    "name": "歌ウマ女王日韓決戦 JAPAN ROUND",
    "nameJa": "歌ウマ女王日韓決戦 JAPAN ROUND",
    "nameEn": "Singing Queens Japan Round",
    "songs": [],
    "note": "아이코와 김다현은 각각 일본·한국 대표로 출연. 일본 방송이며 같은 편에 출연했지만 럭키팡팡 듀엣 무대로 분류하지 않습니다.",
    "noteJa": "住田愛子は日本代表、キム・ダヒョンは韓国代表。2人のユニット出演ではありません。",
    "noteEn": "Aiko represented Japan and Dahyun Korea; not billed as a Lucky PangPang duo stage.",
    "link": "https://www.fujitv.co.jp/fujitv/news/20250004.html",
    "source": "Fuji TV 공식"
  },
  {
    "date": "2025-02-17",
    "station": "TV Tokyo",
    "kind": "japan",
    "name": "昭和vs令和！ 음악 특집",
    "nameJa": "昭和vs令和！世代を超えて愛される最強ヒット曲",
    "nameEn": "Showa vs Reiwa music special",
    "songs": [],
    "note": "아이코 개인 가창 게스트로 출연. 선곡은 확인 중.",
    "noteJa": "住田愛子が歌唱ゲストとして出演。曲目調査中。",
    "noteEn": "Aiko performed as a singing guest; songs pending verification.",
    "link": "https://mfi-inc.tokyo/news/20250217-aico-2/",
    "source": "HppRecords 공식"
  },
  {
    "date": "2025-06-13",
    "station": "TV Tokyo",
    "kind": "japan",
    "name": "歌のサンセット",
    "nameJa": "歌のサンセット",
    "nameEn": "Uta no Sunset",
    "songs": [],
    "note": "아이코 개인 방송 출연. 곡목 확인 중.",
    "noteJa": "住田愛子ソロ出演、曲目調査中。",
    "noteEn": "Aiko appearance; song title pending verification.",
    "link": "https://mfi-inc.tokyo/news/20250613-aiko/",
    "source": "HppRecords 공식"
  }
];
