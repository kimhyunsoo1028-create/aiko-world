-- 안전한 조회만 실행; 기존 생성 테이블을 변경하지 않습니다.
select c.relname as table_name, c.relrowsecurity as rls_enabled
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname in
('site_admins','site_content','site_articles','feed_sources','feed_inbox')
order by c.relname;
