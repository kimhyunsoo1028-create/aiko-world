# AIKO WORLD v17 관리자 연결 수정

Supabase Publishable Key에는 하이픈(`-`)이 포함될 수 있습니다. v17의 검증 정규표현식이 하이픈을 거부하여 관리자가 연결되지 않던 오류를 수정했습니다.

수정된 파일:
- `netlify/functions/public-config.mjs`
- `public/cms-config.js`

나머지 홈페이지, 사진, 관리자 기능, 서버 함수 및 기존 데이터는 원본 v17 그대로입니다.

Netlify의 현재 GitHub 저장소에 이 ZIP을 추가한 후, **Project configuration → Developer settings → Continuous deployment → Build settings**에서 Build command를 다음과 같이 변경해 저장하세요.

`unzip -o AIKO_WORLD_v17_admin_key_fix.zip`

Publish directory는 `public`, Functions directory는 `netlify/functions` 유지. 다시 배포하고 관리자 페이지를 확인하세요.

이 ZIP에 환경변수 값이나 비밀 키는 포함되어 있지 않습니다. 이전에 노출된 Supabase Secret key는 회전(폐기/새 키로 대체)하세요.
