# 愛子 WORLD v1.7 — 관리자·자동 수집 통합판

기준: **v1.6의 기존 전시·음악·럭키팡팡 링크·발자취·방송·공연 카드 전부 보존**.
기존 Netlify 사이트는 아직 수정되지 않았습니다. 이 파일은 직접 배포해야 합니다.

## 이미 완료한 내용
- Supabase DB 5개 테이블 생성 / `ADMIN_OK` 확인
- Netlify `SUPABASE_URL` 등록
- Netlify `SUPABASE_SERVICE_ROLE_KEY`를 **Production secret**으로 등록

## 배포 전에 해야 할 단 한 가지 추가 설정
현재 Netlify Project configuration > Environment variables > Add a variable > Add a single variable에서:

- **Key:** `SUPABASE_PUBLISHABLE_KEY`
- **Value:** Supabase Project Settings > API Keys > **Publishable key** (`sb_publishable_`로 시작하는 키)
- **Secret:** 체크하지 않아도 됨. 이 키는 브라우저에서 노출되어도 되는 공개용 키입니다. Netlify가 경고하면 공개 값 저장을 선택할 수 있습니다.
- **Values:** Production에 입력하면 됩니다. All scopes 또는 Functions 범위에 포함되어야 합니다.

**절대로 `SUPABASE_SERVICE_ROLE_KEY`나 `sb_secret_` 키를 `SUPABASE_PUBLISHABLE_KEY`에 넣지 마세요.**

## PC 배포 (자동 수집 서버 기능까지 활성화하는 방법)

1. 이 ZIP을 PC에서 다운로드해 압축 풉니다. `public/`과 `netlify/functions/`가 함께 보여야 합니다.
2. Node.js 설치 후 PowerShell/터미널에서 다음 명령을 실행합니다.

```powershell
npm install --global netlify-cli
netlify login
cd "압축해제한_프로젝트_폴더"
netlify deploy --prod --site creative-melomakarona-e53d52 --dir public --functions netlify/functions
```

**주의:** Netlify Drop에 `public/` 폴더만 드래그하면 HTML은 올라가도 `netlify/functions/` 서버 함수가 함께 배포된다는 보장이 없습니다. 자동 수집을 켜려면 **Netlify CLI 또는 Git 연동 배포**를 이용하세요. <https://docs.netlify.com/build/functions/get-started/>

3. 배포 후 다음을 확인합니다.
   - 공개 화면 `https://creative-melomakarona-e53d52.netlify.app/`의 기존 사진 4장·음악·발자취 유지
   - `https://creative-melomakarona-e53d52.netlify.app/.netlify/functions/cms-status` 에서 `publicConfigPresent:true`, `serverKeyPresent:true`
   - `https://creative-melomakarona-e53d52.netlify.app/admin/`에서 기존 Supabase 관리자 이메일/비밀번호로 로그인
   - 관리자 화면에서 **소식(임시저장) → 게시**, 공연 추가 후 공개 화면 새로고침
   - Netlify Functions에 `collect-scheduled`가 표시되는지 확인 (6시간 간격, UTC 기준)

## 기능 한계 / 출처
- 자동 수집은 RSS/Atom 제공 여부에 따라 다릅니다. 도메인만 등록되어 있어도 실제 피드가 아닐 수 있습니다.
- 지원 도메인: `mfi-inc.tokyo`, `ovalsistem.work`, `www.youtube.com`.
- 관리자 화면 `수집 출처 → 지금 수집 실행`에서 실제 작동 및 오류 내역을 확인하세요.
- 가져온 기사는 모두 `pending`으로 저장됩니다. 승인 전 방문자 화면에 보이지 않습니다.
- 기사에서 공연 일정 **후보**를 만들 수 있지만 날짜/장소/출연 여부는 관리자가 직접 검증하고 저장해야 합니다. RSS를 근거로 일정을 무조건 자동 확정하지 않습니다.
- X, 인스타그램, SNS 게시물 전체 자동 수집은 포함되지 않습니다.
- 공개 Netlify URL의 기존 정적 프로그램 기록은 그대로 표시되며, DB에 저장한 공연·게시글·사진만 교체/추가됩니다.
- Netlify 환경변수를 추가한 뒤에는 **새로 배포**해야 함수에 적용됩니다.

## 보안
- `public/cms-config.js`에는 비밀키가 없습니다. 공개용 키는 Netlify Function `public-config`가 제공합니다.
- `SUPABASE_SERVICE_ROLE_KEY` / `sb_secret_` 값은 서버 함수 환경변수로만 접근합니다.
- Supabase RLS와 관리자 검증을 거친 사용자만 쓰기 작업이 가능합니다.
- 키 값이나 데이터베이스 비밀번호를 채팅/공개 ZIP/스크린샷에 올리지 마세요.
- 비밀키가 외부에 노출됐을 가능성이 있다면 Supabase에서 교체하고 Netlify 환경변수도 교체하세요.
