@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================
echo AIKO WORLD v1.7  -  Netlify existing-site deploy
 echo ===============================================
echo.
where netlify >nul 2>&1
if errorlevel 1 (
  echo Netlify CLI is not installed.
  echo After installing Node.js, open PowerShell and run:
  echo   npm install --global netlify-cli
  pause
  exit /b 1
)
echo Sign in to the correct Netlify account if prompted.
call netlify login
echo.
echo Deploying the existing site. Do not close this window while deploying.
call netlify deploy --prod --site creative-melomakarona-e53d52 --dir public --functions netlify/functions
if errorlevel 1 (
  echo Deploy did not finish successfully. Please read the error above.
) else (
  echo Deploy command completed. Verify Published and Functions in the Netlify dashboard.
)
pause
