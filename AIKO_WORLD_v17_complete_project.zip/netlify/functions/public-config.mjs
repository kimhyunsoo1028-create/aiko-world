/* Returns PUBLIC client configuration ONLY. Never expose the Supabase secret key. */
const env = name => (typeof Netlify !== 'undefined' && Netlify.env) ? Netlify.env.get(name) : process.env[name];
export default async function(request) {
  if(request.method!=='GET') return Response.json({error:'Method not allowed'},{status:405});
  const url=env('SUPABASE_URL');
  const key=env('SUPABASE_PUBLISHABLE_KEY');
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(url||'') || !/^sb_publishable_[A-Za-z0-9_]+$/.test(key||''))
    return Response.json({error:'Public CMS configuration is incomplete'},{status:503,headers:{'Cache-Control':'no-store'}});
  return Response.json({url:url.replace(/\/$/,''),publishableKey:key},{headers:{'Cache-Control':'public, max-age=60'}});
}
