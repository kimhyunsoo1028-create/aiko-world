/* 愛子 WORLD public client configuration. No secret/server key is sent to browsers. */
window.AIKO_CMS_CONFIG = {url: 'https://daunkvtqiuxijlwwbpcj.supabase.co', publishableKey: ''};
window.AIKO_CMS_READY = (async () => {
  try {
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 6000);
    let response;
    try { response = await fetch('/.netlify/functions/public-config', { cache: 'no-store', signal: ctrl.signal }); }
    finally { clearTimeout(timeout); }
    if (!response.ok) throw new Error(`Configuration not available (HTTP ${response.status})`);
    const data = await response.json();
    if (data.url === window.AIKO_CMS_CONFIG.url && /^sb_publishable_[A-Za-z0-9_]+$/.test(data.publishableKey || '')) {
      window.AIKO_CMS_CONFIG.publishableKey = data.publishableKey;
    }
  } catch (error) {
    console.info('AIKO WORLD: public CMS config unavailable; using published archive.');
  }
  return window.AIKO_CMS_CONFIG;
})();
