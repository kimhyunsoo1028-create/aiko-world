/** v50 patch: distinct Sumida Aiko radio and OVAL broadcasts. Run after v49. */
'use strict';
const fs=require('node:fs'),path=require('node:path');const root=process.cwd(),pub=path.join(root,'public'),admin=path.join(pub,'admin');
const src=path.join(root,'aiko-v50-broadcasts');
const pairs=[
  ['radio-public-v49.js',path.join(pub,'radio-public-v49.js')],
  ['radio-admin-v49.js',path.join(admin,'radio-admin-v49.js')],
  ['broadcast-public-v50.js',path.join(pub,'broadcast-public-v50.js')],
  ['broadcast-admin-v50.js',path.join(admin,'broadcast-admin-v50.js')],
  ['broadcast-v50.css',path.join(pub,'broadcast-v50.css')]
];
for(const [name,dest] of pairs){const origin=path.join(src,name);if(!fs.existsSync(origin))throw Error('v50 patch missing '+name);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(origin,dest)}
function upgrade(file,repls,injects){let text=fs.readFileSync(file,'utf8');for(const [a,b] of repls)text=text.replace(a,b);for(const [tag,html,marker] of injects){if(text.includes(marker))continue;if(!text.includes(tag))throw Error('v50 cannot find '+tag);text=text.replace(tag,html+'\n'+tag)}fs.writeFileSync(file,text,'utf8')}
upgrade(path.join(pub,'index.html'),
  [['/radio-public-v49.js?v=49.0','/radio-public-v49.js?v=50.0']],
  [['</head>','<link rel="stylesheet" href="/broadcast-v50.css?v=50.0">','/broadcast-v50.css'],['</body>','<script defer src="/broadcast-public-v50.js?v=50.0"></script>','/broadcast-public-v50.js']]);
upgrade(path.join(admin,'index.html'),
  [['/admin/radio-admin-v49.js?v=49.0','/admin/radio-admin-v49.js?v=50.0']],
  [['</body>','<script defer src="/admin/broadcast-admin-v50.js?v=50.0"></script>','/admin/broadcast-admin-v50.js']]);
console.log('[AIKO v50] radio (HOP! STEP!) and With OVAL Wednesday broadcast split installed');
